package pt.isec.poe_deis_cl.utils;

/**
 * Class description:
 * <br>
 * Class description:
 * Enum with all the Errors
 * All the info of errors message are here to better manage and reuse
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public enum Errors {

    /**
     * Filenotfound error errors.
     */
    FILENOTFOUND_ERROR,
    /**
     * Email error errors.
     */
    EMAIL_ERROR,
    /**
     * Emailoccupied error errors.
     */
    EMAILOCCUPIED_ERROR,
    /**
     * Emailnotfound error errors.
     */
    EMAILNOTFOUND_ERROR,
    /**
     * Int error errors.
     */
    INT_ERROR,
    /**
     * Boolean error errors.
     */
    BOOLEAN_ERROR,
    /**
     * Id notfound error errors.
     */
    ID_NOTFOUND_ERROR,
    /**
     * Id format errors.
     */
    ID_FORMAT,
    /**
     * Namelimit error errors.
     */
    NAMELIMIT_ERROR,
    /**
     * Course error errors.
     */
    COURSE_ERROR,
    /**
     * Branch error errors.
     */
    BRANCH_ERROR,
    /**
     * Grade error errors.
     */
    GRADE_ERROR,
    /**
     * Double error errors.
     */
    DOUBLE_ERROR,
    /**
     * Outofbounds error errors.
     */
    OUTOFBOUNDS_ERROR,
    /**
     * Proj num error errors.
     */
    PROJ_NUM_ERROR,
    /**
     * Proj not found errors.
     */
    PROJ_NOT_FOUND,
    /**
     * Choice error errors.
     */
    CHOICE_ERROR,
    /**
     * Long error errors.
     */
    LONG_ERROR,
    /**
     * Delete error errors.
     */
    DELETE_ERROR,
    /**
     * Delete all error errors.
     */
    DELETE_ALL_ERROR,
    /**
     * Export error errors.
     */
    EXPORT_ERROR,
    /**
     * Export remove error errors.
     */
    EXPORT_REMOVE_ERROR,
    /**
     * Close State error errors.
     */
    CLOSESTATE_ERROR,
    /**
     * Exception general error errors.
     */
    EXCEPTION_GENERAL_ERROR,
    /**
     * Option general ERROR error errors.
     */
    GENERAL_ERROR,
    /**
     * Option notvalid error errors.
     */
    OPTION_NOTVALID_ERROR,
    /**
     * Not Found error errors.
     */
    NOTFOUND_ERROR,
    /**
     * Beginning of the sentence of error errors.
     */
    START_ERROR,

    /**
     * Index error errors.
     */
    INDEX_ERROR;

    private Errors() {
    }

    /**
     * Gets error.
     *
     * @return the error
     */
    public String getError() {
        String erroStr = "✘ -> ";
        switch (this) {
            case FILENOTFOUND_ERROR -> erroStr += " Mail not found!\n";
            case EMAIL_ERROR -> erroStr += " Mail not found!\n";
            case INT_ERROR -> erroStr += this;
            case BOOLEAN_ERROR -> erroStr += this;
            case NAMELIMIT_ERROR -> erroStr += this;
            case EMAILOCCUPIED_ERROR -> erroStr += this;
            case EMAILNOTFOUND_ERROR -> erroStr += this;
            case COURSE_ERROR -> erroStr += this;
            case DOUBLE_ERROR -> erroStr += this;
            case LONG_ERROR -> erroStr += this;
            case ID_NOTFOUND_ERROR -> erroStr += "Id not found \n";
            case ID_FORMAT -> erroStr += this + " not accepted ";
            case BRANCH_ERROR -> erroStr += this;
            case OUTOFBOUNDS_ERROR -> erroStr += this + " Interval: 0.00 to 1.00 ";
            case GRADE_ERROR -> erroStr += this; //not in use???????
            case PROJ_NOT_FOUND -> erroStr += "Project not found";
            case PROJ_NUM_ERROR -> erroStr += " Error Project Number not in the right format! ";
            case DELETE_ERROR -> erroStr += this + " Problem while deleting ";
            case DELETE_ALL_ERROR -> erroStr += " Problem while deleting all data from this categorie! ";
            case EXPORT_ERROR -> erroStr += this + " Problem while exporting data! ";
            case EXPORT_REMOVE_ERROR -> erroStr += " Export data not removed! ";
            case CLOSESTATE_ERROR-> erroStr += " Data is missing, insert data before closing the fase!\n";
            case EXCEPTION_GENERAL_ERROR -> erroStr += " Exception, An error has occurred: ";
            case GENERAL_ERROR -> erroStr += " An error has occurred: ";
            case OPTION_NOTVALID_ERROR -> erroStr += " Not a valid option!";
            case NOTFOUND_ERROR -> erroStr += " Not Found ";
            case START_ERROR -> erroStr += " ";
            case INDEX_ERROR -> erroStr += " Index error ";

        }

        return erroStr;
    }
}





