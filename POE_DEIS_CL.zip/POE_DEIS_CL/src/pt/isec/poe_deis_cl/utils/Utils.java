package pt.isec.poe_deis_cl.utils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The type Utils.
 */
public class Utils {

    private static void sleepError(int time) {
        System.err.flush();
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.flush();
    }

    /**
     * Error print.
     *
     * @param error the error
     */
    public static void errorPrint(String error) {
        System.err.print(error);
        sleepError(10);
    }

    /**
     * Error print.
     *
     * @param error the error
     * @param t     the t
     */
    public static void errorPrint1(String error, int t) {
        System.err.print(error);
        sleepError(t);
    }

    /**
     * Gets date.
     *
     * @return the date
     */
    public static String getformatDate() {

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");


        return sdf.format(date);
    }

    /**
     * Delete folder.
     *
     * @param folder the folder
     */
    public static void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file: files) {
                if (file.isDirectory())
                    deleteFolder(file);
                file.delete();
            }
        }
    }

    /**
     * Export delete boolean.
     *
     * @param startwith the startwith
     * @return the boolean
     */
    public static boolean exportDelete(String startwith) {

        File dir = new File("Resources/exports/");
        File[] files = dir.listFiles();
        try{
            if (files != null) {
                for (File file: files) {
                    if (file.getName().startsWith(startwith)) {
                        file.delete();
                    }

                }
            }
            return true;

        }catch(NullPointerException e ){
            errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
            return false;
        }

    }

    /**
     * Export delete boolean.
     *
     * @param startwith the startwith
     * @return the boolean
     */
    public static boolean removePoints(String startwith) {

        File dir = new File("Resources/SavePoints");
        File[] files = dir.listFiles();
        try{
            if (files != null) {
                for (File file: files) {
                    if (file.getName().startsWith(startwith)) {
                        file.delete();
                    }

                }
            }
            return true;

        }catch(NullPointerException e ){
            errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
            return false;
        }

    }

    /**
     * Export exists boolean.
     *
     * @param startwith the startwith
     * @param folder    the folder
     * @return the boolean
     */
    public static boolean fileExists(String startwith, String folder) {

        File dir = new File("Resources/"+folder);
        File[] files = dir.listFiles();
        if(FolderCreate(folder))
            return false;
        try{
            for (File file: files) {
                if (file.getName().startsWith(startwith)) {
                    return true;
                }

            }
        }catch(NullPointerException e){
            //errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
            return false;
        }
        return false;

    }

    /**
     * Check empty file boolean.
     *
     * @param startwith the startwith
     * @return the boolean
     */
    public static boolean checkEmptyFile(String startwith) {


        File dir = new File("Resources/imports/");
        File[] files = dir.listFiles();
        if(FolderCreate("imports"))
            return false;
        try{
            for (File file: files) {
                if (file.getName().startsWith(startwith)) {
                    return file.length() == 0;
                }

            }
        }catch(NullPointerException e){
            //errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
            return false;
        }
        return false;

    }



    private static boolean FolderCreate(String fName) {
        File directory = new File("Resources/"+fName);
        if(!directory.exists()) {
            directory.mkdir();
            return true;
        }
        return false;
    }

    /**
     * Copy file boolean.
     *
     * @param source the source
     * @param dest   the dest
     * @return the boolean
     */
    public static boolean copyFile(String source, String dest){

        try {
            return copyFileNIO(source, dest);


        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }


    }

    /**
     * Copy file nio boolean.
     *
     * @param from the from
     * @param to   the to
     * @return the boolean
     * @throws IOException the io exception
     */
    public static boolean copyFileNIO(String from, String to) throws IOException {

            Path fromFile = Paths.get(from);
            Path toFile = Paths.get(to);

            // if fromFile doesn't exist, Files.copy throws NoSuchFileException
            if (Files.notExists(fromFile)) {
                //System.out.println("File doesn't exist? " + fromFile);
                return false;
            }

            // if toFile parent folder doesn't exist, create it.
            Path parent = toFile.getParent();
            if(parent!=null){
                if(Files.notExists(parent)){
                    Files.createDirectories(parent);
                }
            }

            // default - if toFile exist, throws FileAlreadyExistsException
            try {
                Files.copy(fromFile, toFile);
            }catch (Exception e){
              return false;
            }
            return true;
    }

    /**
     * Clear console.
     */
    public static void clearConsole(){
        for (int i = 0; i < 50; ++i) System.out.println();
    }
}
