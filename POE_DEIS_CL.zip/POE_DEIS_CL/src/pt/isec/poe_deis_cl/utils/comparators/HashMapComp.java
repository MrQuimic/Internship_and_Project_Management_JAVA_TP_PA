package pt.isec.poe_deis_cl.utils.comparators;

import pt.isec.poe_deis_cl.utils.Input;
import java.util.*;

import static java.util.stream.Collectors.toMap;

/**
 * Class description:
 * <br>
 * Comparators that allow to use order in the data outputs
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class HashMapComp {

    /**
     * Long sort by comparator hash map.
     *
     * @param unsortMap the unsort map
     * @return the hash map
     */
    public static HashMap<Long, String> longSortByComparator(HashMap<Long, String> unsortMap) {

        List<Map.Entry<Long, String>> list = new LinkedList<Map.Entry<Long, String>>(
                unsortMap.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<Long, String>>() {
            public int compare(Map.Entry<Long, String> o1, Map.Entry<Long, String> o2) {
                return Input.StringremoveAccents(o1.getValue()).compareTo(Input.StringremoveAccents(o2.getValue()));
            }
        });

        HashMap<Long, String> sortedMap = new LinkedHashMap<Long, String>();
        for (Map.Entry<Long, String> entry : list) {

            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }

    /**
     * String sort by comparator hash map.
     *
     * @param unsortMap the unsort map
     * @return the hash map
     */
    public static HashMap<String, String> stringSortByComparator(HashMap<String, String> unsortMap) {

        List<Map.Entry<String, String>> list = new LinkedList<Map.Entry<String, String>>(
                unsortMap.entrySet());

        list.sort(new Comparator<Map.Entry<String, String>>() {
            public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {

                return Input.StringremoveAccents(o1.getValue()).compareTo(Input.StringremoveAccents(o2.getValue()));
            }
        });

        HashMap<String, String> sortedMap = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }


    /**
     * Stringsor old hash map.
     *
     * @param map the map
     * @return the hash map
     */
    public static HashMap<String, String> StringsorOld(HashMap<String, String> map) {


        List<Map.Entry<String, String>> linkedlist = new LinkedList<Map.Entry<String, String>>(map.entrySet());

        linkedlist.sort((Comparator<? super Map.Entry<String, String>>) (o1, o2) -> ((Comparable) ((Map.Entry) (o1)).getValue()).compareTo(((Map.Entry) (o2)).getValue()));

        HashMap<String, String> sortedHashMap = new LinkedHashMap<String, String>();

        for (Map.Entry<String, String> entry : linkedlist) {
            sortedHashMap.put(entry.getKey(), entry.getValue());
        }
        return sortedHashMap;
    }


    /**
     * Int sort by comparator hash map.
     *
     * @param unsortMap the unsort map
     * @return the hash map
     */
    public static HashMap<String, Integer> intSortByComparator(HashMap<String, Integer> unsortMap) {

        List<Map.Entry<String, Integer>> list = new LinkedList<Map.Entry<String, Integer>>(
                unsortMap.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });
        HashMap<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
        int limit= 0;
        for (Map.Entry<String, Integer> entry : list) {
            if((limit++) == 5)
                break;
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }

}