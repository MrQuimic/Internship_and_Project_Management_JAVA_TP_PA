package pt.isec.poe_deis_cl.utils;

import java.util.Locale;

/**
 * Class description:
 * <br>
 * Class description
 * Validators for error checking
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public final class Validators {

    /**
     * Instantiates a new Validators.
     */
    public Validators() {
    }


    /**
     * Is string valid email string.
     *
     * @param email the email
     * @return the string
     */
    public static String isStringValidEmail(String email) {
       // System.out.println("validando [" + email + "]");
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);

        if (!m.matches())
            return Errors.EMAIL_ERROR.toString();

        return email;
    }

    /**
     * Is string valid proj string.
     *
     * @param proj the proj
     * @return the string
     */
    public static String isStringValidProj(String proj) {
        String ePattern = "P{1}([0-9]{3})";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(proj);

        if (!m.matches())
            return Errors.PROJ_NUM_ERROR.toString();

        return proj;
    }

    /**
     * Check valid name string.
     *
     * @param name the name
     * @return the string
     */
    public static String checkValidName(String name) {

        if (name.length() < 40)
            return name;
        else
            return Errors.NAMELIMIT_ERROR.toString();
    }

    /**
     * Is string double string.
     *
     * @param checkdouble the checkdouble
     * @return the string
     */
    public static String isStringDouble(String checkdouble) {
        String decimalPattern = "([0-9]*)\\.([0-9]*)";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(decimalPattern);
        java.util.regex.Matcher m = p.matcher(checkdouble);

        if (!m.matches())
            return Errors.DOUBLE_ERROR.toString();

        return checkdouble;
    }

    /**
     * Is string int string.
     *
     * @param checkInt the check int
     * @return the string
     */
    public static String isStringInt(String checkInt) {
        String decimalPattern = "([0-9]*)";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(decimalPattern);
        java.util.regex.Matcher m = p.matcher(checkInt);

        if (!m.matches())
            return Errors.INT_ERROR.toString();

        return checkInt;
    }

    /**
     * Is string boolean string.
     *
     * @param checkboolean the checkboolean
     * @return the string
     */
    public static String isStringBoolean(String checkboolean) {
        String decimalPattern = "true|false";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(decimalPattern);
        java.util.regex.Matcher m = p.matcher(checkboolean);

        if (!m.matches())
            return Errors.BOOLEAN_ERROR.toString();

        return checkboolean;
    }

    /**
     * Check valid grade string.
     *
     * @param grade the grade
     * @return the string
     */
    public static String checkValidGrade(String grade) {
        grade = isStringDouble(grade); //Checks valid double format
        if (!grade.equals(Errors.DOUBLE_ERROR.toString())) {
            double grade2 = Double.parseDouble(grade);
            if (grade2 >= 0 && grade2 <= 1) //checks if it is between 0 and 1
                grade = isStringDouble(grade);
            else
                grade = Errors.OUTOFBOUNDS_ERROR.toString();
        }
        return grade;
    }


    /**
     * Check valid branch string.
     *
     * @param branch the branch
     * @return the string
     */
    public static String checkValidBranch(String branch) {
        if (branch.toUpperCase(Locale.ROOT).matches("DA|SI|RAS"))
            return branch.toUpperCase();
        return Errors.BRANCH_ERROR.toString();
    }

    /**
     * Check valid course string.
     *
     * @param course the course
     * @return the string
     */
    public static String checkValidCourse(String course) {
        if (course.toUpperCase(Locale.ROOT).matches("LEI|LEI-PL|LEI-CE"))
            return course.toUpperCase(Locale.ROOT);
        return Errors.COURSE_ERROR.toString();
    }

}
