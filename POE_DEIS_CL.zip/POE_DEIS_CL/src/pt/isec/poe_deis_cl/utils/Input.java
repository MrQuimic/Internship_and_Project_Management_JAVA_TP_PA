package pt.isec.poe_deis_cl.utils;

import java.io.PrintStream;
import java.text.Normalizer;
import java.util.*;

/**
 * Class description:
 * <br>
 * Class description
 * Some useful functions for inputs
 * Like the PAinput used during classes but changed to better suit our needs
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public final class Input {
    private static Scanner sc;

    static {
        resetScanner();
    }

    private Input() {
    }

    /**
     * Reset scanner.
     */
    public static void resetScanner() {
        sc = new Scanner(System.in);
    }


    /**
     * Choose option int.
     *
     * @param title   the title
     * @param options the options
     * @return the int
     */
    public static int chooseOptionZeroOff(String title, String... options) {
        int option = -1;

        do {
            if (title != null) {
                PrintStream var10000 = System.out;
                String var10001 = System.lineSeparator();
                var10000.print(var10001 + title);
            }

            System.out.println();

            for (int i = 0; i < options.length; ++i) {

                if (options[i].startsWith("0")) { // add invisible option
                    continue;
                }
                if (options[i].startsWith("⇢ ")) // add invisible option
                    System.out.printf("     %s\n", options[i]);
                else
                    System.out.printf("%3d ⇾ %s\n", i + 1, options[i]);
            }


            System.out.print("\nOption: ");

            if (sc.hasNextInt()) {
                option = sc.nextInt();
                if (option == 991)  //debug open phase
                    return option;
            }
            if (option < 1 || option > options.length) {
                Utils.errorPrint(Errors.INDEX_ERROR.getError() + "Out of Bounds\n");
            }
            sc.nextLine();


        }
        while (option < 1 || option > options.length) ;

        return option;
    }

    /**
     * Choose option Alternative.
     *
     * @param title   the title
     * @param options the options
     * @return the int
     */
    public static int chooseOptionAlternative(String title, String... options) {
        int option = -1;
        int j = 0, opt=0;
        HashMap<Integer, Integer> stdChoosen;
        do {
            if (title != null) {
                PrintStream var10000 = System.out;
                String var10001 = System.lineSeparator();
                var10000.print(var10001 + title);
            }

            System.out.println();
            stdChoosen = new HashMap<>();
            j=0;
            for (int i = 0; i < options.length; ++i, ++j) {

                if (options[i].startsWith("_")){// add invisible option
                    j--;
                    continue;
                }else {
                    if (options[i].startsWith("⇢ ")) // add invisible option
                        System.out.printf("     %s\n", options[i]);
                    else
                        System.out.printf("%3d ⇾ %s\n", j + 1, options[i]);
                    stdChoosen.put(j + 1, i + 1);
                }
            }


            System.out.print("\nOption: ");
            if (sc.hasNextInt()) {
                opt = sc.nextInt();
                if (opt == 991)  //debug open phase
                    return opt;
            }

            for (Integer key : stdChoosen.keySet()) {
                if (opt == key) {
                    option = stdChoosen.get(key);
                }
            }

            if (option < 1 || option > options.length) {
                Utils.errorPrint(Errors.INDEX_ERROR.getError() + "Out of Bounds\n");
            }
            sc.nextLine();



        }
        while (option < 1 || option > options.length) ;

        return option;
    }

    /**
     * Choose option no breaks int.
     *
     * @param title   the title
     * @param options the options
     * @return the int
     */
    public static int chooseOptionNoBreaksChangeOptNum(String title, String... options) {
        int option = -1;
        int j = 0, opt=0;
        HashMap<Integer, Integer> stdChoosen;

        do {
            if (title != null) {
                PrintStream var10000 = System.out;
                String var10001 = System.lineSeparator();
                var10000.println(var10001 + title);
            }
            stdChoosen = new HashMap<>();
            j=0;
            for (int i = 0; i < options.length; ++i, ++j) {

                if (options[i].startsWith("_")){// add invisible option
                    j--;
                    continue;
                }else {
                    if (options[i].startsWith("⇢ ")) // add invisible option
                        System.out.printf("    %s", options[i]);
                    else
                        System.out.printf("%3d ⇾ %s", j+1, options[i]);

                    stdChoosen.put(j+1, i+1);
                }
            }

            System.out.print("Option: ");
            if (sc.hasNextInt()) {
                opt = sc.nextInt();
            }

            for (Integer key : stdChoosen.keySet()) {
                if (opt == key) {
                    option = stdChoosen.get(key);
                }
            }

            if (option < 1 || option > options.length){
                Utils.errorPrint(Errors.INDEX_ERROR.getError() + "Out of Bounds\n");
            }

            sc.nextLine();
        } while (option < 1 || option > options.length);
        System.out.println();
        return option;
    }

    /**
     * Choose option no breaks int.
     *
     * @param title   the title
     * @param options the options
     * @return the int
     */
    public static int chooseOptionNoBreaks(String title, String... options) {
        int option = -1;

        do {
            if (title != null) {
                PrintStream var10000 = System.out;
                String var10001 = System.lineSeparator();
                var10000.println(var10001 + title);
            }

            for (int i = 0; i < options.length; ++i) {

                if (options[i].startsWith("_")) {// add invisible option
                    continue;
                } else {
                    if (options[i].startsWith("⇢ ")) // add invisible option
                        System.out.printf("    %s", options[i]);
                    else
                        System.out.printf("%3d ⇾ %s", i + 1, options[i]);
                }
            }


            System.out.print("Option: ");
            if (sc.hasNextInt()) {
                option = sc.nextInt();
            }


            if (option < 1 || option > options.length) {
                Utils.errorPrint(Errors.INDEX_ERROR.getError() + "Out of Bounds\n");
            }

            sc.nextLine();
        } while (option < 1 || option > options.length);



        System.out.println();
        return option;
    }


    /**
     * Stringremove accents string.
     *
     * @param text the text
     * @return the string
     */
    public static String StringremoveAccents(String text) {
        return text == null ? null : Normalizer.normalize(text, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }


}

