package pt.isec.poe_deis_cl.model.fsm;

import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import pt.isec.poe_deis_cl.model.data.DGeneral;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Class description:
 * <br>
 * GPEStateAdapter - State adapter
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
abstract public class GpeStateAdapter implements IState {

    /**
     * The Context.
     */
    protected GpeContext context;


    /**
     * The Data.
     */
    protected DGeneral data;

    /**
     * Instantiates a new Gpe state adapter.
     *
     * @param context the context
     * @param data    the data
     */
    protected GpeStateAdapter(GpeContext context, DGeneral data) {
        this.context = context;
        this.data = data;
    }

    public int manualInsertCand(String number, String proposals){return  1;}


    public int manualInsert(String number, String proposals){
        return 1;
    }

    public HashSet<Long> hashPropAssigned(){return null;}

    public HashMap<String, ArrayList<Object>> consultMode(int opc){return null; }


    /**
     * Change state.
     *
     * @param state the state
     */
    protected void changeState(GpeState state) {
        this.context.changeState(state.createState(this.context, this.data));
    }

    public String consult(int column, String filter) {
        return context.consult(column, filter);
    }

    public boolean edit(String id) {
        return false;
    }

    public boolean editStudents(long id, String capName, String mail, String course, String branch, double grade, boolean internship) {
        return false;
    }

    public void resetFilter(){
        data.resetFilter();
    }

    public boolean manualInsert(Long stdID,String proposal){
        return false;
    }

    public void setPhase(int p) {
        data.setPhase(p);
    }

    public boolean editTeachers(String mail, String capName) {
        return false;
    }

    public boolean editCandidatures(long id, HashSet<String> newProjs) {
        return false;
    }

    public boolean editProposals(String id, ArrayList<Object> newProposals) {
        return false;
    }

    public String editAdvisors(String proposal,String Tmail)  {
        return null;
    }
    public boolean insert(String nameFile) {
        return false;
    }

    public boolean export(String nameFile) {
        return false;
    }

    public boolean exportDelete() {
        return false;
    }

    public boolean delete(String id) {
        return false;
    }

    public boolean isEmpty(){ return false;}

    public boolean deleteAll() {
        return false;
    }
    public boolean refreshState() {
        return false;
    }

    /**
     * Manual insert student boolean.
     *
     * @param id         the id
     * @param name       the name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the boolean
     */
    public boolean manualInsertStudent(long id, String name, String mail, String course, String branch, double grade, boolean internship) {
        return false;
    }

    public int  manualAddStudent(String id, String name, String mail, String course, String branch, String grade, String internship){
        return 1;
    }


    public boolean advancePhase() {
        return false;
    }

    public boolean previousPhase() {
        return false;
    }

    public boolean closePhase() {
        return false;
    }

    /**
     * Increment close fase int.
     *
     * @return the int
     */
    public int incrementClosePhase() {
       return data.incrementCloseFase();
    }


    public boolean f1_students() {
        return false;
    }

    public boolean f1_propProj() {
        return false;
    }

    public boolean f1_teachers() {
        return false;
    }

    public boolean containsId(long idNum) {
            return false;
        }

    public String containsMail(String mail){
        return null;
    }

    public String containsStuMail(long idNum, String mail){
        return null;
    }


    public boolean getDataPossible(GpeState state){
        return false;
    }

    public boolean checkEmptyData(){
        return false;
    }

    public boolean filterIsActive(int index){
        return false;
    }

    public String ToStringSelector(int opc){
        return null;
    }

    public String toStringfilter(int i) {
            return null;
        }

    public String filter(int filterChoice ) {
        return null;
    }
    public String listStudents(int typeOFlist){
        return null;
    }

    public void addManualadvisor(String proposal, String email) {}

    public XYChart.Series<String,Integer> barChartInfo(int opc)
    {
        return null;
    }

    public String advisor_teacherSpecifStatus(String teacherMail){ return null;}

    public void atributeProposals() {}
    public void atributeAutoProposals() {}

    public boolean addAutoDesignedAdvisor() {
        return false;
    }

    public String lisTWithAllProposalsAssigned(){
        return null;
    }

    public String listPropAvailable(){
        return null;
    }

    public String listStdWithoutAssigAndCand(){
        return null;
    }

    public String listStdWithProposalsAssigned(){
        return null;
    }

    public ArrayList<Object> attributedProposals(){
        return data.D3P.atributeProposals();
    }

    public String advisorsGeneralStatus(){
        return null;
    }

    public int getPhase(){
        return 0;
    }

    public int getClosePhase(){
        return 0;
    }

    public String getList(int i, String s){
        return null;
    }

    public String getStudent(long std) {
       return null;
    }

    public String stdCand(long std){
        return null;
    }

    public GpeState getState() {
        return null;
    }

    public boolean save() {
        return false;
    }
    public boolean load() {
            return false;
        }

    public boolean undo() {
        return false;
    }

    public boolean redo() {
        return false;
    }

    public boolean saveUndo() {
        return false;
    }

    public boolean saveRedo() {
        return false;
    }

    public boolean checkOneEmptyP1() {
        return false;
    }

    public ObservableList<PieChart.Data> pieChartInfo(int opc) {
        return data.D5C.pieChartInfo(opc);
    }

    public int getBottomInfo(int opc) {
        return 0;
    }


}


