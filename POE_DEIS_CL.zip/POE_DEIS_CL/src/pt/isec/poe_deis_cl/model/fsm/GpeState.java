package pt.isec.poe_deis_cl.model.fsm;

import pt.isec.poe_deis_cl.model.data.DGeneral;
import pt.isec.poe_deis_cl.model.fsm.state.*;

import java.io.Serializable;

/**
 * Class description:
 * <br>
 * GPEState - Enum with all the states
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public enum GpeState {
    /**
     * Start gpe state.
     */
    START,
    /**
     * Teachers gpe state.
     */
    TEACHERS,
    /**
     * Students gpe state.
     */
    STUDENTS,
    /**
     * Proposalsprojects gpe state.
     */
    PROPOSALS,
    /**
     * Candidature gpe state.
     */
    CANDIDATURE,
    /**
     * Proposals gpe state.
     */
    ASSIGNEDPROPOSALS,
    /**
     * Advisors gpe state.
     */
    ADVISORS,
    /**
     * Consult gpe state.
     */
    CONSULT;
    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;

    private GpeState() {

    }

    /**
     * Create state state.
     *
     * @param context the context
     * @param data    the data
     * @return the state
     */
    public IState createState(GpeContext context, DGeneral data) {
        IState varNextState;

        switch (this) {

            case TEACHERS:
                varNextState = new P1_Teachers(context, data);
                break;
            case STUDENTS:
                varNextState = new P1_Students(context, data);
                break;
            case PROPOSALS:
                varNextState = new P1_ProposalsProjects(context, data);
                break;
            case CANDIDATURE:
                varNextState = new P2_Candidature(context, data);
                break;
            case ASSIGNEDPROPOSALS:
                varNextState = new P3_Proposals(context, data);
                break;
            case ADVISORS:
                varNextState = new P4_Advisors(context, data);
                break;
            case CONSULT:
                varNextState = new P5_Consult(context, data);
                break;
            default:
                varNextState = null;
        }

        return varNextState;
    }
}



