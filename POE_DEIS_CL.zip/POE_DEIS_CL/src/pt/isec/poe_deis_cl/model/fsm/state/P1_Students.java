
package pt.isec.poe_deis_cl.model.fsm.state;

import pt.isec.poe_deis_cl.model.data.DGeneral;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.GpeStateAdapter;

import java.util.ArrayList;
import java.util.Map;

/**
 * Class description:
 * <br>
 * Phase 1 Students - data retrieval phase
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class P1_Students extends GpeStateAdapter {

    /**
     * Instantiates a new P 1 students.
     *
     * @param context the context
     * @param data    the data
     */
    public P1_Students(GpeContext context, DGeneral data) {
        super(context, data);
            }


    public String consult(int column, String filter) {

        return data.D1S.toString(column, filter);
    }

    public boolean insert(String nameFile) {

        return data.D1S.AddData(nameFile);
    }


    public boolean editStudents(long id, String capName, String mail, String course, String branch, double grade, boolean internship) {

        return data.D1S.editStudent(id, capName, mail, course, branch, grade, internship);
    }

    public boolean export(String nameFile) {
        data.D1S.exportData(nameFile);
        return true;
    }

    /**
     * Get data map.
     *
     * @return the map
     */
    public Map<Long, ArrayList<Object>> getData(){
        return (Map<Long, ArrayList<Object>>) data.getData(GpeState.STUDENTS);
    }


    public boolean exportDelete() {

        data.D1S.exportDelete();
        return true;
    }

    public int  manualAddStudent(String id, String name, String mail, String course, String branch, String grade, String internship){
        return data.D1S.manualAddStudent( id,  name,  mail,  course,  branch,  grade,  internship);
    }


    public boolean delete(String id) {
        return data.D1S.delete(id);
    }

    public boolean deleteAll() {
        data.D1S.deleteAll();
        return true;
    }



    public boolean refreshState() {  //All changes need to be done with a change of state
        this.changeState(GpeState.STUDENTS);
        return true;
    }

    public boolean advancePhase() {
        this.setPhase(getPhase()+1);
        this.changeState(GpeState.CANDIDATURE);
        return true;
    }

    public boolean closePhase() {
            data.incrementCloseFase();
            this.changeState(GpeState.CANDIDATURE);
            return true;
        }




/*
    public int incrementClosePhase() {
        return data.incrementCloseFase();
    }
*/


    /**
     * Sets fase.
     *
     * @param
     */

    /**
     * Sets fase.
     *
     * @param
     */
    public void setPhase(int p) {
        data.setPhase(p);
    }

    /**
     * Sets close fase.
     *
     * @param f the f
     */
    public void setClosePhase(int f) {
        data.setClosePhase(f);
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return data.getPhase();
    }


    /**
     * Get data map.
     *
     * @param state the state
     * @return the map
     */
    public Map<?, ?>  getData(GpeState state){
        return  data.getData(state);
    }

    public boolean getDataPossible(GpeState state){
        return  data.getNotDataPossible(state);
    }

    public boolean checkEmptyData() {

        if (data.D3P.atributeProposals().isEmpty())
            return true;
        return false;


    }


    public boolean containsId(long idNum) {

        return data.D1S.containsId(idNum);
    }

    public int getBottomInfo(int opc) {
        return data.getBottomInfo(opc);
    }

    @Override
    public GpeState getState() {
        return GpeState.STUDENTS;
    }
}
