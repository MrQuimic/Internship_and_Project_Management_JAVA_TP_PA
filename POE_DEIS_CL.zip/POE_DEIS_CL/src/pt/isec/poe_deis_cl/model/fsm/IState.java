package pt.isec.poe_deis_cl.model.fsm;

import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Class description:
 * <br>
 * FSM
 * Istate - Combines stages and manages modes
 * <p>
 * IState interface with the
 * methods corresponding to transitions between states
 * • Also include getState method that allows returning the
 * current state (constant defined by enum)
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public interface IState{


    /**
     * Consult string.
     *
     * @param column the column
     * @param filter the toStringfilter
     * @return the string
     */
    String consult(int column, String filter);

    /**
     * Edit boolean.
     *
     * @param id the id
     * @return the boolean
     */
    boolean edit(String id);

    /**
     * Manual add student int.
     *
     * @param id         the id
     * @param name       the name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the int
     */
    int manualAddStudent(String id, String name, String mail, String course, String branch, String grade, String internship);

    /**
     * Export boolean.
     *
     * @return the boolean
     */
    /**
     * Edit students boolean.
     *
     * @param id         the id
     * @param capName    the cap name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the boolean
     */
    boolean editStudents(long id, String capName, String mail, String course, String branch, double grade, boolean internship);

    /**
     * Manual insert cand int.
     *
     * @param number    the number
     * @param proposals the proposals
     * @return the int
     */
    int manualInsertCand(String number, String proposals);

    /**
     * Edit teachers boolean.
     *
     * @param mail    the mail
     * @param capName the cap name
     * @return the boolean
     */
    boolean editTeachers(String mail, String capName);

    /**
     * Manual insert int.
     *
     * @param number    the number
     * @param proposals the proposals
     * @return the int
     */
    public int manualInsert(String number, String proposals);

    /**
     * Edit candidatures boolean.
     *
     * @param id       the id
     * @param newProjs the new projs
     * @return the boolean
     */
    boolean editCandidatures(long id, HashSet<String> newProjs);

    /**
     * Hash prop assigned hash set.
     *
     * @return the hash set
     */
    HashSet<Long> hashPropAssigned();

    /**
     * Edit proposals boolean.
     *
     * @param id         the id
     * @param newChanges the new changes
     * @return the boolean
     */
    boolean editProposals(String id, ArrayList<Object> newChanges);

    /**
     * Edit advisors string.
     *
     * @param proposal the proposal
     * @param Tmail    the tmail
     * @return the string
     */
    String editAdvisors(String proposal,String Tmail);

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    HashMap<String, ArrayList<Object>> consultMode(int opc);

    /**
     * Advisor teacher specif status string.
     *
     * @param teacherMail the teacher mail
     * @return the string
     */
    String advisor_teacherSpecifStatus(String teacherMail);

    /**
     * Manual insert boolean.
     *
     * @param stdID    the std id
     * @param proposal the proposal
     * @return the boolean
     */
    boolean manualInsert(Long stdID,String proposal);

    /**
     * Bar chart info xy chart . series.
     *
     * @param opc the opc
     * @return the xy chart . series
     */
    XYChart.Series<String,Integer> barChartInfo(int opc);

    /**
     * Insert boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    boolean insert(String nameFile);

    /**
     * Export boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    boolean export(String nameFile);

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    boolean exportDelete();

    /**
     * Delete boolean.
     *
     * @param id the id
     * @return the boolean
     */
    boolean delete(String id);

    /**
     * Is empty boolean.
     *
     * @return the boolean
     */
    public boolean isEmpty();

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    boolean deleteAll();

    /**
     * Refresh state boolean.
     *
     * @return the boolean
     */
    boolean refreshState();

    /**
     * Advance phase boolean.
     *
     * @return the boolean
     */
    boolean advancePhase();

    /**
     * Previous phase boolean.
     *
     * @return the boolean
     */
    boolean previousPhase();

    /**
     * Close phase boolean.
     *
     * @return the boolean
     */
    boolean closePhase();

    /**
     * F 1 s boolean.
     *
     * @return the boolean
     */
    boolean f1_students();

    /**
     * F 1 t boolean.
     *
     * @return the boolean
     */
    boolean f1_teachers();

    /**
     * F 1 p boolean.
     *
     * @return the boolean
     */
    boolean f1_propProj();

    /**
     * Check tie stu hash set.
     *
     * @return the hash set
     */

    /**
     * Contains id boolean.
     *
     * @param idNum the id num
     * @return the boolean
     */
    boolean containsId(long idNum);

    /**
     * Contains mail string.
     *
     * @param mail the mail
     * @return the string
     */
    String containsMail(String mail);

    /**
     * Contains stu mail string.
     *
     * @param idNum the id num
     * @param mail  the mail
     * @return the string
     */
    String containsStuMail(long idNum, String mail);

    /**
     * Gets data possible.
     *
     * @param state the state
     * @return the data possible
     */
    boolean getDataPossible(GpeState state);

    /**
     * Check empty data boolean.
     *
     * @return the boolean
     */
    boolean checkEmptyData();

    /**
     * Filter is active boolean.
     *
     * @param index the index
     * @return the boolean
     */
    boolean filterIsActive(int index);

    /**
     * Reset filter.
     */
    void resetFilter();

    /**
     * To string selector string.
     *
     * @param opc the opc
     * @return the string
     */
    String ToStringSelector(int opc);

    /**
     * To stringfilter string.
     *
     * @param i the
     * @return the string
     */
    String toStringfilter(int i);

    /**
     * Filter string.
     *
     * @param filterChoice the filter choice
     * @return the string
     */
    String filter(int filterChoice);

    /**
     * Atribute proposals.
     */
    void atributeProposals();

    /**
     * Atribute auto proposals.
     */
    void atributeAutoProposals();

    /**
     * Add auto designed advisor boolean.
     *
     * @return the boolean
     */
    boolean addAutoDesignedAdvisor();

    /**
     * List students string.
     *
     * @param typeOFlist the type o flist
     * @return the string
     */
    String listStudents(int typeOFlist);

    /**
     * Add manualadvisor.
     *
     * @param proposal the proposal
     * @param email    the email
     */
    void addManualadvisor(String proposal, String email);

    /**
     * Lis t with all proposals assigned string.
     *
     * @return the string
     */
    String lisTWithAllProposalsAssigned();

    /**
     * List prop available string.
     *
     * @return the string
     */
    String listPropAvailable();

    /**
     * List std without assig and cand string.
     *
     * @return the string
     */
    String listStdWithoutAssigAndCand();

    /**
     * List std with proposals assigned string.
     *
     * @return the string
     */
    String listStdWithProposalsAssigned();

    /**
     * Attributed proposals array list.
     *
     * @return the array list
     */
    ArrayList<Object> attributedProposals();

    /**
     * Advisors general status string.
     *
     * @return the string
     */
    String advisorsGeneralStatus();

    /**
     * Gets list.
     *
     * @param i the
     * @param s the s
     * @return the list
     */
    String getList(int i, String s);

    /**
     * Gets state.
     *
     * @return the state
     */


    /**
     * Gets phase.
     *
     * @return the phase
     */
    int getPhase();

    /**
     * Gets phase.
     *
     * @return the phase
     */
    GpeState getState();

    /**
     * Sets phase.
     *
     * @param f the f
     */
    void setPhase(int f);

    /**
     * Gets close phase.
     *
     * @return the close phase
     */
    int getClosePhase();


    /**
     * Gets student.
     *
     * @param std the std
     * @return the student
     */
    String getStudent(long std);

    /**
     * Std cand string.
     *
     * @param std the std
     * @return the string
     */
    String stdCand(long std);

    /**
     * Save boolean.
     *
     * @return the boolean
     */
    boolean save();

    /**
     * Load boolean.
     *
     * @return the boolean
     */
    boolean load();

    /**
     * Check one empty p 1 boolean.
     *
     * @return the boolean
     */
    boolean checkOneEmptyP1();

    /**
     * Sets close phase.
     *
     * @param f the f
     */
    void setClosePhase(int f);

    /**
     * Pie chart info observable list.
     *
     * @param opc the opc
     * @return the observable list
     */
    ObservableList<PieChart.Data> pieChartInfo(int opc);


    /**
     * Gets bottom info.
     *
     * @param opc the opc
     * @return the bottom info
     */
    int getBottomInfo(int opc);

    /**
     * Save undo boolean.
     *
     * @return the boolean
     */
    boolean saveUndo();

    /**
     * Save redo boolean.
     *
     * @return the boolean
     */
    boolean saveRedo();

    /**
     * Redo boolean.
     *
     * @return the boolean
     */
    boolean redo();

    /**
     * Undo boolean.
     *
     * @return the boolean
     */
    boolean undo();
}


