package pt.isec.poe_deis_cl.model.fsm;


import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import pt.isec.poe_deis_cl.model.data.DGeneral;
import pt.isec.poe_deis_cl.model.fsm.state.*;
import pt.isec.poe_deis_cl.utils.Utils;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import static pt.isec.poe_deis_cl.utils.Utils.copyFile;

/**
 * The type Gpe context.
 */

/**
 * Class description:
 * <br>
 * GPEContext - Context
 * <br> which should include:
 * <br> • Reference to the current state
 * <br> • Create in builder
 * <br> • Reference to the data model
 * <br> • Create in builder
 * <br> • Public method that allows obtaining the current state
 * <br> • package-private method that allows changing the current state
 * <br> • Methods that forward actions/events to the active state
 * <br> • Set of methods to obtain the necessary data for the
 * <br> interaction with the user or with the remaining modules of the program
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class GpeContext {


    /**
     * The Relative path objects.
     */
    static final String relativePath_Objects = "Resources/SavePoints/objectsSavePoint.bin";
    /**
     * The Relative path objects undo.
     */
    static final String relativePath_ObjectsUndo = "Resources/SavePoints/UndoSavePoint.bin";

    /**
     * The Relative path objects redo.
     */
    static final String relativePath_ObjectsRedo = "Resources/SavePoints/RedoSavePoint.bin";

    private final String pass = "199";

    /**
     * The State.
     */
    IState state;

    /**
     * The Data.
     */
    DGeneral data;


    /**
     * Instantiates a new Gpe context.
     */
    public GpeContext() {
        data  = new DGeneral();
        state = new P1_Students (this, data);}

    /**
     * Consult string.
     *
     * @param column the column
     * @param filter the filter
     * @return the string
     */
    public String consult(int column, String filter) {
        return this.state.consult(column, filter);
    }

    /**
     * Insert boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean insert(String nameFile) {
        return this.state.insert(nameFile);
    }

    /**
     * Edit students boolean.
     *
     * @param id         the id
     * @param capName    the cap name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the boolean
     */
    public boolean editStudents(long id, String capName, String mail, String course, String branch, double grade, boolean internship) {
        return this.state.editStudents(id, capName, mail, course, branch, grade, internship);
    }

    /**
     * Edit teachers boolean.
     *
     * @param mail    the mail
     * @param capName the cap name
     * @return the boolean
     */
    public boolean editTeachers(String mail, String capName) {
        return this.state.editTeachers(mail, capName);
    }

    /**
     * Edit candidatures boolean.
     *
     * @param id       the id
     * @param newProjs the new projs
     * @return the boolean
     */
    public boolean editCandidatures(long id, HashSet<String> newProjs) {
        return this.state.editCandidatures(id, newProjs);
    }

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    public HashMap<String, ArrayList<Object>> consultMode(int opc){return state.consultMode(opc); }


    /**
     * Manual insert int.
     *
     * @param number    the number
     * @param proposals the proposals
     * @return the int
     */
    public int manualInsert(String number, String proposals){return state.manualInsert(number,proposals);}

    /**
     * Edit proposals boolean.
     *
     * @param id         the id
     * @param newChanges the new changes
     * @return the boolean
     */
    public boolean editProposals(String id, ArrayList<Object> newChanges) {
        return this.state.editProposals(id, newChanges);
    }

    /**
     * Edit advisors string.
     *
     * @param proposal the proposal
     * @param Tmail    the tmail
     * @return the string
     */
    public String editAdvisors(String proposal,String Tmail) {
        return this.state.editAdvisors(proposal, Tmail);
    }

    /**
     * Assign manual proposal boolean.
     *
     * @param stdID    the std id
     * @param proposal the proposal
     * @return the boolean
     */
    public boolean assignManualProposal(Long stdID,String proposal){
        return this.state.manualInsert(stdID, proposal);
    }

    /**
     * Get data map.
     *
     * @param GpeState the gpe state
     * @return the map
     */
    public Object getData(GpeState GpeState){
        return data.getData(GpeState);
    }

    /**
     * Advisor teacher specif status string.
     *
     * @param teacherMail the teacher mail
     * @return the string
     */
    public String advisor_teacherSpecifStatus(String teacherMail){return state.advisor_teacherSpecifStatus(teacherMail);}

    /**
     * Manual add student int.
     *
     * @param id         the id
     * @param name       the name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the int
     */
    public int  manualAddStudent(String id, String name, String mail, String course, String branch, String grade, String internship){
        return state.manualAddStudent( id,  name,  mail,  course,  branch,  grade,  internship);
    }

    /**
     * Bar chart info xy chart . series.
     *
     * @param opc the opc
     * @return the xy chart . series
     */
    public XYChart.Series<String,Integer> barChartInfo(int opc){ return state.barChartInfo(opc);}

    /**
     * Export boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean export(String nameFile) {
        return this.state.export(nameFile);
    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {
        return this.state.exportDelete();
    }

    /**
     * Is empty boolean.
     *
     * @return the boolean
     */
    public boolean isEmpty(){ return this.state.isEmpty();}

    /**
     * Delete boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean delete(String id) {
        return this.state.delete(id);
    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        return this.state.deleteAll();
    }

    /**
     * Previous phase.
     */
    public void previousPhase() {
        this.state.previousPhase();
    }

    /**
     * Refresh state.
     */
    public void refreshState() {
        this.state.refreshState();
    }

    /**
     * Advance phase boolean.
     *
     * @return the boolean
     */
    public boolean advancePhase() {
        return this.state.advancePhase();
    }

    /**
     * Close phase boolean.
     *
     * @return the boolean
     */
    public boolean closePhase() {
        return this.state.closePhase();
    }


    /**
     * Gets close phase.
     *
     * @return the close phase
     */
    public int getClosePhase() {

        return data.getClosePhase();
    }



    /**
     * Sets fase.
     *
     * @param f the f
     */
    private void setPhase(int f) {
        this.state.setPhase(f);
    }

    /**
     * Sets close fase.
     *
     * @param f the f
     */
    void setClosePhase(int f) {
        this.state.setClosePhase(f);
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {

        return this.state.getPhase();
    }

    /**
     * F 1 t.
     */
    public void f1_teachers() {
        state = new P1_Teachers(this,data);
        this.state.f1_teachers();
    }

    /**
     * F 1 s.
     */
    public void f1_students() {
        state = new P1_Students(this,data);
        this.state.f1_students();
    }

    /**
     * F 1 p.
     */
    public void f1_propProj() {
        state = new P1_ProposalsProjects(this,data);
        this.state.f1_propProj();
    }

    /**
     * Contains id boolean.
     *
     * @param idNum the id num
     * @return the boolean
     */
    public boolean containsId(long idNum) {

        return this.state.containsId(idNum);
    }

    /**
     * Add manualadvisor.
     *
     * @param proposal the proposal
     * @param email    the email
     */
    public void addManualadvisor(String proposal, String email) {
        this.state.addManualadvisor(proposal, email);
    }


    /**
     * Get not data possible boolean.
     *
     * @param state the state
     * @return the boolean
     */
    public boolean getNotDataPossible(GpeState state){
        return this.state.getDataPossible(state);
    }


    /**
     * Check empty data boolean.
     *
     * @return the boolean
     */
    public boolean checkEmptyData(){
        return this.state.checkEmptyData();
    }

    /**
     * Filter is active boolean.
     *
     * @param index the index
     * @return the boolean
     */
    public boolean filterIsActive(int index){
        return this.state.filterIsActive(index);
    }

    /**
     * Reset filter.
     */
    public void resetFilter(){
        this.state.resetFilter();
    }

    /**
     * To string selector string.
     *
     * @param opc the opc
     * @return the string
     */
    public String ToStringSelector(int opc){
        return this.state.ToStringSelector(opc);
    }

    /**
     * To stringfilter string.
     *
     * @param i the
     * @return the string
     */
    public String toStringfilter(int i) {
        return this.state.toStringfilter(i);
    }

    /**
     * Filter string.
     *
     * @param filterChoice the filter choice
     * @return the string
     */
    public String filter(int filterChoice ) {
        return this.state.filter(filterChoice);
    }

    /**
     * List students string.
     *
     * @param typeOFlist the type o flist
     * @return the string
     */
    public String listStudents(int typeOFlist){
        return this.state.listStudents(typeOFlist);
    }

    /**
     * Gets state.
     *
     * @return the state
     */
    public GpeState getState() {
        return this.state.getState();
    }

    /**
     * Contains mail string.
     *
     * @param mail the mail
     * @return the string
     */
    public String containsMail(String mail){
        return this.state.containsMail(mail);
    }

    /**
     * Contains stu mail string.
     *
     * @param idNum the id num
     * @param mail  the mail
     * @return the string
     */
    public String containsStuMail(long idNum, String mail) {
        return this.state.containsStuMail(idNum, mail);
    }

    /**
     * Atribute proposals.
     */
    public void atributeProposals() {
        this.state.atributeProposals();
    }

    /**
     * Atribute auto proposals.
     */
    public void atributeAutoProposals() {
        this.state.atributeAutoProposals();
    }

    /**
     * Add auto designed advisor boolean.
     *
     * @return the boolean
     */
    public boolean addAutoDesignedAdvisor() {
        return this.state.addAutoDesignedAdvisor();
    }

    /**
     * Gets list.
     *
     * @param i the
     * @param s the s
     * @return the list
     */
    public String getList(int i, String s) {
        return this.state.getList(i, s);
    }

    /**
     * Hash prop assigned hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> hashPropAssigned(){return state.hashPropAssigned();}

    /**
     * Change State.
     *
     * @param state the state packagePrivate
     */
    void changeState(IState state) {
        this.state = state;
    }

    /**
     * List std with proposals assigned string.
     *
     * @return the string
     */
    public String listStdWithProposalsAssigned() {
        return this.state.listStdWithProposalsAssigned();
    }

    /**
     * List std without assig and cand string.
     *
     * @return the string
     */
    public String listStdWithoutAssigAndCand() {
        return this.state.listStdWithoutAssigAndCand();
    }

    /**
     * List prop available string.
     *
     * @return the string
     */
    public String listPropAvailable() {
        return this.state.listPropAvailable();
    }

    /**
     * Lis t with all proposals assigned string.
     *
     * @return the string
     */
    public String lisTWithAllProposalsAssigned() {
        return this.state.lisTWithAllProposalsAssigned();
    }

    /**
     * Attributed proposals array list.
     *
     * @return the array list
     */
    public ArrayList<Object> attributedProposals(){
        return this.state.attributedProposals();
    }
/*
    public void save(){
        return this.state.attributedProposals();
    }

    public void load(){
        return this.state.attributedProposals();
    }
    */

    /**
     * Advisors general status string.
     *
     * @return the string
     */
    public String advisorsGeneralStatus() {
        return this.state.advisorsGeneralStatus();
    }

    /**
     * Gets student.
     *
     * @param std the std
     * @return the student
     */
    public String getStudent(long std) {
        return this.state.getStudent(std);
    }

    /**
     * Std cand string.
     *
     * @param std the std
     * @return the string
     */
    public String stdCand(long std){
        return this.state.stdCand(std);
    }

    /**
     * Admin boolean.
     *
     * @param opc     the opc
     * @param passInt the pass int
     * @return the boolean
     */
    public boolean admin(int opc, String passInt) {
        if(!passInt.equals(pass)) {
            return false;
        }
        if(opc == 1){
            state = new P1_Students (this, data);
            setPhase(1);
            setClosePhase(0);
        }
        else
            setClosePhase(4);


        return true;
    }


    /**
     * Change phases boolean.
     *
     * @param closeFaseI the close fase i
     * @return the boolean
     */
    boolean ChangePhases(int closeFaseI) {
        int f1 = closeFaseI + 1;
        state = new P1_Students (this, data);
        data.setPhase(1);
        data.setClosePhase(0);

        if (f1 >= 0) {
            for (int i = 1; i <= closeFaseI; i++) {
                closePhase(); //closed phase and increments current phase
            }
        }

        return true;
    }

    /**
     * Clear data boolean.
     *
     * @return the boolean
     */
    public boolean ClearData() {

        data.deleteAll();
        state = new P1_Students (this, data);
        //data = new DGeneral();
        Utils.removePoints("objectsSavePoint");

        return true;
    }


    /**
     * Save boolean.
     *
     * @return the boolean
     */
    public boolean save() {



        try (ObjectOutputStream oos =
                     new ObjectOutputStream(
                             new FileOutputStream(relativePath_Objects))) {

            oos.writeObject(data);

        } catch (Exception e) {
            Utils.errorPrint("Error saving data" + e);
        }


        return true;
    }

    /**
     * Load data teachers.
     *
     * @return the data teachers
     */
    public boolean load() {


        try (
                ObjectInputStream ois =
                        new ObjectInputStream(
                                new FileInputStream(relativePath_Objects))) {


            DGeneral s1 = (DGeneral) ois.readObject();
            data.setData(s1);
            ChangePhases(data.getClosePhase());

            return true;

        } catch (
                Exception e) {
            // Utils.errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
        }
        return false;
    }


    /**
     * Check empty data boolean.
     *
     * @return the boolean
     */
    public  boolean checkEmpty() {
        return checkEmptyDataAllP1()
                && data.getNotDataPossible(GpeState.CANDIDATURE)
                && data.getNotDataPossible(GpeState.ASSIGNEDPROPOSALS)
                && data.getNotDataPossible(GpeState.ADVISORS)
                && (getPhase() == 1) && (getClosePhase() == 0) && getState().equals(GpeState.STUDENTS);
    }

    /**
     * Check empty data all p 1 boolean.
     *
     * @return the boolean
     */
    public boolean checkEmptyDataAllP1() {
        return data.getNotDataPossible(GpeState.TEACHERS)
                && data.getNotDataPossible(GpeState.STUDENTS)
                && data.getNotDataPossible(GpeState.PROPOSALS);
    }

    /**
     * Check one empty p 1 boolean.
     *
     * @return the boolean
     */
    public boolean checkOneEmptyP1() {
        return data.getNotDataPossible(GpeState.TEACHERS)
                || data.getNotDataPossible(GpeState.STUDENTS)
                || data.getNotDataPossible(GpeState.PROPOSALS);
    }

    /**
     * Pie chart info observable list.
     *
     * @param opc the opc
     * @return the observable list
     */
    public ObservableList<PieChart.Data> pieChartInfo(int opc) {
        return state.pieChartInfo(opc);
    }


    /**
     * Gets bottom info.
     *
     * @param opc the opc
     * @return the bottom info
     */
    public int getBottomInfo(int opc) {
        return this.state.getBottomInfo(opc);
    }


    /**
     * Save boolean.
     *
     * @return the boolean
     */
    public boolean saveUndo() {
        if(!copyFile(relativePath_ObjectsUndo, relativePath_ObjectsRedo))
            copyFile(relativePath_Objects, relativePath_ObjectsUndo);

        try (ObjectOutputStream oos =
                     new ObjectOutputStream(
                             new FileOutputStream(relativePath_ObjectsUndo))) {

            oos.writeObject(data);

        } catch (Exception e) {
            Utils.errorPrint("Error saving data" + e);
        }


        return true;
    }


    /**
     * Save redo boolean.
     *
     * @return the boolean
     */
    public boolean saveRedo() {
        if(!copyFile(relativePath_ObjectsRedo, relativePath_ObjectsUndo))
            copyFile(relativePath_Objects, relativePath_ObjectsRedo);

        try (ObjectOutputStream oos =
                     new ObjectOutputStream(
                             new FileOutputStream(relativePath_ObjectsRedo))) {

            oos.writeObject(data);

        } catch (Exception e) {
            Utils.errorPrint("Error saving data" + e);
        }


        return true;
    }

    /**
     * Redo boolean.
     *
     * @return the boolean
     */
    public boolean redo() {
        saveUndo();


        try (
                ObjectInputStream ois =
                        new ObjectInputStream(
                                new FileInputStream(relativePath_ObjectsRedo))) {


           DGeneral s1 = (DGeneral) ois.readObject();
          data.setData(s1);
          //  ChangePhases(data.getClosePhase());

            return true;

        } catch (
                Exception e) {
            // Utils.errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
        }
        return false;
    }

    /**
     * Undo boolean.
     *
     * @return the boolean
     */
    public boolean undo() {
        saveRedo();
        try (
                ObjectInputStream ois =
                        new ObjectInputStream(
                                new FileInputStream(relativePath_ObjectsUndo))) {


            DGeneral s1 = (DGeneral) ois.readObject();
            data.setData(s1);
          //ChangePhases(data.getClosePhase());

            return true;

        } catch (
                Exception e) {
            // Utils.errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e);
        }
        return false;
    }


}




