package pt.isec.poe_deis_cl.model.fsm.state;

import pt.isec.poe_deis_cl.model.data.*;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.GpeStateAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;


/**
 * Class description:
 * <br>
 * Phase 3 - Proposals attribution phase
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class P3_Proposals extends GpeStateAdapter {
    /**
     * Instantiates a new P 3 proposals.
     *
     * @param context the context
     * @param data    the data
     */
    public P3_Proposals(GpeContext context, DGeneral data) {
        super(context, data);
    }

    public String consult(int column, String filter) {

        return data.D3P.toString();
    }

    public boolean insert(String nameFile) {
        data.D3P.atributeProposalsRemain();
        return data.D3P.atributeAutoProposals();
    }

    public int manualInsert(String stdID,String proposal){
        return data.D3P.manualAddAssignment(stdID,proposal);
    }

    public boolean export(String nameFile) {
        data.D3P.exportData(nameFile);
        return true;
    }

    public boolean delete(String id) {
        return data.D3P.delete(id);
    }

    public boolean exportDelete() {

        data.D3P.exportDelete();
        return true;
    }

    public HashMap<String, ArrayList<Object>> consultMode(int opc){return data.D3P.consultMode(opc); }

    /**
     * Check tie stu hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> checkTieStu() {

        return this.checkTieStu();
    }

    public boolean refreshState() {
        this.changeState(GpeState.ASSIGNEDPROPOSALS);
        return true;
    }

    public boolean previousPhase() {
        this.setPhase(getPhase()-1);
        this.changeState(GpeState.CANDIDATURE);
        return true;
    }


    public boolean advancePhase() {
        this.setPhase(getPhase()+1);
        this.changeState(GpeState.ADVISORS);
        return true;
    }

    public boolean closePhase() {
        if (!data.getNotDataPossible(GpeState.ASSIGNEDPROPOSALS)) {
            data.incrementCloseFase();
            this.changeState(GpeState.ADVISORS);
            return true;
        }else{
            return false;
        }
    }

/*
    /**
     * Increment close fase int.
     *
     * @param state the state
     * @return the int
     * /
    public int incrementCloseFase(IState state) {
        return data.incrementCloseFase();
    }

*/
    /**
     * Sets fase.
     *
     * @param
     */

    /**
     * Sets close fase.
     *
     * @param f the f
     */
    public void setClosePhase(int f) {
        data.setClosePhase(f);
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return data.getPhase();
    }


    /**
     * Get data map.
     *
     * @param state the state
     * @return the map
     */
    public Map<?, ?> getData(GpeState state){
        return  data.getData(state);
    }

    public boolean getDataPossible(GpeState state){
        return  data.getNotDataPossible(state);
    }

    public boolean checkEmptyData() {

        if (data.D3P.atributeProposals().isEmpty())
            return true;
        return false;


    }

    public boolean filterIsActive(int index){
        return data.D3P.filterIsActive(index);
    }


    public String filter(int filterChoice ) {
        return data.D3P.filter(filterChoice);
    }

    public void atributeProposals(){data.D3P.atributeProposals();}

    public void atributeAutoProposals() {
        data.D3P.atributeAutoProposals();
    }

    public String listStudents(int typeOFlist) {
        return data.D3P.listStudents(typeOFlist);
    }


    public String stdCand(long std){
        return data.D2C.stdCand(std);
    }

    public String getStudent(long std) {
        return data.D1S.getStudent(std);
    }

    public int getBottomInfo(int opc) {
        return data.getBottomInfo(opc);
    }

    @Override
    public GpeState getState() {
        return GpeState.ASSIGNEDPROPOSALS;
    }



}

