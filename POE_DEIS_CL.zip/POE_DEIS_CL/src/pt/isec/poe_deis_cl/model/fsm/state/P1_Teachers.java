
package pt.isec.poe_deis_cl.model.fsm.state;

import pt.isec.poe_deis_cl.model.data.DGeneral;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.GpeStateAdapter;

import java.util.Map;

/**
 * Class description:
 * <br>
 * Phase 1 Teachers - data retrieval phase
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class P1_Teachers extends GpeStateAdapter {
    /**
     * Instantiates a new P1 teachers.
     *
     * @param context the context
     * @param data    the data
     */
    public P1_Teachers(GpeContext context, DGeneral data) {
        super(context, data);


    }

    public String consult(int column, String filter) {

        return data.D1T.toString(column, filter);
    }

    public boolean insert(String nameFile) {
        return data.D1T.AddData(nameFile);
    }

    public boolean editTeachers(String mail, String capName) {

        return data.D1T.editTeacher(mail, capName);
    }

    public boolean export(String nameFile) {
        data.D1T.exportData(nameFile);
        return true;
    }

    public boolean exportDelete() {

        data.D1T.exportDelete();
        return true;
    }

    public boolean delete(String id) {
        return data.D1T.delete(id);
    }

    public boolean deleteAll() {
        data.D1T.deleteAll();
        return true;
    }

    public int manualInsert(String name, String mail){
        return data.D1T.manualInsert(name,mail);
    }

    public boolean refreshState() {  //All changes need to be done with a change of state
        this.changeState(GpeState.TEACHERS);

        return true;
    }

    public boolean advancePhase() {
        this.setPhase(getPhase()+1);
        this.changeState(GpeState.CANDIDATURE);
        return true;
    }

    public boolean closePhase() {

        if (!checkOneEmptyP1()) {
            data.incrementCloseFase();
            this.changeState(GpeState.CANDIDATURE);
            return true;
        }else{
            return false;
        }
    }

/*
    /**
     * Increment close fase int.
     *
     * @param state the state
     * @return the int
     * /
    public int incrementCloseFase(IState state) {
        return data.incrementCloseFase();
    }
*/

    /**
     * Sets fase.
     *
     * @param
     */

    public String containsMail(String mail){
        return data.D1T.containsMail(mail);
    }
    /**
     * Sets close fase.
     *
     * @param f the f
     */
    public void setClosePhase(int f) {
        data.setClosePhase(f);
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return data.getPhase();
    }


    /**
     * Get data map.
     *
     * @param state the state
     * @return the map
     */
///////////////////////////////////////////////////////////////////
    public Map<?, ?> getData(GpeState state){
        return  data.getData(state);
    }
    public boolean getDataPossible(GpeState state){
        return data.getNotDataPossible(state);
    }


    public boolean checkEmptyData() {

        if (data.D3P.atributeProposals().isEmpty())
            return true;
        return false;


    }

    public int getBottomInfo(int opc) {
        return data.getBottomInfo(opc);
    }

    @Override
    public GpeState getState() {
        return GpeState.TEACHERS;
    }

}
