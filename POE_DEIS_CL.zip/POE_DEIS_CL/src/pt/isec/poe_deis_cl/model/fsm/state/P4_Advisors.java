package pt.isec.poe_deis_cl.model.fsm.state;

import pt.isec.poe_deis_cl.model.data.DGeneral;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.GpeStateAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;


/**
 * Class description:
 * <br>
 * Advisors attribution phase
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class P4_Advisors extends GpeStateAdapter {
    /**
     * Instantiates a new P 4 advisors.
     *
     * @param context the context
     * @param data    the data
     */
    public P4_Advisors(GpeContext context, DGeneral data) {
        super(context, data);
    }

    public String consult(int column, String filter) {

        return data.D4A.toString(column, filter);
    }
    public boolean export(String nameFile) {
        data.D4A.exportData(nameFile);
        return true;
    }

    public HashMap<String, ArrayList<Object>> consultMode(int opc){return data.D4A.consultMode(opc); }

    public boolean exportDelete() {

        data.D4A.exportDelete();
        return true;
    }

    public boolean deleteAll() {
        data.D4A.deleteAll();
        return true;
    }

    public boolean delete(String proposal) {
        return data.D4A.delete(proposal);
    }

    public boolean refreshState() {
        this.changeState(GpeState.ADVISORS);
        return true;
    }

    public boolean previousPhase() {
        this.setPhase(getPhase()-1);
        this.changeState(GpeState.ASSIGNEDPROPOSALS);
        return true;
    }

    public boolean advancePhase() {
        this.setPhase(getPhase()+1);
        this.changeState(GpeState.CONSULT);
        return true;
    }

    public boolean closePhase() {
        if (!data.getData(GpeState.ADVISORS).toString().isEmpty()) {
            data.incrementCloseFase();
            this.changeState(GpeState.CONSULT);
            return true;
        }else{
            return false;
        }
    }

    public String advisor_teacherSpecifStatus(String teacherMail){
        return data.D4A.advisor_teacherSpecifStatus(teacherMail);
    }

/*
     /**
     * Increment close fase int.
     *
     * @param state the state
     * @return the int
     * /
    public int incrementCloseFase(IState state) {
        return data.incrementCloseFase();
    }
*/


    /**
     * Sets fase.
     *
     * @param
     */

    /**
     * Sets close fase.
     *
     * @param f the f
     */
    public void setClosePhase(int f) {
        data.setClosePhase(f);
    }


    public String editAdvisors(String proposal,String Tmail) {
        return data.D4A.editAdvisors(proposal, Tmail);
    }
    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return data.getPhase();
    }

    /**
     * Get data map.
     *
     * @param state the state
     * @return the map
     */
    public Map<?, ?> getData(GpeState state){
        return  data.getData(state);
    }

    public boolean getDataPossible(GpeState state) {
        return data.getNotDataPossible(state);
    }

    public boolean checkEmptyData() {

        if (data.D3P.atributeProposals().isEmpty())
            return true;
        return false;


    }

    public int manualInsert(String number, String proposals){
        return data.D4A.manualInsert(number,proposals);
    }

    public boolean addAutoDesignedAdvisor() {
        return data.D4A.addAutoDesignedAdvisor();
    }

    public String getList(int i, String s) {
        return data.D4A.getList(i, s);
    }

    public String advisorsGeneralStatus() {
        return data.D5C.advisorsGeneralStatus();
    }

    public void addManualadvisor(String proposal, String email) {
        data.D4A.addManualadvisor(proposal, email);
    }

    public int getBottomInfo(int opc) {
        return data.getBottomInfo(opc);
    }

    @Override
    public GpeState getState() {
        return GpeState.ADVISORS;
    }


}