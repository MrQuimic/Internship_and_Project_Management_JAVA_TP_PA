package pt.isec.poe_deis_cl.model.fsm.state;

import pt.isec.poe_deis_cl.model.data.*;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.GpeStateAdapter;

import java.util.ArrayList;
import java.util.Map;

/**
 * Class description:
 * <br>
 * Phase 1 - Proposals and projects data retrieval phase
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class P1_ProposalsProjects extends GpeStateAdapter {
    /**
     * Instantiates a new P1 proposals projects.
     *
     * @param context the context
     * @param data    the data
     */
    public P1_ProposalsProjects(GpeContext context, DGeneral data) {
        super(context, data);

        setPhase(1);
    }

    public String consult(int column, String filter) {

        return data.D1P.toString(column, filter);
    }

    public boolean insert(String nameFile) {

        return data.D1P.AddData(nameFile);
    }



    public boolean editProposals(String id, ArrayList<Object> newChanges) {
        return data.D1P.editProposal(id, newChanges);
    }

    public boolean export(String nameFile) {
        data.D1P.exportData(nameFile);
        return true;
    }

    public boolean exportDelete() {

        data.D1P.exportDelete();
        return true;
    }


    public boolean delete(String id) {
        return data.D1P.delete(id);
    }

    public boolean deleteAll() {
        data.D1P.deleteAll();
        return true;
    }

    public boolean refreshState() {
        this.changeState(GpeState.PROPOSALS);
        return true;
    }

    public boolean advancePhase() {
        this.setPhase(getPhase()+1);
        this.changeState(GpeState.CANDIDATURE);
        return true;
    }

    public boolean closePhase() {

        if (!checkOneEmptyP1()) {
            data.incrementCloseFase();
            this.changeState(GpeState.CANDIDATURE);
            return true;
        }else{
            return false;
        }
    }

    public boolean checkEmptyData() {

        if (data.D3P.atributeProposals().isEmpty())
            return true;
        return false;


    }


    public boolean isEmpty(){
        return (data.D1S.isEmpty() || data.D1T.isEmpty());
    }
/*
    public int incrementClosePhase() {
        return data.incrementCloseFase();
    }

*/

    /**
     * Sets fase.
     *
     * @param
     */
    public void setPhase(int p) {
        data.setPhase(p);
    }

    /**
     * Sets close fase.
     *
     * @param f the f
     */
    public void setClosePhase(int f) {
        data.setClosePhase(f);
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return data.getPhase();
    }


    /**
     * Get data map.
     *
     * @param state the state
     * @return the map
     */
    public Map<?, ?> getData(GpeState state){
        return data.getData(state);
    }

    public boolean getDataPossible(GpeState state){
        return  data.getNotDataPossible(state);
    }


    public int getBottomInfo(int opc) {
        return data.getBottomInfo(opc);
    }

    @Override
    public GpeState getState() {
        return   GpeState.PROPOSALS;
    }
}
