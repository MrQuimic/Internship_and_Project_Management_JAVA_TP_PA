package pt.isec.poe_deis_cl.model.fsm.state;

/**
 * Class description:
 * Consulta
 *
 * @author Carlos Santos {@literal <a2003035578@isec.pt>}
 * @author Leonardo Sousa {@literal <a2019129243@isec.pt>}
 * @date 2022/04/05
 */

import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import pt.isec.poe_deis_cl.model.data.D5Consult;
import pt.isec.poe_deis_cl.model.data.DGeneral;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.GpeStateAdapter;
import pt.isec.poe_deis_cl.model.fsm.IState;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Class description:
 * <br>
 * Phase 5 - Consult data phase
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class P5_Consult extends GpeStateAdapter {
    /**
     * Instantiates a new P 5 consult.
     *
     * @param context the context
     * @param data    the data
     */
    public P5_Consult(GpeContext context, DGeneral data) {
        super(context, data);

    }
    public boolean export(String nameFile) {
        data.D5C.exportData(nameFile);
        return true;
    }

    public boolean exportDelete() {

        data.D5C.exportDelete();
        return true;
    }


    public boolean refreshState() {
        this.changeState(GpeState.CONSULT);
        return true;
    }

    public boolean previousPhase() {
        this.setPhase(getPhase()-1);
        this.changeState(GpeState.ADVISORS);
        return true;
    }

    public HashMap<String, ArrayList<Object>> consultMode(int opc){return data.D5C.consultMode(opc); }

    /**
     * Increment close fase int.
     *
     * @param state the state
     * @return the int
     */
    public int incrementCloseFase(IState state) {
        return data.incrementCloseFase();
    }



    /**
     * Sets fase.
     *
     * @param
     */

    /**
     * Sets close fase.
     *
     * @param f the f
     * @return
     */
    public void setClosePhase(int f) {
        data.setClosePhase(f);
    }

    public XYChart.Series<String,Integer> barChartInfo(int opc){
        return data.D5C.barChartInfo(opc);
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return data.getPhase();
    }


    public boolean closePhase() {
        return super.closePhase();
    }

    public boolean checkEmptyData() {

        if (data.D3P.atributeProposals().isEmpty())
            return true;
        return false;


    }

    public String advisor_teacherSpecifStatus(String teacherMail){
        return data.D4A.advisor_teacherSpecifStatus(teacherMail);
    }

    public String listStdWithProposalsAssigned() {
        return data.D5C.listStdWithProposalsAssigned();
    }

    public String listStdWithoutAssigAndCand() {
        return data.D5C.listStdWithoutAssigAndCand();
    }

    public String listPropAvailable() {
        return data.D5C.listPropAvailable();
    }

    public String lisTWithAllProposalsAssigned() {
        return data.D5C.lisTWithAllProposalsAssigned();
    }

    public String advisorsGeneralStatus() {
        return data.D5C.advisorsGeneralStatus();
    }

    public ObservableList<PieChart.Data> pieChartInfo(int opc) {
        return data.D5C.pieChartInfo(opc);
    }

    public int getBottomInfo(int opc) {
        return data.getBottomInfo(opc);
    }

    @Override
    public GpeState getState() {
        return GpeState.CONSULT;
    }

}