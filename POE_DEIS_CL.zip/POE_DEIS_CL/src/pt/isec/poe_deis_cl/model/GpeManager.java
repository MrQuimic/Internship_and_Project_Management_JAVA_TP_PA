package pt.isec.poe_deis_cl.model;

import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.model.fsm.state.P1_Students;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;
import pt.isec.poe_deis_cl.ui.gui.Panes.TableP1Students;
import pt.isec.poe_deis_cl.utils.Utils;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Gpe manager.
 */
public class GpeManager {
    private GpeContext fsm;
    /**
     * The Pcs.
     */
    PropertyChangeSupport pcs;
    /**
     * The Table update.
     */
    PropertyChangeSupport tableUpdate;

    /**
     * The Close update.
     */
    PropertyChangeSupport closeUpdate;
    /**
     * The Undo redo.
     */
    PropertyChangeSupport UndoRedo;

    /**
     * The Menu opt.
     */
    MenuOpt menuOpt;


    /**
     * Instantiates a new Gpe manager.
     */
    public GpeManager() {
        menuOpt = MenuOpt.STARTMENU;

        fsm = new GpeContext();
        pcs = new PropertyChangeSupport(this);
        tableUpdate = new PropertyChangeSupport(this);
        closeUpdate = new PropertyChangeSupport(this);
        UndoRedo = new PropertyChangeSupport(this);
    }

    /**
     * Add property change listener.
     *
     * @param listener the listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    /**
     * Addclose update listener.
     *
     * @param listener the listener
     */
    public void addcloseUpdateListener(PropertyChangeListener listener) {closeUpdate.addPropertyChangeListener(listener);}

    /**
     * Consult string.
     *
     * @param listener the listener
     * @return the string
     */
    public void addTableUpdateListener(PropertyChangeListener listener) {
        tableUpdate.addPropertyChangeListener(listener);
    }

    /**
     * Add undo redo listener.
     *
     * @param listener the listener
     */
    public void addUndoRedoListener(PropertyChangeListener listener) {
        UndoRedo.addPropertyChangeListener(listener);
    }

    /**
     * Consult string.
     *
     * @return the string
     */
    public String consult() {

        pcs.firePropertyChange(null, null, null);
        return fsm.consult(2, "");
    }

    /**
     * Bar chart info xy chart . series.
     *
     * @param opc the opc
     * @return the xy chart . series
     */
    public XYChart.Series<String,Integer> barChartInfo(int opc){
        return fsm.barChartInfo(opc);
    }

    /**
     * Insert.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean insert(String nameFile) {
        boolean res = fsm.insert(nameFile);

        return res;
    }

    /**
     * Manual insert int.
     *
     * @param number    the number
     * @param proposals the proposals
     * @return the int
     */
    public int manualInsert(String number, String proposals) {
        if(number.isEmpty() || proposals.isEmpty())
            return 1;
        int res = fsm.manualInsert(number, proposals);
        pcs.firePropertyChange(null, null, null);
        return res;
    }

    /**
     * Export boolean.
     *
     * @return the boolean
     */
    public boolean export() {
        return fsm.export("");
    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {
        return fsm.exportDelete();
    }

    /**
     * Is empty d boolean.
     *
     * @return the boolean
     */
    public boolean isEmptyD() {
        return fsm.isEmpty();
    }

    /**
     * Edit students boolean.
     *
     * @param id         the id
     * @param capName    the cap name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the boolean
     */
    public boolean editStudents(long id, String capName, String mail, String course, String branch, double grade, boolean internship) {
        fsm.editStudents(id, capName, mail, course, branch, grade, internship);
        pcs.firePropertyChange(null, null, null);
        return true;
    }

    /**
     * Edit proposals boolean.
     *
     * @param id         the id
     * @param newChanges the new changes
     * @return the boolean
     */
    public boolean editProposals(String id, ArrayList<Object> newChanges) {
        boolean res = fsm.editProposals(id, newChanges);
        pcs.firePropertyChange(null, null, null);
        return res;
    }

    /**
     * Edit teachers boolean.
     *
     * @param mail    the mail
     * @param capName the cap name
     * @return the boolean
     */
    public boolean editTeachers(String mail, String capName) {
        boolean res = fsm.editTeachers(mail, capName);
        pcs.firePropertyChange(null, null, null);
        return res;
    }

    /**
     * Edit candidatures boolean.
     *
     * @param id       the id
     * @param newProjs the new projs
     * @return the boolean
     */
    public boolean editCandidatures(long id, HashSet<String> newProjs) {
        boolean res = fsm.editCandidatures(id, newProjs);
        return res;
    }

    /**
     * Advisor teacher specif status string.
     *
     * @param teacherMail the teacher mail
     * @return the string
     */
    public String advisor_teacherSpecifStatus(String teacherMail){return fsm.advisor_teacherSpecifStatus(teacherMail);}

    /**
     * Check tied array list.
     *
     * @return the array list
     */
    public ArrayList<Object> checkTied(){ //to check tied
        return fsm.attributedProposals();
    }

    /**
     * Edit advisors string.
     *
     * @param proposal the proposal
     * @param Tmail    the tmail
     * @return the string
     */
    public String editAdvisors(String proposal, String Tmail) {

        String res = fsm.editAdvisors(proposal, Tmail);
        return res;
    }

    /**
     * Add auto designed advisor.
     */
    public void addAutoDesignedAdvisor() {
        fsm.addAutoDesignedAdvisor();
        pcs.firePropertyChange(null, null, null);
    }

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    public HashMap<String, ArrayList<Object>> consultMode(int opc) {
        return fsm.consultMode(opc);
    }


    /**
     * Manual insert student int.
     *
     * @param id         the id
     * @param name       the name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the int
     */
    public int manualInsertStudent(String id, String name, String mail, String course, String branch, String grade, String internship) {
        int res = fsm.manualAddStudent(id, name, mail, course, branch, grade, internship);
        pcs.firePropertyChange(null, null, null);
        return res;
    }

    /**
     * Close phase.
     */
    public void closePhase() {
        fsm.closePhase();
        pcs.firePropertyChange(null, null, null);
        closeUpdate.firePropertyChange(null,null,null);
    }

    /**
     * Advance phase.
     */
    public void advancePhase() {
        fsm.advancePhase();
        pcs.firePropertyChange(null, null, null);
        //System.out.println("Close Phase : " + getClosePhase());
    }

    /**
     * Previous phase.
     */
    public void previousPhase() {
        fsm.previousPhase();
        pcs.firePropertyChange(null, null, null);
    }

    /**
     * Gets close phase.
     *
     * @return the close phase
     */
    public int getClosePhase() {
        int res = fsm.getClosePhase();
        return res;
    }

    /**
     * Gets data maps.
     *
     * @return the data maps
     */
    public Object getDataMaps() {
        return fsm.getData(fsm.getState());
    }

    /**
     * Delete boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean delete(String id) {
        boolean res = fsm.delete(id);

            tableUpdate.firePropertyChange(null,null,null);
        return res;
    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        return fsm.deleteAll();
    }

    /**
     * Gets state.
     *
     * @return the state
     */
    public GpeState getState() {
        return fsm.getState();
    }


    /**
     * F 1 teachers.
     */
    public void f1_teachers() {

        fsm.f1_teachers();
        pcs.firePropertyChange(null, null, null);
    }

    /**
     * F 1 prop proj.
     */
    public void f1_propProj() {

        fsm.f1_propProj();
        pcs.firePropertyChange(null, null, null);
    }

    /**
     * Hash prop assigned hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> hashPropAssigned() {
        return fsm.hashPropAssigned();
    }

    /**
     * F 1 students.
     */
    public void f1_students() {

        fsm.f1_students();
        pcs.firePropertyChange(null, null, null);
    }


    /**
     * Gets menu opt.
     *
     * @return the menu opt
     */
    public MenuOpt getMenuOpt() {
        return menuOpt;
    }

    /**
     * Sets menu opt.
     *
     * @param menuOpt the menu opt
     */
    public void setMenuOpt(MenuOpt menuOpt) {
        this.menuOpt = menuOpt;
        pcs.firePropertyChange(null, null, null);
    }

    /**
     * Reset boolean.
     *
     * @return the boolean
     */
    public boolean reset() {
        if (fsm.ClearData()) {
           /*
            if ( fsm.save()) {
                File dir = new File("Resources/SavePoints/");
                Utils.deleteFolder(dir);
                System.out.println("\n ✔ SavePoint was cleared");

            }

            */
        }
        tableUpdate.firePropertyChange(null, null, null);
        return true;
    }

    /**
     * Is empty boolean.
     *
     * @return the boolean
     */
    public boolean isEmpty() {
        return fsm.isEmpty();
    }


    /**
     * Save boolean.
     *
     * @return the boolean
     */
    public boolean save() {
        return fsm.save();
    }


    /**
     * Gets data all.
     *
     * @param gpeState the gpe state
     * @return the data all
     */
    public Map<?, ?> getDataAll(GpeState gpeState) {
        pcs.firePropertyChange(null, null, null);

        return (Map<?, ?>) fsm.getData(gpeState);
    }

    /**
     * Check one empty p 1 boolean.
     *
     * @return the boolean
     */
    public boolean checkOneEmptyP1() {
        return fsm.getNotDataPossible(GpeState.TEACHERS)
                || fsm.getNotDataPossible(GpeState.STUDENTS)
                || fsm.getNotDataPossible(GpeState.PROPOSALS);
    }

    /**
     * Advisors general status string.
     *
     * @return the string
     */
    public String advisorsGeneralStatus() {
        return fsm.advisorsGeneralStatus();
    }

    /**
     * Load boolean.
     *
     * @return the boolean
     */
    public boolean load() {

        menuOpt = MenuOpt.STARTMENU;

        boolean res = fsm.load();
        pcs.firePropertyChange(null, null, null);
        return res;
    }

    /**
     * Pie chart info observable list.
     *
     * @param opc the opc
     * @return the observable list
     */
    public ObservableList<PieChart.Data> pieChartInfo(int opc) {
        return fsm.pieChartInfo(opc);
    }

    /**
     * Gets bottom info.
     *
     * @param opc the opc
     * @return the bottom info
     */
    public int getBottomInfo(int opc) {
        return fsm.getBottomInfo(opc);
    }

    /**
     * Undo boolean.
     *
     * @return the boolean
     */
    public boolean undo() {

        boolean res = fsm.undo();
        UndoRedo.firePropertyChange(null, null, null);
        return res;
    }

    /**
     * Redo boolean.
     *
     * @return the boolean
     */
    public boolean redo() {

        boolean res = fsm.redo();
        UndoRedo.firePropertyChange(null, null, null);
        return res;


    }

    /**
     * Save undo boolean.
     *
     * @return the boolean
     */
    public boolean saveUndo() {
        return fsm.saveUndo();
    }

    /**
     * Save redo boolean.
     *
     * @return the boolean
     */
    public boolean saveRedo() {
        return fsm.saveRedo();
    }
}