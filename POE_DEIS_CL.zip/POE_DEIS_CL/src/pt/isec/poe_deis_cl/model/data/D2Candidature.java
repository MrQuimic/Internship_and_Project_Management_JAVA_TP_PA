package pt.isec.poe_deis_cl.model.data;

import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;

import java.io.*;
import java.util.*;

/**
 * Class description:
 * <br>
 * Contém as classes que representam as estruturas de dados e
 * que disponibilizam toda a funcionalidade.
 * <br><br>
 * <p>
 * Candidature data - Students note the projects and internships they would like by preference order
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class D2Candidature implements Serializable {
    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;

    /**
     * The Data can.
     * <p>
     * USE HASHSET TO HAVE ALWAYS DIFFERENT PROJECTS
     */


    /**
     * The Filtercache.
     */
    DGeneral dGeneral;

    /**
     * The Data can.
     */
    public Map<Long, HashSet<String>> dataCan; //{idStudent,info}


    /**
     * Instantiates a new D 2 candidature.
     *
     * @param dGeneral the d general
     */
    public D2Candidature(DGeneral dGeneral) {
        this.dataCan = new HashMap<>();
        this.dGeneral = dGeneral;
    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public Map<Long, HashSet<String>> getData() {
        return dataCan;
    }

    /**
     * Return data map.
     *
     * @return the map
     */
    public Map<Long, HashSet<String>> returnData(){
        return Map.copyOf(dataCan);
    }

    /**
     * Gets data can.
     *
     * @return the data can
     */
    public Map<Long, HashSet<String>> getDataCan() {
        return dataCan;
    }

    /**
     * Manual insert int.
     *
     * @param number    the number
     * @param proposals the proposals
     * @return the int
     */
    public int manualInsert(String number, String proposals){
        HashSet<String> proposalsRead = new HashSet<>();
        String pRead;
        long idNum;
        try {
            idNum = Long.parseLong(number);
        } catch (NumberFormatException e) {
            return -1;
        }
        if(!dGeneral.D1S.containsId(idNum))
            return -2;
        if(proposals.isEmpty())
            return -3;
        Scanner sc = new Scanner(proposals);
        sc.useDelimiter(",");
        while (sc.hasNext()) {
            pRead = sc.next();
            proposalsRead.add(pRead);

        }
        dataCan.put(idNum,proposalsRead);
        return 0;

    }

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(Map<Long, HashSet<String>> data) {
        this.dataCan = data;
    }

    /**
     * Add data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean AddData(String nameFile) {
        String relativePath;
        if(nameFile.isEmpty())
            relativePath = "Resources/imports/candidaturas.csv";
        else
            relativePath= "Resources/imports/" + nameFile;

        String scanned = "";
        long idNum = 0;

        File ProposalsFile = new File(relativePath);
        Scanner sc = null;
        Scanner sc_line = null;
        try {
            sc = new Scanner(ProposalsFile);
            sc_line = new Scanner(scanned);
        } catch (FileNotFoundException e) {
            return false;
        }

        sc.useDelimiter("[,;\r\n]");
        sc_line.useDelimiter(",");

        while ((sc.hasNext())) {
            String id = sc.next();

            try {
                idNum = Long.parseLong(id);
            } catch (NumberFormatException e) {
                sc.nextLine();
                continue;
            }



            if (!dGeneral.D1S.containsId(idNum)) { // if the student do not exists it does not add
                sc.nextLine();
                continue;
            }

            scanned = sc.nextLine();
            sc_line = new Scanner(scanned);
            sc_line.useDelimiter(",");


            HashSet<String> candidatures = dataCan.get(idNum);  //data is the Hashmap
            if (dataCan.get(idNum) == null) {
                candidatures = new HashSet<String>();
                dataCan.put(idNum, candidatures); //inserts in the hasmap if it does not exist yet

            }
            while (sc_line.hasNext()) {
                id = sc_line.next();
                candidatures.add(id);
            }


        }
        return true;
    }

    /**
     * Edit candidature boolean.
     *
     * @param id       the id
     * @param newProjs the new projs
     * @return the boolean
     */
    public boolean editCandidature(long id, HashSet<String> newProjs) {
        HashSet<String> candidature = dataCan.get(id);
        if (candidature == null) {
            return false;
        }
        for (String proj : newProjs) {
            proj = proj.substring(1);
            if (!candidature.contains(proj) && dGeneral.D1P.containsId(proj)){
                candidature.add(proj);
            }
        }
        return true;
    }


    /**
     * Contains id string.
     *
     * @param id the id
     * @return the string
     */
    public String containsId(long id) {

        if (!dataCan.containsKey(id))
            return Errors.ID_NOTFOUND_ERROR.toString();

        return String.valueOf(id);
    }


    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {
        String relativePath;
        Utils.fileExists(GpeState.CANDIDATURE.toString(), "exports");
        String fileName = GpeState.CANDIDATURE + "_";
        String type = "";

        if(nameFile.isEmpty())
            relativePath = "Resources/exports/" + fileName + dGeneral.CurrentDate + ".csv";
        else
            relativePath= "Resources/exports/" + fileName  + nameFile;

        try {
            FileWriter candidatureWriter = new FileWriter(relativePath);

            if (dataCan.isEmpty())
                return false;
            for (Long key : dataCan.keySet()) {
                candidatureWriter.write(key.toString());
                HashSet<String> candidature = dataCan.get(key);
                for (String projs : candidature)
                    candidatureWriter.write("," + projs);

                candidatureWriter.write("\n");
            }

            candidatureWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {

        return Utils.exportDelete(GpeState.CANDIDATURE.toString()
        );
    }

    /**
     * Delete boolean.
     * Deletes specific candidature
     *
     * @param id the id
     * @return the boolean
     */
    public boolean delete(String id) {
        long ID;
        try{
            ID = Long.parseLong(id);
        }catch (Exception e){
            return false;
        }
        if (!dataCan.containsKey(ID))
            return false;
        dataCan.remove(ID);
        return true;
    }

    /**
     * Delete all data fom data candidature
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        dataCan.clear();
        return true;
    }

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    public HashMap<String,ArrayList<Object>> consultMode(int opc){
        HashMap<String,ArrayList<Object>> infoCand = new HashMap<>();
        ArrayList<Object> info ;
        switch (opc){
            case 1->{ // All proposals
                for(Long key : dataCan.keySet()) {
                    info = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    info.add(dataCan.get(key));
                    infoCand.put(key.toString(),info);
                }
            }
            case 2->{ // Assigned candidature
                for(Long key : dataCan.keySet()) {
                    info = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    info.addAll(dGeneral.D1S.getStudentList(key));
                    infoCand.put(key.toString(),info);
                }
            }
            case 3-> { // Auto-Proposal candidature
                HashSet<Long> Students_auto = dGeneral.D1P.autoANDprop_teachersStudents();                        //get list of autoproposal/proposal by tea
                for (Long key : Students_auto) {
                    info = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    info.addAll(dGeneral.D1S.getStudentList(key));
                    infoCand.put(key.toString(), info);
                }
            }
            case 4->{ // Without candidature
                HashSet<Long> students = dGeneral.D1S.getStudentsIDs();
                HashSet<Long> Students_auto = dGeneral.D1P.autoANDprop_teachersStudents();                        //get list of autoproposal/proposal by tea
                for (Long key : students) {
                    if(!dataCan.containsKey(key)) {
                        info = new ArrayList<>();
                        if(!dGeneral.D1S.containsId(key) || Students_auto.contains(key))
                            continue;
                        info.addAll(dGeneral.D1S.getStudentList(key));
                        infoCand.put(key.toString(), info);
                    }
                }

            }
        }
        return infoCand;
    }


    /**
     * Filter is active boolean.
     *
     * @param index the index
     * @return the boolean
     */
    public boolean filterIsActive(int index){
        index--;
        if(index < 0  || index > 4) {
            return false;
        }
        return dGeneral.filtercache[index];
    }

    /**
     * Filter string.
     *
     * @param filterChoice the filters
     * @return the string
     */
    public String toStringfilter(int filterChoice ){
        //ex [0 1 1 0]
        // 1-> Autoproposals of students.          // 2-> Proposals by teachers.
        // 3-> Proposals with candidature.         // 4-> Proposals without candidature.


        if(dataCan.isEmpty())
            return "ListIsEmpty";

        filterChoice--;
        if(filterChoice < 0 || filterChoice > 3 )
            return Errors.INDEX_ERROR.getError() + "- Insert a valid index!";

        HashSet<String> filteredProposal = new HashSet<>();
        HashSet<String> filteredToDelete = new HashSet<>();
        HashSet<String> tempfilter = null;
        StringBuilder sb = new StringBuilder();

        if(dGeneral.filtercache[filterChoice])
            dGeneral.filtercache[filterChoice] = false;
        else
            dGeneral.filtercache[filterChoice] = true;



        if(dGeneral.filtercache[0]) { // 1-> Autoproposals of students.

            filteredProposal.addAll(hashAutoProposal());

            sb.append("Student Auto-Proposals\n");

        }

        if(dGeneral.filtercache[1]) {// 2-> Proposals by teachers.
            if(filteredProposal.isEmpty())
                filteredProposal.addAll(hashteacherProposal());
            else {
                tempfilter = hashteacherProposal();
                for (String prop : tempfilter)
                    if (!filteredProposal.contains(prop))
                        filteredToDelete.add(prop);

                for (String prop : filteredProposal)
                    if (!tempfilter.contains(prop))
                        filteredToDelete.add(prop);
            }
        sb.append("Teachers Proposals\n");
        }


        filteredProposal.removeAll(filteredToDelete);
        filteredToDelete.clear();

        if(dGeneral.filtercache[2]) {
            if(filteredProposal.isEmpty())
                filteredProposal.addAll(hashCandProposal());
            else {
                tempfilter = hashCandProposal();
                for (String prop : tempfilter)
                    if (!filteredProposal.contains(prop))
                        filteredToDelete.add(prop);

                for (String prop : filteredProposal)
                    if (!tempfilter.contains(prop))
                        filteredToDelete.add(prop);
            }

            sb.append("Proposals With Candidature \n");
        }

        filteredProposal.removeAll(filteredToDelete);
        filteredToDelete.clear();

        if(dGeneral.filtercache[3]) {
            if(filteredProposal.isEmpty())
                filteredProposal.addAll(hashNoCandProposal());
            else {
                tempfilter = hashNoCandProposal();
                for (String prop : tempfilter)
                    if (!filteredProposal.contains(prop))
                        filteredToDelete.add(prop);

                for (String prop : filteredProposal)
                    if (!tempfilter.contains(prop))
                        filteredToDelete.add(prop);
            }
            sb.append("Proposals Without Candidature");
        }

        filteredProposal.removeAll(filteredToDelete);


        return ToStringProp(filteredProposal);
    }

    /**
     * To string prop string.
     *
     * @param filteredProposal the filtered proposal
     * @return the string
     */
    public String ToStringProp(HashSet<String>filteredProposal){
        int sizeValues= 0, sizeValuesMax= 0;
        StringBuilder sb = new StringBuilder();
        String tableLength;
        for(String b:filteredProposal) {
            sizeValues =0;

            sizeValues = sizeValues  + dGeneral.D1P.getProp(b).length();

            if (sizeValuesMax < sizeValues)
                sizeValuesMax = sizeValues;
        }

        tableLength = "━".repeat(sizeValuesMax); //line after titles
        sb.append("\n").append(tableLength).append("\n");

        if(filteredProposal.isEmpty())
            return Errors.GENERAL_ERROR.getError() + "No cumulated results in the filters!";

        for(String prop:filteredProposal) {
                 int i=0;

            ArrayList<Object> specifProp = dGeneral.D1P.returnData().get(prop);
            if(specifProp.isEmpty())
                return "PROPOSAL NOT FOUND!\n";

            sb.append(" Proposal "+ prop+":  \uD83C\uDFF7 ");


            for(Object value : specifProp) {
                if(!(dGeneral.filtercache[2] || dGeneral.filtercache[3])) {
                    if (value instanceof Long)
                        sb.append("").append((dGeneral.D1S.getName(Long.parseLong(value.toString())) + " "));
                }



                if (value.toString().equals("0"))
                    value = " ";

                if(!((dGeneral.filtercache[2] || dGeneral.filtercache[3]) && (value instanceof Long)))
                    sb.append(value);
                else
                    value = " ";

                if (i==0 && value.toString().equals("T3"))
                    sb.append(" | ");
                else if (i==0 && !value.toString().equals("T3"))
                    sb.append(" | ");
                else if(!value.toString().equals(" ") && !value.toString().equals(""))
                    sb.append("  \uD83C\uDFF7  ");

                i++;

            }

            sb.append("\n");
        }

        tableLength = "━".repeat(sizeValuesMax); //line after titles
        sb.append("").append(tableLength).append("\n");

        return sb.toString();
    }

    /**
     * Amount of data.
     *
     * @return the int total quantity of candidatures
     */
    protected int amountOF() {
        if (dataCan.isEmpty())
            return 0;
        return dataCan.size();
    }

    /**
     * Gets list.
     *
     * @param opc the opc
     * @return the list
     */
    public String ToStringSelector(int opc) {
        StringBuilder sb = new StringBuilder();

        switch (opc) {
            case 1:// With autoProposal done
                return dGeneral.D1P.listAutoProposal();
            case 2:// With candidature done
                return toStringCandRegisted();
            case 3:
                return toStringStunotRegisted(); //Students without candidatures
        }
        return null;
    }


    /**
     * Has cand boolean.
     * Checks if there is a candidature for the proposal
     *
     * @param proposal the proposal
     * @return the boolean
     */
    protected boolean hasCand(String proposal){
        for(Long num :dataCan.keySet()) {
            HashSet<String> candid = dataCan.get(num);
            if(candid.contains(proposal))
                return true;
        }

        return false;
    }

    /**
     * Hash auto proposals hash set.
     *
     * @return the hash set
     */
    public HashSet<String> hashAutoProposal(){

        HashSet<String> stdChoosen = new HashSet<>();
        for (String key : dGeneral.D1P.returnData().keySet()) {
            ArrayList<Object> propos = dGeneral.D1P.returnData().get(key);
            if (propos.get(0).equals("T3")) {
                stdChoosen.add(key);
            }

        }


        return stdChoosen;
    }

    /**
     * Hash no cand proposal hash set.
     * gets all proposals with no candidatures
     *
     * @return the hash set
     */
    protected HashSet<String> hashNoCandProposal(){
        HashSet<String> stdChoosen = new HashSet<>();
        for (String key : dGeneral.D1P.returnData().keySet()) {
            if(!dGeneral.D2C.hasCand(key))
                stdChoosen.add(key);
        }
        return stdChoosen;
    }

    /**
     * Hash cand proposal hash set.
     *
     * @return the hash set
     */
    protected HashSet<String> hashCandProposal(){
        HashSet<String> stdChoosen = new HashSet<>();
        for (String key : dGeneral.D1P.returnData().keySet()) {
            if(dGeneral.D2C.hasCand(key))
                stdChoosen.add(key);
        }

        return stdChoosen;
    }


    /**
     * Hashteacher proposal hash set.
     *
     * @return the hash set with all the teachers
     */
    public HashSet<String> hashteacherProposal(){
        HashSet<String> stdChoosen = new HashSet<>();
        for (String key : dGeneral.D1P.returnData().keySet()) {
            ArrayList<Object> propos = dGeneral.D1P.returnData().get(key);
            if (propos.get(0).equals("T2")) {
                stdChoosen.add(key);
            }
        }
        return stdChoosen;
    }
/*
    public Boolean getNotDataPossible(){
        return dataCan.isEmpty();
    }*/

    /**
     * Gets cand registed.
     * Accesses D1Students data and complies toString there
     *
     * @return the cand registed
     */
    protected String toStringCandRegisted() {

        String[] printTitles= {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE"};
        int[] sizeTitles1= {6, 6, 6, 6, 6, 6};
        String[] ord= {" ", " "," ", " ", " ", " "};

        HashSet<Long> stdChoosen = new HashSet<Long>();



        for (long key : dataCan.keySet()) {
            if (!dGeneral.D1S.containsId(key))
                continue;
            stdChoosen.add(key);
        }

        return dGeneral.D1S.toString_compile(1, "","Assigned Candidature\n", stdChoosen, printTitles,sizeTitles1, ord);
    }
    /**
     * To string string.
     * Accesses D1Students data and complies toString there
     * @return the string
     */

    private String toStringStunotRegisted() { //accesses D1Students
        String[] printTitles= {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE"};
        int[] sizeTitles1= {6, 6, 6, 6, 6, 6};
        String[] ord= {" ", " "," ", " ", " ", " "};


        HashSet<Long> stdChoosen = new HashSet<Long>();
        HashSet<Long> students = dGeneral.D1S.getHashStudent();
        for (long id : students) {
            if (dataCan.containsKey(id))
                continue;
            stdChoosen.add(id);
        }
        return dGeneral.D1S.toString_compile(1, "","Without Candidature\n", stdChoosen, printTitles,sizeTitles1, ord);

    }


    /**
     * To string string.
     *
     * @param column the column
     * @param filter the toStringfilter
     * @return the string
     */
    public String toString(int column, String filter) {

        String[] printTitles = {"ID", "Candidatures"};
        int[] sizeTitles1 = {6, 6};
        String[] ord = {" ", " "};


        return toString_compile(column, filter, printTitles, sizeTitles1, ord);
    }

    /**
     * Get std id long.
     *
     * @param prop the prop
     * @return the long
     */
    public Long getStdId(String prop){
        for(Long number :dataCan.keySet()) {
            if (dataCan.get(number).equals(prop)) {
                return number;
            }
        }
        return 0L;
    }

    /**
     * Remain students with candidatures hash set.
     *
     * @return the hash set
     */
    protected HashSet<Long> remainStudentsWithCandidatures(){
        HashSet<Long> Students_auto = dGeneral.D1P.autoANDprop_teachersStudents();                        //get list of autoproposal/proposal by tea
        HashSet<Long> remainStudentswithCandidatures = new HashSet<>();                      //get list of students with available candidatures
        Map<Long, HashSet<String>> candidatures = dGeneral.D2C.dataCan;    //gete data of candidature

        for(long num : candidatures.keySet())                                               //get number of candidature
            if(!Students_auto.contains(num) && !dGeneral.D3P.AtribProposals.containsKey(num))                                                //se nao contiver numeroo
                remainStudentswithCandidatures.add(num);                                    //add

        return remainStudentswithCandidatures;
    }

    /**
     * Students with cand hash set.
     *
     * @return the hash set
     */
    protected HashSet<Long> studentsWithCand(){
        HashSet<Long> Students_auto = dGeneral.D1P.autoANDprop_teachersStudents();                        //get list of autoproposal/proposal by tea
        HashSet<Long> students = new HashSet<>();
        students.addAll(Students_auto);
        for(Long studentID : dataCan.keySet())
            students.add(studentID);
        return students;
    }

    /**
     * Get preference int.
     *
     * @param id   the id
     * @param proj the proj
     * @return the int
     */
    public int getPreference(long id,String proj){
        int pref = 0;
        Map<Long, HashSet<String>> candidatures = dataCan; //get data from candidatures
        HashSet<String> studentCand = candidatures.get(id);                         //get info of student
        if(dGeneral.D1P.autoANDprop_teachersStudents().contains(id))
            return 1;
        if (candidatures.get(id)!=null) {
            if (!studentCand.contains(proj))                     //if info do not contain candidature to that proposal
                return 9999;


            for(String cand : studentCand) {                                            //roam all candidatures of student
                if (cand.equals(proj))                                                  //if is in x position
                    return pref;                                                        //return x
                pref++;                                                                 //else increase x
            }
        }
        return 9999;                                                     //if not found return 999, to be treated after
    }

    /**
     * To string compile string.
     *
     * @param column      the column
     * @param filter      the toStringfilter
     * @param printTitles the print titles
     * @param sizeTitles  the size titles
     * @param ord         the ord
     * @return the string
     */
    public String toString_compile(int column, String filter, String[] printTitles, int[] sizeTitles, String[] ord) {
        int countResults = 0, countFilters = 0, titlelinelength, lineLength = 0, k,  sizet, j, projMaxSize = 0, countProj=0, projSize =0;
        boolean res;
        String ordervar = "↕ ";
        StringBuilder sb = new StringBuilder();
        ArrayList<Object> GetKeyArray;

        ord[column - 1] = ordervar; //icone of toStringfilter

        if (dataCan == null || dataCan.isEmpty())
            sb.append("\nThe list is empty!\n");
        else {

            for (Long key : dataCan.keySet()) {
                GetKeyArray = new ArrayList<>(dataCan.get(key));

                sizet = key.toString().length();
                if (sizet > sizeTitles[0])
                    sizeTitles[0] = sizet;

                if (printTitles[0].length() > sizeTitles[0])
                    sizeTitles[0] = printTitles[0].length();


                j = 0;

                for (String str : printTitles) {
                    sizet = 0;
                    for (Object proj : GetKeyArray) {
                        sizet = sizet + proj.toString().length();
                    }
                    if (sizeTitles[1] < sizet)
                        sizeTitles[1] = sizet;

                    j++;


                }
            }

            k = 0;
            for (String str : printTitles) {

                sb.append(" ".repeat((sizeTitles[k]) / 2)).append(ord[k]).append(str).append(" ".repeat((sizeTitles[k]) / 2)); //titles print
                k++;

            }

            titlelinelength = sb.length()+1;
            String tableLength = "━".repeat(titlelinelength); //line after titles
            sb.append("\n").append(tableLength).append("\n");

            HashMap<Long, String> mp = new HashMap<Long, String>(); //order hasmap

            if (column == 1) {
                for (Long key : dataCan.keySet()) {
                    mp.put(key, key.toString());

                }

            } else {
                for (Long key : dataCan.keySet()) {
                    GetKeyArray = new ArrayList<>(dataCan.get(key));
                    mp.put(key, GetKeyArray.get(column - 2).toString());
                }
            }

            Map<Long, String> sortedMap = HashMapComp.longSortByComparator(mp);
            Set<Map.Entry<Long, String>> set = sortedMap.entrySet();
            // Get an iterator
            Iterator<Map.Entry<Long, String>> p = set.iterator();


            // Display elements
            while (p.hasNext()) {
                Map.Entry<Long, String> me = p.next();

                GetKeyArray = new ArrayList<>(dataCan.get(me.getKey()));
                res = GetKeyArray.stream().anyMatch((a) -> a.toString().contains(filter));
                lineLength = sb.length() - lineLength - titlelinelength;

                if (res || me.getKey().toString().contains(filter)) {
                    sb.append(" ").append(me.getKey()).append(" ".repeat(sizeTitles[0] - me.getKey().toString().length()));

                    sb.append(" \t|\t");
                    countProj = 0;
                    for (Object proj : GetKeyArray) {
                            sb.append(" ").append(proj);


                        countProj++;
                        projSize = projSize + proj.toString().length();
                    }

                    projSize = 0;
                    sb.append("\n");

                    countFilters++;
                }
                countResults++;
            }
            sb.append(tableLength).append("\n ").append(countFilters).append(" of ").append(countResults).append(" ");

        }
        return sb.toString();
    }


    /**
     * Std cand string.
     *
     * @param stdID the std id
     * @return the string
     */
    public String stdCand(long stdID){
        if(!dataCan.containsKey(stdID))
            return "Student do not exist";
        StringBuilder sb = new StringBuilder();
        sb.append(" -> ");
        HashSet<String> proposalList = dataCan.get(stdID);
        for(String prop : proposalList)
            sb.append(prop + " ");


        return sb.toString();
    }

}
