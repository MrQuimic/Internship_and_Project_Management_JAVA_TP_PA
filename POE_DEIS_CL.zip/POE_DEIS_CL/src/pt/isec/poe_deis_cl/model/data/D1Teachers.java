/**
 * Class description:
 *
 * Teachers data
 *
 * @author Carlos Santos {@literal <a2003035578@isec.pt>}
 * @author Leonardo Sousa {@literal <a2019129243@isec.pt>}
 * @date 2022/04/05
 */
package pt.isec.poe_deis_cl.model.data;

import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;
import pt.isec.poe_deis_cl.utils.Validators;
import pt.isec.poe_deis_cl.utils.Utils;

import java.io.*;
import java.util.*;

/**
 * Class description:
 * <br>
 * Teachers data
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class D1Teachers  implements Serializable  {
    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;
    /**
     * The Data t.
     */

    // dataT = new HashMap<>();/**/**/*
    /**
     * The Data t.
     */
    public  Map<String, String> dataT;           //{mail,name}
    /**
     * The D general.
     */
    DGeneral dGeneral;


    /**
     * Instantiates a new D 1 teachers.
     *
     * @param dGeneral the d general
     */
    public D1Teachers(DGeneral dGeneral) {
        this.dataT = new HashMap<>();
        this.dGeneral = dGeneral;
    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public Map<String, String> getData() {
        return dataT;
    }


    /**
     * Get data possible boolean.
     *
     * @param state the state
     * @return the boolean
     */
    public Boolean getDataPossible(GpeState state){

        if (state==GpeState.PROPOSALS){

            return dGeneral.D1P.dataP.isEmpty();

        }else if (state==GpeState.STUDENTS){

            return dGeneral.D1S.dataS.isEmpty();

        }else if (state==GpeState.TEACHERS){

            return dGeneral.D1T.dataT.isEmpty();

        }else if (state==GpeState.CANDIDATURE) {
            return dGeneral.D2C.dataCan.isEmpty();

        }else if (state==GpeState.ASSIGNEDPROPOSALS) {

            return dGeneral.D3P.AtribProposals.isEmpty();
        }else if (state==GpeState.ADVISORS) {

            return dGeneral.D4A.AtribAdvisors.isEmpty();
        }
        return true;
    }

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(Map<String, String> data) {
        this.dataT = data;
    }

    /**
     * Add data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean AddData(String nameFile) {
        String relativePath;
        if(nameFile.isEmpty())
            relativePath = "Resources/imports/docentes.csv";
        else
            relativePath= "Resources/imports/" + nameFile;

        File TeachersFile = new File(relativePath);
        Scanner sc = null;
        try {
            sc = new Scanner(TeachersFile);
        } catch (FileNotFoundException e) {

            return false;
        }

        sc.useDelimiter("[,;\r\n]");

        while ((sc.hasNext())) {

            String name = sc.next();
            String mail = Validators.isStringValidEmail(sc.next()); //Checks valid email format

            if (dataT.containsKey(mail) || dGeneral.D1S.studentsHaveThisMail(mail)) { //if email already exists it does not add
                sc.nextLine();
                continue;
            }

            dataT.put(mail, name);

            if (sc.hasNext())
                sc.nextLine();
        }
        return true;
    }


    /**
     * Manual insert int.
     *
     * @param name the name
     * @param mail the mail
     * @return the int
     */
    public int manualInsert(String name, String mail) {
        dataT.put(Validators.isStringValidEmail(mail), name);
        return 0;
    }

    /**
     * Return data map.
     *
     * @return the map
     */
    public Map<String, String> returnData(){
        return Map.copyOf(dataT);
    }

    /**
     * Edit teacher boolean.
     *
     * @param mail the mail
     * @param name the name
     * @return the boolean
     */
    public boolean editTeacher(String mail, String name) {
        String teacher = dataT.get(mail);
        if (teacher == null)
            return false;

        int i = 0;

        dataT.put(Validators.isStringValidEmail(mail), name);

        return true;
    }

    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {
        String relativePath;
        Utils.fileExists(GpeState.TEACHERS.toString(), "exports");
        String fileName = GpeState.TEACHERS + "_";
        String type = "";

        if(nameFile.isEmpty())
            relativePath = "Resources/exports/" + fileName + dGeneral.CurrentDate + ".csv";
        else
            relativePath= "Resources/exports/" + fileName  + nameFile;

        try {
            FileWriter teacherWriter = new FileWriter(relativePath);

            if (dataT.isEmpty())
                return false;

            for (String key : dataT.keySet()) {
                teacherWriter.write(dataT.get(key));
                teacherWriter.write("," + key);
                teacherWriter.write("\n");
            }

            teacherWriter.close();

        } catch (IOException e) { //if file writer mandatory exception
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Is empty boolean.
     *
     * @return the boolean
     */
    public boolean isEmpty(){
        return dataT.isEmpty();
    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {

        return Utils.exportDelete(GpeState.TEACHERS.toString()
        );
    }

    /**
     * Delete boolean.
     *
     * @param email the email
     * @return the boolean
     */
    public boolean delete(String email) {
        if (!dataT.containsKey(email))
            return false;
        dataT.remove(email);
        return true;
    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll() {//Removes all data
        dataT.clear();
        return true;
    }

    /**
     * Amount of data.
     *
     * @return the int total quantity of teachers
     */
    protected int amountOF() {
        if (dataT.isEmpty())
            return 0;
        return dataT.size();
    }

    /**
     * Contains mail string.
     *
     * @param email the email
     * @return the string
     */
    public String containsMail(String email) { // Checks if it constains email on the data
        //USED AT PHASE 4
        if (!dataT.containsKey(email))
            return Errors.EMAILNOTFOUND_ERROR.toString();
        return email;

    }

    /**
     * Get name string.
     *
     * @param email the email
     * @return the string
     */
    public String getName(String email) {
        //USED AT PHASE 4
        return dataT.get(email);

    }
/*
    public Boolean getNotDataPossible() {

        return dataT.isEmpty();
    }
*/

    /**
     * To string string.
     *
     * @param column the column
     * @param filter the toStringfilter
     * @return the string
     */
    public String toString(int column, String filter) {

        String[] printTitles = {"Name", "Mail"};
        int[] sizeTitles1 = {8, 8};
        String[] ord = {" ", " "};

        HashSet<String> teachChoosen = new HashSet<String>();

        for (String email : dataT.keySet()) {
            teachChoosen.add(email);
        }
        return toString_compile(column, filter, "", teachChoosen, printTitles, sizeTitles1, ord);
    }

    /**
     * To string compile string.
     *
     * @param column        the column
     * @param filter        the toStringfilter
     * @param title         the title
     * @param teatchChoosen the teatch choosen
     * @param printTitles   the print titles
     * @param sizeTitles    the size titles
     * @param ord           the ord
     * @return the string
     */
    public String toString_compile(int column, String filter, String title, HashSet<String> teatchChoosen, String[] printTitles, int[] sizeTitles, String[] ord) {
        int countResults = 0, countFilters = 0, titlelinelength, lineLength = 0, k, sizet;
        boolean res;
        String ordervar = "↕ ";
        StringBuilder sb = new StringBuilder();

        if (!title.equals(""))
            sb.append("\n" + title + "\n");

        try {
            ord[column - 1] = ordervar; //icone of toStringfilter
        }catch (ArrayIndexOutOfBoundsException e){
            ord[0] = ordervar; //icone of toStringfilter
            column=1;
        }

        if (dataT == null || dataT.isEmpty())
            sb.append("\nlist is empty!\n");
        else {

            for (String key : teatchChoosen) {

                sizet = key.length();
                if (sizet > sizeTitles[0])
                    sizeTitles[0] = sizet;
                if (printTitles[0].length() > sizeTitles[0])
                    sizeTitles[0] = printTitles[0].length();


                sizet = dataT.get(key).length();
                if (sizet > sizeTitles[1])
                    sizeTitles[1] = sizet;

                if (printTitles[1].length() > sizeTitles[1])
                    sizeTitles[1] = printTitles[1].length();
            }

            k = 0;
            for (String str : printTitles) {

                sb.append(" ".repeat((sizeTitles[k]) / 2)).append(ord[k]).append(str).append(" ".repeat((sizeTitles[k]) / 2)); //titles print
                k++;
            }

            titlelinelength = sb.length()-title.length();
            String tableLength = "━".repeat(titlelinelength); //line after titles

            sb.append("\n").append(tableLength).append("\n");

            HashMap<String, String> mp = new HashMap<String, String>(); //order hasmap

            if (column == 2) {
                for (String key : teatchChoosen) {
                    mp.put(key, key);
                }
            } else {
                for (String key : teatchChoosen) {
                    mp.put(key, dataT.get(key));
                }
            }

            Map<String, String> sortedMap = HashMapComp.stringSortByComparator(mp);
            Set<Map.Entry<String, String>> set = sortedMap.entrySet();
            // Get an iterator
            Iterator<Map.Entry<String, String>> p = set.iterator();


            // Display elements
            while (p.hasNext()) {
                Map.Entry<String, String> me = p.next();

                res = dataT.get(me.getKey()).contains(filter);

                if (res || me.getKey().contains(filter)) {
                    lineLength = sb.length() - lineLength - titlelinelength;

                    sb.append(" ").append(dataT.get(me.getKey())).append(" ".repeat(((sizeTitles[1]) - dataT.get(me.getKey()).length()) / 2));
                    sb.append("\t|\t").append(me.getKey());
                    sb.append(" ").append(" ".repeat((sizeTitles[0] - (me.getKey()).length()) / 2)).append("\n");

                    countFilters++;

                }
                countResults++;
            }
            sb.append(tableLength).append("\n ").append(countFilters).append(" of ").append(countResults).append(" ");
        }


        //┏, ┓, ┛ e ┗
        return sb.toString();
    }

}
