package pt.isec.poe_deis_cl.model.data;

import javafx.collections.FXCollections;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;

import java.io.*;
import java.util.*;

/**
 * The type D general.
 */
public class DGeneral implements Serializable {

    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;
    /**
     * The Current date.
     */
    String CurrentDate = Utils.getformatDate();

    /**
     * The Phase.
     */
    int Phase = 1;
    /**
     * The Close Phase.
     */
    int ClosedPhase = 0;


    /**
     * The D 1 p.
     */
    public D1Proposals D1P;
    /**
     * The D 1 s.
     */
    public D1Students D1S;
    /**
     * The D 1 t.
     */
    public D1Teachers D1T;

    /**
     * The D 2 c.
     */
    public D2Candidature D2C;
    /**
     * The D 3 p.
     */
    public D3AssignedProp D3P;

    /**
     * The D 4 a.
     */
    public D4Advisors D4A;

    /**
     * Instantiates a new D general.
     */
    public D5Consult D5C;


    /**
     * Instantiates a new D general.
     */
    public DGeneral() {
        this.Phase = 1;
        this.ClosedPhase = 0;
        filtercache = new boolean[4];

        D1P = new D1Proposals(this);
        D1S = new D1Students(this);
        D1T = new D1Teachers(this);
        D2C = new D2Candidature(this);
        D3P = new D3AssignedProp(this);
        D4A = new D4Advisors(this);
        D5C = new D5Consult(this);
    }


    /**
     * The Filtercache.
     */
    public boolean[] filtercache;


    /**
     * Reset filter.
     */
    public void resetFilter() {
        Arrays.fill(filtercache, false);
    }

    /**
     * Delete all data fom data candidature
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        D1S.dataS.clear();
        D1T.dataT.clear();
        D1P.dataP.clear();
        D2C.dataCan.clear();
        D3P.AtribProposals.clear();
        D4A.AtribAdvisors.clear();
        Phase = 1;
        ClosedPhase = 0;
        return true;
    }


    /**
     * Increment close Phase int.
     *
     * @return the int
     */
    public int incrementCloseFase() {
        Phase++;
        return ClosedPhase++;
    }

    /**
     * Gets close phase.
     *
     * @return the close phase
     */
    public int getClosePhase() {
        return ClosedPhase;
    }

    /**
     * Sets Phase.
     *
     * @param f the f
     */
    public void setPhase(int f) {
        Phase = f;
    }

    /**
     * Sets close Phase.
     *
     * @param f the f
     */
    public void setClosePhase(int f) {
        ClosedPhase = f;
    }

    /**
     * Gets phase.
     *
     * @return the phase
     */
    public int getPhase() {
        return Phase;
    }


    /**
     * Gets data.
     *
     * @param state the state
     * @return the data
     */
    public Map<?, ?> getData(GpeState state) {
        Map<?, ?> data;
        if (state == GpeState.PROPOSALS) {
            return D1P.dataP;
        } else if (state == GpeState.STUDENTS) {

            return D1S.dataS;
        } else if (state == GpeState.TEACHERS) {


            return D1T.dataT;
        } else if (state == GpeState.CANDIDATURE) {

            return D2C.dataCan;

        } else if (state == GpeState.ASSIGNEDPROPOSALS) {

            return D3P.AtribProposals;
        } else if (state == GpeState.ADVISORS) {

            return D4A.AtribAdvisors;
        }

        return null;
    }


    /**
     * Get not data possible boolean.
     *
     * @param state the state
     * @return the boolean
     */
    public Boolean getNotDataPossible(GpeState state) {

        if (state == GpeState.PROPOSALS) {
            return D1P.dataP.isEmpty();

        } else if (state == GpeState.STUDENTS) {
            return D1S.dataS.isEmpty();

        } else if (state == GpeState.TEACHERS) {
            return D1T.dataT.isEmpty();

        } else if (state == GpeState.CANDIDATURE) {
            return D2C.dataCan.isEmpty();

        } else if (state == GpeState.ASSIGNEDPROPOSALS) {

            return D3P.AtribProposals.isEmpty();
        } else if (state == GpeState.ADVISORS) {

            return D4A.AtribAdvisors.isEmpty();
        }
        return true;
    }


    /**
     * Gets bottom info.
     *
     * @param opc the opc
     * @return the bottom info
     */
    public int getBottomInfo(int opc) {
        int result = 0;


        switch (opc) {
            case 1 -> { //Number of Students
                return D1S.dataS.size();
            }
            case 2 -> { //Number of Teachers
                return D1T.dataT.size();

            }
            case 3 -> { //Students with candidatures
                return D2C.dataCan.size();

            }
            case 4 -> { //Number of Proposals
                return D3P.AtribProposals.size();

            }
            case 5 -> { //Number of Assigned Advisors
                return D4A.AtribAdvisors.size();
            }
        }
        return result;
    }

    /**
     * Sets data.
     *
     * @param dg the dg
     */
    public void setData(DGeneral dg) {
        D1S.dataS.clear();
        D1S.dataS.putAll(dg.D1S.dataS);

        D1T.dataT.clear();
        D1T.dataT.putAll(dg.D1T.dataT);

        D1P.dataP.clear();
        D1P.dataP.putAll(dg.D1P.dataP);


        D2C.dataCan.clear();
        D2C.dataCan.putAll(dg.D2C.dataCan);

        D3P.AtribProposals.clear();
        D3P.AtribProposals.putAll(dg.D3P.AtribProposals);

        D4A.AtribAdvisors.clear();
        D4A.AtribAdvisors.putAll(dg.D4A.AtribAdvisors);

        this.Phase = dg.Phase;
        this.ClosedPhase = dg.ClosedPhase;

    }


}



