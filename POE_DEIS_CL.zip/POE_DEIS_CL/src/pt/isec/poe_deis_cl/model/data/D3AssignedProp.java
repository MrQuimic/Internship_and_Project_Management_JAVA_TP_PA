package pt.isec.poe_deis_cl.model.data;

import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.*;


/**
 * The type D 3 assigned prop.
 */
public class D3AssignedProp implements Serializable  {
    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;

    /**
     * The Filtercache.
     * <p>
     * The Atrib proposals.
     */
    /**
     * The Atrib proposals.
     */

    //boolean[] filtercache;



    public Map<Long,String> AtribProposals; //{number,proposal}

    /**
     * The D general.
     */
    DGeneral dGeneral;


    /**
     * Instantiates a new D 3 assigned prop.
     *
     * @param dGeneral the d general
     */
    public D3AssignedProp(DGeneral dGeneral) {
        this.AtribProposals = new HashMap<>();

        this.dGeneral = dGeneral;
    }


    /**
     * Gets data.
     *
     * @return the data
     */
    public Map<Long, String> getData() {
        return AtribProposals;
    }

    /**
     * Return data map.
     *
     * @return the map
     */
    public Map<Long,String> returnData(){
        return Map.copyOf(AtribProposals);
    }


    /**
     * Manual add assignment boolean.
     *
     * @param stdID    the std id
     * @param proposal the proposal
     * @return the boolean
     */
    public int manualAddAssignment(String stdID,String proposal){
        long stdIDD = Long.parseLong(stdID);
        if(AtribProposals.containsKey(stdIDD)) {
           return -1;
        }
        else if(AtribProposals.containsValue(proposal)){
            return -2;
        }
        else if(!dGeneral.D1P.containsId(proposal)) {
            return -3;
        }
        else if(!dGeneral.D1S.containsId(stdIDD)) {
            return -4;
        }
        AtribProposals.put(stdIDD,proposal);
        return 0;
    }


    /**
     * Delete boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean delete(String id){
        long idd = Long.parseLong(id);
        if(!dGeneral.D1P.autoANDprop_teachersStudents().contains(idd)){   //if not auto/teacher proposal
            if(AtribProposals.containsKey(idd)) {              //if is registered
                AtribProposals.remove(idd);                    //delete
                return true;
            }
            else
                return false;

        }

        return false;

    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll(){
        if(AtribProposals.isEmpty())
            return false;
        else
            AtribProposals.clear();
        return true;
    }

    /**
     * Check tie stu long.
     *
     * @return the long
     */
    public long checkTieStu(){


        return 0L;
    }

    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {
        String relativePath;
        Utils.fileExists(GpeState.ASSIGNEDPROPOSALS.toString(),"exports");
        String fileName = GpeState.ASSIGNEDPROPOSALS + "_";
        String type = "";

        if(nameFile.isEmpty())
            relativePath = "Resources/exports/" + fileName + dGeneral.CurrentDate + ".csv";
        else
            relativePath= "Resources/exports/" + fileName  + nameFile;




        try {
            FileWriter teacherWriter = new FileWriter(relativePath);

            if (AtribProposals.isEmpty())
                return false;
            for (Long key : AtribProposals.keySet()) {




                for (Long key2 : dGeneral.D1S.returnData().keySet()) {
                    if (key.equals(key2)) {
                        //teacherWriter.write(key.toString());
                        teacherWriter.write(AtribProposals.get(key));
                        teacherWriter.write("," + key2.toString());
                        for (Object k : dGeneral.D1S.returnData().get(key2))
                            teacherWriter.write("," + k.toString());
                    }
                }
                teacherWriter.write("\n");
            }
            teacherWriter.close();
            return true;
        } catch (IOException e) { //if file writer mandatory exception
            e.printStackTrace();
            return false;
        }

    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {
        return Utils.exportDelete(GpeState.ASSIGNEDPROPOSALS.toString()
        );
    }


    /**
     * Filter is active boolean.
     *
     * @param index the index
     * @return the boolean
     */
    public boolean filterIsActive(int index){
        index--;
        if(index < 0  || index > 4) {
            //Utils.errorPrint(Errors.INDEX_ERROR.getError());
            return false;
        }
        return dGeneral.filtercache[index];
    }


    /**
     * Filter string.
     *
     * @param filterChoice the filter choice
     * @return the string
     */
    public String filter(int filterChoice ){
        //ex [0 1 1 0]
        // 1-> Autoproposals of students.          // 2-> Proposals by teachers.
        // 3-> Available proposals.                // 4-> Proposals occupied.
        int sizeValues= 0, sizeValuesMax= 0;

        String tableLength;
        if(AtribProposals.isEmpty())
            return "Proposal list is empty!";

        filterChoice--;
        if(filterChoice < 0 || filterChoice > 3 )
            return Errors.INDEX_ERROR.getError() + "- Insert a valid index!";

        HashSet<String> filteredProposal = new HashSet<>(); //hashSet
        HashSet<String> filteredToDelete = new HashSet<>(); //hashSet
        HashSet<String> tempfilter = null;
        StringBuilder sb = new StringBuilder();

        if(dGeneral.filtercache[filterChoice])
            dGeneral.filtercache[filterChoice] = false;
        else
            dGeneral.filtercache[filterChoice] = true;



        if(dGeneral.filtercache[0]) { // 1-> Autoproposals of students.
            filteredProposal.addAll(hashAutoProposal());
        }
        if(dGeneral.filtercache[1]) {// 2-> Proposals by teachers.
            if(filteredProposal.isEmpty())
                filteredProposal.addAll(hashteacherProposal());
            else {
                tempfilter = hashteacherProposal();
                for (String prop : tempfilter)
                    if (!filteredProposal.contains(prop))
                        filteredToDelete.add(prop);

                for (String prop : filteredProposal)
                    if (!tempfilter.contains(prop))
                        filteredToDelete.add(prop);
            }
        }

        filteredProposal.removeAll(filteredToDelete);
        filteredToDelete.clear();


        if(dGeneral.filtercache[2]) {
            if(filteredProposal.isEmpty())
                filteredProposal.addAll(remainProposals());
            else {
                tempfilter = remainProposals();
                for (String prop : tempfilter)
                    if (!filteredProposal.contains(prop))
                        filteredToDelete.add(prop);

                for (String prop : filteredProposal)
                    if (!tempfilter.contains(prop))
                        filteredToDelete.add(prop);
            }
        }

        filteredProposal.removeAll(filteredToDelete);
        filteredToDelete.clear();

        if(dGeneral.filtercache[3]) {
            if(filteredProposal.isEmpty())
                filteredProposal.addAll(OccupiedProposals());
            else {
                tempfilter = OccupiedProposals();
                for (String prop : tempfilter)
                    if (!filteredProposal.contains(prop))
                        filteredToDelete.add(prop);

                for (String prop : filteredProposal)
                    if (!tempfilter.contains(prop))
                        filteredToDelete.add(prop);
            }
        }

        filteredProposal.removeAll(filteredToDelete);
        filteredToDelete.clear();



        return dGeneral.D2C.ToStringProp(filteredProposal);
    }

    /**
     * Contains i dand project boolean.
     *
     * @param proj the proj
     * @return the boolean
     */
    public boolean containsIDandProject(String proj){
        //USED AT PHASE 4
        for(long ids : AtribProposals.keySet())
            if(AtribProposals.get(ids).equals(proj)) {
                return true;
            }
        return false;
    }


    /**
     * Students without assign hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> studentsWithoutAssign(){
        HashSet<Long> studentsWithoutAssign = new HashSet<>();
        HashSet<Long> students = dGeneral.D1S.getStudentsIDs();
        for(Long key : students){
            if(!AtribProposals.containsKey(key)){
                studentsWithoutAssign.add(key);
            }
        }
        return studentsWithoutAssign;
    }

    /**
     * Get std id long.
     *
     * @param prop the prop
     * @return the long
     */
    public Long getStdId(String prop){
        for(Long number :AtribProposals.keySet()) {
            if (AtribProposals.get(number).equals(prop)) {
                return number;
            }
        }
        return 0L;
    }

    /**
     * Hash auto proposal hash set.
     *
     * @return the hash set
     */
    public HashSet<String> hashAutoProposal(){

        HashSet<String> stdChoosen = new HashSet<>();
        for (String key : dGeneral.D1P.returnData().keySet()) {
            ArrayList<Object> propos = dGeneral.D1P.returnData().get(key);
            if (propos.get(0).equals("T3")) {
                stdChoosen.add(key);
            }
        }


        return stdChoosen;
    }

    /**
     * Hashteacher proposal hash set.
     *
     * @return the hash set
     */
    public HashSet<String> hashteacherProposal(){
        HashSet<String> stdChoosen = new HashSet<>();
        for (String key : dGeneral.D1P.returnData().keySet()) {
            ArrayList<Object> propos = dGeneral.D1P.returnData().get(key);
            if (propos.get(0).equals("T2")) {
                stdChoosen.add(key);
            }
        }
        return stdChoosen;
    }


    /**
     * Delete all possible boolean.
     *
     * @return the boolean
     */


    /**
     * List students string.
     *
     * @param typeOFlist the type o flist
     * @return the string
     */
    public String listStudents(int typeOFlist){
        // 1 : with autoproposal
        // 2 : with candidature registed
        // 3 : have proposal atributed
        // 4 : without proposal assigned
        String[] printTitles= {"ID", "Name", "Mail", "Course", "Branch", "Grade", "Preference", "Proposal"};
        int[] sizeTitles1= {6, 6, 6, 6, 6, 6, 6, 6};
        String[] ord= {" ", " "," ", " ", " ", " ", " ", " "};

        HashSet<Long> stdChoosen = new HashSet<>();

        StringBuilder sb = new StringBuilder();
        switch (typeOFlist){
            case 1 -> {
                stdChoosen = new HashSet<Long>();

                for (String key : AtribProposals.values()) {
                    ArrayList<Object> propos = dGeneral.D1P.returnData().get(key);
                    if (propos.get(0).equals("T3") && !propos.get(5).equals("") && !propos.get(5).equals("0") ) {
                        stdChoosen.add((Long) propos.get(5));
                    }
                }
                return toString_compile(1, "","Auto Proposal\n", stdChoosen, printTitles,sizeTitles1, ord);
            }

            case 2-> {
                stdChoosen = new HashSet<Long>();
                for (long key : dGeneral.D2C.returnData().keySet()) {
                    if (!dGeneral.D1S.containsId(key))
                        continue;
                    stdChoosen.add(key);
                }
                return toString_compile(1, "","Assigned Candidature\n", stdChoosen, printTitles,sizeTitles1, ord);
            }

            case 3 ->{


                sb.append("Attributed Students : \n");

                for (Long key : AtribProposals.keySet()) {
                    if(dGeneral.D2C.getPreference(key,AtribProposals.get(key))!=9999)
                        stdChoosen.add(key);
                }
                return toString_compile(1, "","Attributed Students\n", stdChoosen, printTitles,sizeTitles1, ord);

            }
            case 4 ->{
                sb.append("STUDENTS WITHOUT ASSIGNED PROPOSAL").append("\n");
                HashSet<Long> remainStudents =  dGeneral.D1S.remainStudents();
                for(Long idStudent : remainStudents)
                    stdChoosen.add(idStudent);

                return toString_compile(1, "","WITHOUT ASSIGNED PROPOSAL\n", stdChoosen, printTitles,sizeTitles1, ord);
            }
        }
        return sb.toString();
    }


    /**
     * Hash prop assigned hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> hashPropAssigned(){
        HashSet<Long> stdChoosen = new HashSet<>();
        for (Long key : AtribProposals.keySet()) {
            if(dGeneral.D2C.getPreference(key,AtribProposals.get(key))!=9999)
                stdChoosen.add(key);
        }
        return stdChoosen;
    }


    /**
     * Get student long.
     *
     * @param proposal the proposal
     * @return the long
     */
    protected long getStudent(String proposal){
        for(Long std_id : AtribProposals.keySet())
            if(AtribProposals.get(std_id).equals(proposal))
                return std_id;

        return 0;
    }

    /**
     * Get prop string.
     *
     * @param id the id
     * @return the string
     */
    protected String getProp(Long id){
        return AtribProposals.get(id);
    }


    /**
     * Occupied proposals hash set.
     *
     * @return the hash set
     */
    protected HashSet<String> OccupiedProposals(){
        //USED AT PHASE 5
        HashSet<String> remainProposals = remainProposals();
        HashSet<String> occupiedProposals = new HashSet<>();
        for(String prop : AtribProposals.values())
            if(!remainProposals.contains(prop))
                occupiedProposals.add(prop);

        return occupiedProposals;
    }

    /**
     * Students with prop assigned hash set.
     *
     * @return the hash set
     */
    protected HashSet<Long> studentsWithPropAssigned(){
        //USED AT PHASE 5
        if(AtribProposals.isEmpty())
            return null;
        HashSet<Long> std = new HashSet<>();
        std.addAll(AtribProposals.keySet());
        return std;
    }


    /**
     * All with prop assigned hash set.
     *
     * @return the hash set
     */
    protected HashSet<String> AllWithPropAssigned(){
        //USED AT PHASE 5
        if(AtribProposals.isEmpty())
            return null;
        HashSet<String> proposal = new HashSet<>();
        proposal.addAll(AtribProposals.values());
        return proposal;
    }

/*
    public Boolean getNotDataPossible() {

        return AtribProposals.isEmpty();
    }
*/

    /**
     * Remain proposals hash set.
     *
     * @return the hash set
     */
    protected HashSet<String> remainProposals(){
        //USED AT PHASE 5
        HashSet<String> remainProposals = new HashSet<>();
        Map<String, ArrayList<Object>> proposals=dGeneral.D1P.dataP; //get data from proposals
        for(String keyProposals : proposals.keySet()) {                 //roam proposals
            ArrayList<Object> proposal = proposals.get(keyProposals);   //get info from proposal
            if(!(proposal.get(5).toString().equals(" ") || proposal.get(5).toString().equals("0")) || AtribProposals.containsValue(keyProposals) ) //if is atrributed
                continue;                                                                          //dont add
            remainProposals.add(keyProposals);
        }
        return remainProposals;
    }

    /**
     * Atribute proposals array list.
     *
     * @return the array list
     */
    public ArrayList<Object> atributeProposals(){ //for not autoproposals    -   GRADES EQUALS METHOD
        long choosenID;
        double biggestGrade;
        ArrayList<Object> info = new ArrayList<>();
        Map<String, ArrayList<Object>> proposals= dGeneral.D1P.dataP; //get data from proposals
        Map<Long, HashSet<String>> candidatures = dGeneral.D2C.dataCan; //get data from candidatures
        HashSet<String> remainProposals = remainProposals();                                //remain proposals
        HashSet<Long> availableStudents = new HashSet<>();


        for(String rem : remainProposals){           //roam available proposals
            biggestGrade = 0.00;
            choosenID =0;
            availableStudents.clear();                      //clear available students every cycle
            for(long num : candidatures.keySet()){           //search students candidate to that proposal
                HashSet<String> a = candidatures.get(num);
                if(a.contains(rem))                         //if student have a candidature to that proposal
                    availableStudents.add(num);
            }

            ArrayList<Long> toRemoveNum = new ArrayList<>();
            if(proposals.get(rem).get(0).equals("T1")){         //See if can do internship
                for(long num : availableStudents) {
                    ArrayList<Object> student = dGeneral.D1S.getStudentList(num);

                    if((student.get(5).toString().equals("false")))            //if not, remove
                        toRemoveNum.add(num);

                }

                availableStudents.removeAll(toRemoveNum);
            }

            for(long student_num : availableStudents) {     //get grade
                ArrayList<Object> student =dGeneral.D1S.getStudentList(student_num);  //search specific info from a student
                if(Double.parseDouble(student.get(4).toString()) >= biggestGrade){                    //if his grade is bigger
                    if(Double.parseDouble(student.get(4).toString()) == biggestGrade){
                        if(info.size() < 1) {
                            info.add(rem);
                            info.add(choosenID);
                        }
                        info.add(student_num);

                    }
                    else {
                        biggestGrade = Double.parseDouble(student.get(4).toString());
                        choosenID = student_num;// 0.3 0.3 0.9
                    }
                }
            }
            boolean delete = false;
            for(Object grade :info)
                if(grade instanceof Long) {
                    if (dGeneral.D1S.getGrade( Long.parseLong(grade.toString())) < biggestGrade) {
                        delete = true;

                    }
                }
            if(delete)
                info.clear();
            if(info.size() > 0 && info.size()<8)
                return info;
        }
        //T1 - ESTAGIO
        //T2 - PROJETO
        info.clear();
        return info;
    }


    /**
     * Atribute proposals remain boolean.
     *
     * @return the boolean
     */
    public Boolean atributeProposalsRemain(){ //for not autoproposals    -   GRADES EQUALS METHOD
        long choosenID;
        double biggestGrade;
        ArrayList<Object> info = new ArrayList<>();
        Map<String, ArrayList<Object>> proposals= dGeneral.D1P.dataP;   //get data from proposals
        Map<Long, HashSet<String>> candidatures = dGeneral.D2C.dataCan; //get data from candidatures
        HashSet<String> remainProposals = remainProposals();                                //remain proposals
        HashSet<Long> availableStudents = new HashSet<>();


        for(String rem : remainProposals){           //roam available proposals
            biggestGrade = 0.00;
            choosenID =0;
            availableStudents.clear();                      //clear available students every cycle
            for(long num : candidatures.keySet()){           //search students candidate to that proposal
                HashSet<String> a = candidatures.get(num);
                if(a.contains(rem) && !AtribProposals.containsKey(num))                         //if student have a candidature to that proposal
                    availableStudents.add(num);
            }

            ArrayList<Long> toRemoveNum = new ArrayList<>();
            if(proposals.get(rem).get(0).equals("T1")){         //See if can do internship
                for(long num : availableStudents) {
                    ArrayList<Object> student = dGeneral.D1S.getStudentList(num);

                    if((student.get(5).toString().equals("false")))            //if not, remove
                        toRemoveNum.add(num);

                }

                availableStudents.removeAll(toRemoveNum);
            }

            for(long student_num : availableStudents){     //get grade
                ArrayList<Object> student =dGeneral.D1S.getStudentList(student_num);  //search specific info from a student
                if(Double.parseDouble(student.get(4).toString()) >= biggestGrade){                    //if his grade is bigger
                    if(Double.parseDouble(student.get(4).toString()) == biggestGrade){
                        if(info.size() < 1) {
                            info.add(rem);
                            info.add(choosenID);
                        }
                        info.add(student_num);

                    }
                    else {
                        biggestGrade = Double.parseDouble(student.get(4).toString());
                        choosenID = student_num;// 0.3 0.3 0.9
                    }
                }
            }
            boolean delete = false;
            for(Object grade :info)
                if(grade instanceof Long) {
                    if (dGeneral.D1S.getGrade( Long.parseLong(grade.toString())) < biggestGrade) {
                        delete = true;
                    }
                }
            if(delete)
                info.clear();
            if(info.size() > 0 && info.size()<8) {
                AtribProposals.put(choosenID, rem);
            }
        }
        //T1 - ESTAGIO
        //T2 - PROJETO
        info.clear();
        return true;
    }

    /**
     * Gets prop.
     */
    public void getProp() {
        for (Long number : AtribProposals.keySet()) {
            System.out.println("Number : " + number + " prop: " + AtribProposals.get(number));
        }
    }


    /**
     * Atribute auto proposals boolean.
     *
     * @return the boolean
     */
    public boolean atributeAutoProposals(){
        long id = 0;

        Map<String, ArrayList<Object>> proposals= dGeneral.D1P.dataP; //get proposals

        for(String keyProposals : proposals.keySet()){                      //roam proposalData
            ArrayList<Object> propsN = proposals.get(keyProposals);
            if( (propsN.get(5).toString().equals("0")) || (propsN.get(5).toString().equals("")))                     //if dont have ID
                continue;
            id = Long.parseLong(propsN.get(5).toString());                  //transform into long
            if (!containsIDandProject(keyProposals) && !AtribProposals.containsKey(id)) {                    //if do not exist
                AtribProposals.put(id, keyProposals);
            }
        }
        return true;
    }


    /**
     * Get assigned prop hash map.
     *
     * @return the hash map
     */
    public HashMap<Long, ArrayList<Object>> getAssignedProp(){
        HashSet<Long> students = hashPropAssigned();
        HashMap<Long, ArrayList<Object>> info = new HashMap<>();
        for(Long key : students){
            ArrayList<Object> stdInfo = new ArrayList<>();
            stdInfo = dGeneral.D1S.getStudentList(key);
            if (dGeneral.D2C.getPreference(key, AtribProposals.get(key)) != 9999) {

                stdInfo.add(dGeneral.D2C.getPreference(key,String.valueOf(AtribProposals.get(key))));
                //col;
            }else
                stdInfo.add(" ");
            stdInfo.add(AtribProposals.get(key));
            info.put(key,stdInfo);
        }

        return info;
}


    /**
     * Without assigment hash map.
     *
     * @return the hash map
     */
    public HashMap<Long, ArrayList<Object>> withoutAssigment(){
        HashMap<Long, ArrayList<Object>> info = new HashMap<>();
        HashSet<Long> students= dGeneral.D1S.getHashStudent();
        for(Long key : students){
            ArrayList<Object> stdInfo = new ArrayList<>();
            if(AtribProposals.containsKey(key))
                continue;
            stdInfo = dGeneral.D1S.getStudentList(key);


                stdInfo.add(" ");
                stdInfo.add(" ");

            info.put(key,stdInfo);
        }

        return info;
    }

    /**
     * Registed cand hash map.
     *
     * @return the hash map
     */
    public HashMap<Long, ArrayList<Object>> registedCand(){
        HashMap<Long, ArrayList<Object>> info = new HashMap<>();
       // HashSet<Long> students= dGeneral.D1P.autoANDprop_teachersStudents();
        HashSet<Long> students= dGeneral.D2C.studentsWithCand();
        for(Long key : students){
            ArrayList<Object> stdInfo = new ArrayList<>();
            stdInfo = dGeneral.D1S.getStudentList(key);

            if (dGeneral.D2C.getPreference(key, AtribProposals.get(key)) != 9999) {
                stdInfo.add(dGeneral.D2C.getPreference(key,String.valueOf(AtribProposals.get(key))));
            }else
                stdInfo.add(" ");
            if(AtribProposals.containsKey(key))
                stdInfo.add(dGeneral.D2C.getPreference(key,String.valueOf(AtribProposals.get(key))));
            else
                stdInfo.add(" ");
            info.put(key,stdInfo);
        }

        return info;
    }


    /**
     * Auto proposal assigned hash map.
     *
     * @return the hash map
     */
    public HashMap<Long, ArrayList<Object>> autoProposalAssigned(){
        HashMap<Long, ArrayList<Object>> info = new HashMap<>();
        HashSet<Long> students= dGeneral.D1P.autoANDprop_teachersStudents();
        for(Long key : students){
            ArrayList<Object> stdInfo = new ArrayList<>();
            stdInfo = dGeneral.D1S.getStudentList(key);
            stdInfo.add(1);

            info.put(key,stdInfo);
        }

        return info;
    }

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    public HashMap<String, ArrayList<Object>> consultMode(int opc){

        HashMap<String, ArrayList<Object>> info = new HashMap<>();
        ArrayList<Object> stdInfo;


        switch (opc){

            case 1->{//Auto proposal
                HashSet<Long> students= dGeneral.D1P.autoANDprop_teachersStudents();
                for(Long key : students){
                    stdInfo = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    stdInfo = dGeneral.D1S.getStudentList(key);
                    stdInfo.add(1);
                    stdInfo.add(AtribProposals.get(key));

                   info.put(key.toString(),stdInfo);
                }
            }

            case 2->{//Registered Cand
                HashSet<Long> students= dGeneral.D2C.studentsWithCand();
                for(Long key : students){
                    stdInfo = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    stdInfo = dGeneral.D1S.getStudentList(key);

                    if (dGeneral.D2C.getPreference(key, AtribProposals.get(key)) != 9999) {
                        stdInfo.add(dGeneral.D2C.getPreference(key,String.valueOf(AtribProposals.get(key))));
                    }else
                        stdInfo.add(" ");

                    if(AtribProposals.containsKey(key))
                        stdInfo.add(AtribProposals.get(key));
                    else
                        stdInfo.add(" ");

                  info.put(key.toString(),stdInfo);
                }

            }
            case 3->{//Assigned Proprosals
                HashSet<Long> students = hashPropAssigned();
                for(Long key : students) {
                    stdInfo = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    stdInfo = dGeneral.D1S.getStudentList(key);

                    if (dGeneral.D2C.getPreference(key, AtribProposals.get(key)) != 9999) {
                        stdInfo.add(dGeneral.D2C.getPreference(key,String.valueOf(AtribProposals.get(key))));
                    }else
                        stdInfo.add(" ");

                    stdInfo.add(AtribProposals.get(key));

                    info.put(key.toString(),stdInfo);
                }


                }

            case 4->{//Without assignement
                HashSet<Long> students= dGeneral.D1S.getHashStudent();

                for(Long key : students){
                    stdInfo = new ArrayList<>();
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    if(AtribProposals.containsKey(key))
                        continue;
                    stdInfo = dGeneral.D1S.getStudentList(key);


                    stdInfo.add(" ");
                    stdInfo.add(" ");

                   info.put(key.toString(),stdInfo);
                }
            }
        }



        return info;
    }

    /**
     * Number cand vs assigned array list.
     *
     * @return the array list
     */
    public ArrayList<Integer> numberCandVSAssigned(){
        ArrayList<Integer> status = new ArrayList<>();
        status.add(remainProposals().size());status.add(AtribProposals.size());
        return status;
    }




    @Override
    public String toString() {
        if(AtribProposals.isEmpty())
            return Errors.START_ERROR.getError() + "\nLIST EMPTY!\n";
        StringBuilder sb = new StringBuilder();
        for(long ids : AtribProposals.keySet())
            sb.append(ids).append(" <--------> ").append(AtribProposals.get(ids)).append('\n');

        return sb.toString();
    }


    /**
     * To string compile string.
     *
     * @param column      the column
     * @param filter      the toStringfilter
     * @param title       the title
     * @param stdChoosen  the std choosen
     * @param printTitles the print titles
     * @param sizeTitles  the size titles
     * @param ord         the ord
     * @return the string
     */
    public String toString_compile(int column, String filter, String title, HashSet<Long> stdChoosen, String[] printTitles, int[] sizeTitles, String[] ord) {
        int countResults = 0, countFilters = 0,titlelinelength, lineLength = 0, k, numbchar=2, sizet, j,extraTitles =2,h = 0;
        boolean res;
        String ordervar = "↕ ";
        StringBuilder sb = new StringBuilder();
        ArrayList<Object> GetKeyArray;
        if(!title.equals(""))
            sb.append("\n" + title + "\n");
        ord[column-1] = ordervar; //icone of toStringfilter

        if (dGeneral.D1S.returnData() == null || dGeneral.D1S.returnData().isEmpty())
            sb.append("\nThe list is empty!\n");
        else {

            for (Long key : stdChoosen) {
                GetKeyArray = dGeneral.D1S.returnData().get(key);

                sizet = key.toString().length();
                if (sizet > sizeTitles[0])
                    sizeTitles[0] = sizet;

                if (printTitles[0].length() > sizeTitles[0])
                    sizeTitles[0] = printTitles[0].length();

                k = 0;
                j = 0;

                for(String str : printTitles) {

                    if (k<6 && j>0) {

                        sizet = GetKeyArray.get(k).toString().length();

                        if (sizet > sizeTitles[j]) {
                            sizeTitles[j] = sizet;
                        }
                        if (str.length() > sizeTitles[j])
                            sizeTitles[j] = str.length();

                        k++;
                    }
                    j++;
                }
            }

            k = 0;
            for(String str : printTitles) {

                sb.append(" ".repeat((sizeTitles[k])/2)).append(ord[k]).append(str).append(" ".repeat((sizeTitles[k])/2)); //titles print
                k++;

            }
            titlelinelength = sb.length()-title.length();


            String tableLength = "━".repeat(titlelinelength); //line after titles
            sb.append("\n").append(tableLength).append("\n");

            HashMap<Long, String> mp = new HashMap<Long, String>(); //order hasmap

            if (column == 1) {
                for (Long key : stdChoosen) {
                    mp.put(key, key.toString());

                }

            } else {
                for (Long key : stdChoosen) {
                    GetKeyArray= dGeneral.D1S.returnData().get(key);
                    mp.put(key, GetKeyArray.get(column - 2).toString());
                }
            }

            Map<Long, String> sortedMap = HashMapComp.longSortByComparator(mp);
            Set<Map.Entry<Long, String>> set = sortedMap.entrySet();
            // Get an iterator
            Iterator<Map.Entry<Long, String>> p = set.iterator();



            // Display elements
            while (p.hasNext()) {
                Map.Entry<Long, String> me = p.next();

                GetKeyArray = dGeneral.D1S.returnData().get(me.getKey());

                res = GetKeyArray.stream().anyMatch((a) -> a.toString().contains(filter));
                lineLength = sb.length() - lineLength - titlelinelength;

                if (res || me.getKey().toString().contains(filter)) {
                    sb.append(" ").append(me.getKey()).append(" ".repeat(sizeTitles[0] - me.getKey().toString().length()));

                    j = 1;
                    for (int i = 0; i < printTitles.length-extraTitles-1; i++) { //-1 without internship

                        sb.append("\t|\t").append(GetKeyArray.get(i)).append(" ".repeat((sizeTitles[j]) - GetKeyArray.get(i).toString().length()));

                        j++;

                    }
                    sb.append("\t");


                                if (dGeneral.D2C.getPreference(me.getKey(), AtribProposals.get(me.getKey())) != 9999) {
                                    sb.append("\t|\t").append(" ".repeat(((sizeTitles[printTitles.length-2]) / 2)-3)).append(dGeneral.D2C.getPreference(me.getKey(), AtribProposals.get(me.getKey()))).append(" ".repeat((sizeTitles[printTitles.length-2] / 2)-3)); //titles print
                                    sb.append("\t|\t").append(" ".repeat(((sizeTitles[printTitles.length-1]) / 2)-3)).append(AtribProposals.get(me.getKey())).append(" ".repeat(((sizeTitles[printTitles.length-1]) / 2)-3)); //titles print

                                } else {
                                    sb.append("\t|\t").append(" ".repeat(((sizeTitles[printTitles.length-2]) / 2) )).append(" ").append(" ".repeat((sizeTitles[printTitles.length-3] / 2)-3)); //titles print
                                    sb.append("\t|\t").append(" ".repeat(((sizeTitles[printTitles.length-1]) / 2) )).append(" ").append(" ".repeat(((sizeTitles[printTitles.length-2]) / 2)-3)); //titles print

                                }
                    sb.append("\t\n");

                    countFilters++;
                }
                countResults++;
            }
            sb.append(tableLength).append("\n ").append(countFilters).append(" of ").append(countResults).append(" ");

        }
        return sb.toString();
    }


}

