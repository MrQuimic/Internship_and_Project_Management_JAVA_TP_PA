/**
 * Class description:
 * <p>
 * Proposals of projects and internship data
 *
 * @author Carlos Santos {@literal <a2003035578@isec.pt>}
 * @author Leonardo Sousa {@literal <a2019129243@isec.pt>}
 * @date 2022/04/05
 */
package pt.isec.poe_deis_cl.model.data;

import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.Validators;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;

import java.io.*;
import java.util.*;


/**
 * The type Data in proposals.
 */
public class D1Proposals implements Serializable {
    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;
    /**
     * The Data p.
     */
    public Map<String, ArrayList<Object>> dataP;      //{ProposalID,INFO}
    /**
     * The D general.
     */
    DGeneral dGeneral;


    /**
     * Instantiates a new D 1 proposals.
     *
     * @param dGeneral the d general
     */
    public D1Proposals(DGeneral dGeneral) {
        this.dataP = new HashMap<>();
        this.dGeneral = dGeneral;

    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public Map<String, ArrayList<Object>> getData() {
        return dataP;
    }

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(Map<String, ArrayList<Object>> data) {
        this.dataP = data;
    }
    /**
     * Get data map.
     *
     * @return the map
     */

    /**
     * Return data map.
     *
     * @return the map
     */
    public Map<String, ArrayList<Object>> returnData(){
        return Map.copyOf(dataP);
    }


    /**
     * Add data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean AddData(String nameFile) {
        String relativePath;
        if(nameFile.isEmpty())
            relativePath = "Resources/imports/propostas.csv";
        else
            relativePath= "Resources/imports/" + nameFile;

        String scannedValue = "";
        String scanned = "";
        String type, key = "", branch = "", title = "", entity = "", docente = "";
        long aluno;
        File ProposalsFile = new File(relativePath);
        Scanner sc = null;
        Scanner sc_line = null;


        try {
            sc = new Scanner(ProposalsFile);

        } catch (FileNotFoundException e) {
            return false;
        }
        sc_line = new Scanner(scanned);
        sc.useDelimiter("[,;]");
        sc_line.useDelimiter("[,;]");

        while ((sc.hasNext())) {
            type = sc.next();
            try {
                key = sc.next();
            }catch(NoSuchElementException e){
                continue;
            }




            if (dataP.containsKey(key)) {
                sc.nextLine();
                continue;
            }

            ArrayList<Object> proposals = dataP.get(key);  //data is the Hashmap
            if (dataP.get(key) == null) {
                proposals = new ArrayList<>();

                if(!Validators.isStringValidProj(key).equals(Errors.PROJ_NUM_ERROR.toString()))
                    dataP.put(key, proposals); //inserts in the hasmap if it does not exist yet

            }

            scanned = sc.nextLine();
            sc_line = new Scanner(scanned);
            sc_line.useDelimiter(",");

            proposals.add(type);
            if (type.equals("T1")) {
                if (sc_line.hasNext())
                    branch = sc_line.next();
                else
                    branch = " ";

                proposals.add(branch);

                if (sc_line.hasNext())
                    title = sc_line.next();
                else
                    title = " ";
                proposals.add(title);

                if (sc_line.hasNext())
                    entity = sc_line.next();
                else
                    entity = " ";
                proposals.add(entity);

                docente = " ";
                proposals.add(docente);

                if (sc_line.hasNext()) {
                    aluno = sc_line.nextLong();
                    if ((!dGeneral.D1S.containsId(aluno)) || getPropRegisted(aluno)) {
                        dataP.remove(key);
                        continue;
                    }
                }
                else {
                    aluno = 0;
                }

                proposals.add(aluno);

            } else if (type.equals("T2")) {
                if (sc_line.hasNext())
                    branch = sc_line.next();
                else
                    branch = " ";
                proposals.add(branch);

                if (sc_line.hasNext())
                    title = sc_line.next();
                else
                    title = " ";
                proposals.add(title);

                entity = " ";
                proposals.add(entity);


                if (sc_line.hasNext())
                    docente = sc_line.next();
                else
                    docente = " ";

                if (dGeneral.D1T.containsMail(docente).equals(Errors.EMAILNOTFOUND_ERROR.toString())){
                    dataP.remove(key);
                    continue;
                }

                proposals.add(docente); //if docente exists



                if (sc_line.hasNext()) {
                    aluno = sc_line.nextLong();
                    if ((!dGeneral.D1S.containsId(aluno)) || getPropRegisted(aluno)) {
                        dataP.remove(key);
                        continue;

                    }
                }
                else {
                    aluno = 0;
                }

                proposals.add(aluno);

            } else if (type.equals("T3")) {
                branch = " ";
                proposals.add(branch);

                if (sc_line.hasNext())
                    title = sc_line.next();
                else
                    title = " ";
                proposals.add(title);

                entity = " ";
                proposals.add(entity);

                docente = " ";
                proposals.add(docente);

                if (sc_line.hasNext())
                    try {
                        aluno = sc_line.nextLong();
                    }catch (InputMismatchException e){
                        dataP.remove(key);
                        continue;
                    }

                else
                    aluno = 0;

                if ((!dGeneral.D1S.containsId(aluno) && aluno!=0) || getPropRegisted(aluno)){
                    dataP.remove(key);
                    continue;
                }
                proposals.add(aluno);



            }else{
                dataP.remove(key);
                continue;
            }

            while (sc_line.hasNext()) {
                scannedValue = sc_line.next();
                proposals.add(scannedValue);
            }

        }

        return true;
    }

    /**
     * Get branch type string.
     *
     * @param prop the prop
     * @return the string
     */
    public String getBranchType(String prop){
        if(!dataP.containsKey(prop))
            return null;

        return  dataP.get(prop).get(1).toString();
    }


    /**
     * Edit proposal boolean.
     *
     * @param id         the id
     * @param newChanges the new changes
     * @return the boolean
     */
    public boolean editProposal(String id, ArrayList<Object> newChanges) {

        ArrayList<Object> edtProposal = dataP.get(id);
        if (edtProposal.isEmpty())
            return false;

        edtProposal.clear();
        if(newChanges == null)
            return false;
        for (Object value : newChanges)
            edtProposal.add(value);

        return true;
    }

    /**
     * Delete boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean delete(String id) {
        if (!dataP.containsKey(id))
            return false;
        dataP.remove(id);
        return true;
    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        dataP.clear();
        return true;
    }

    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {
        String relativePath;
        Utils.fileExists(GpeState.PROPOSALS.toString(), "exports");
        String fileName = GpeState.PROPOSALS + "_";
        String type = "";

        if(nameFile.isEmpty())
            relativePath = "Resources/exports/" + fileName + dGeneral.CurrentDate + ".csv";
        else
            relativePath= "Resources/exports/" + fileName + nameFile;


        try {
            FileWriter proposalsWriter = new FileWriter(relativePath);

            if (dataP.isEmpty())
                return false;
            for (String key : dataP.keySet()) {
                proposalsWriter.write(key.toString() + ",");
                ArrayList<Object> candidature = dataP.get(key);
                type = candidature.get(0).toString();
                proposalsWriter.write(type + "," + key);
                for (Object projs : candidature)
                    if (!projs.equals(type) && !projs.equals(" ") && !String.valueOf(projs).equals("0"))
                        proposalsWriter.write("," + projs);


                proposalsWriter.write("\n");
            }

            proposalsWriter.close();
        } catch (IOException e) {
            Utils.errorPrint(Errors.EXCEPTION_GENERAL_ERROR.getError() + e + " !");
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {

        return Utils.exportDelete(GpeState.PROPOSALS.toString()
        );
    }

    /**
     * Amount of data.
     *
     * @return the int total quantity of proposals
     */
    protected int amountOF() {
        if (dataP.isEmpty())
            return 0;
        return dataP.size();
    }

    /**
     * Sets proposal instance.
     *
     * @param proposal_instance the proposal instance
     */


    /**
     * Contains id boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean containsId(String id) {
        if (!dataP.containsKey(id))
            return false;
        return true;
    }


    /**
     * Get prop string.
     *
     * @param prop the prop
     * @return the string
     */
    protected String getProp(String prop){
        int i=0;

        ArrayList<Object> specifProp = dataP.get(prop);
        if(specifProp.isEmpty())
            return "PROPOSAL NOT FOUND!\n";
        StringBuilder sb = new StringBuilder();
        sb.append(" Proposal "+ prop+":  \uD83C\uDFF7 ");


        for(Object value : specifProp) {

            if(value instanceof Long)
                sb.append("  \uD83C\uDFF7  ").append((dGeneral.D1S.getName(Long.parseLong(value.toString()))));

            if (!value.toString().equals(" ")) {
                if (value.toString().equals("0"))
                    value = " ";

                sb.append(value);
                if (i==0 && value.toString().equals("T3"))
                    sb.append(" | ");
                else if (i==0 && !value.toString().equals("T3"))
                    sb.append(" | ");
                else
                    sb.append("  \uD83C\uDFF7  ");
                i++;
            }

        }

        return sb.toString();
    }

    /**
     * List auto proposal string.
     *
     * @return the string
     */
    String listAutoProposal() {
        String[] printTitles= {"ID", "Name", "Email", "Course", "Branch", "Grade"};
        int[] sizeTitles1= {6, 6, 6, 6, 6, 6};
        String[] ord= {" ", " "," ", " ", " ", " "};


        HashSet<Long> stdChoosen = new HashSet<Long>();
        for (String key : dataP.keySet()) {
            ArrayList<Object> propos = dataP.get(key);
            if (propos.get(0).equals("T3")) {
                stdChoosen.add((Long) propos.get(5));
            }
        }


        return dGeneral.D1S.toString_compile(1, "","Auto-Proposal \n", stdChoosen, printTitles,sizeTitles1, ord);

    }



    private boolean getPropRegisted(long idStudent){
        int count;
        for(String key : dataP.keySet()){
            ArrayList<Object> propos = dataP.get(key);
            if(propos.contains(idStudent))
                return true;
        }
        return false;
    }

    /*
    public Boolean getdataPossible() {

            return dataP.isEmpty();
    }*/

    /**
     * Get info prop array list.
     *
     * @param prop the prop
     * @return the array list
     */
    public ArrayList<Object> getInfoProp(String prop){
        if(!dataP.containsKey(prop))
            return null;
        return dataP.get(prop);
    }

    /**
     * Top entity hash map.
     *
     * @return the hash map
     */
    public HashMap<String,Integer> topEntity(){
        HashMap<String,Integer> ADrank = new HashMap<>();
        for(String prop : dataP.keySet()){
            ArrayList<Object> info = new ArrayList<>(dataP.get(prop));
            if(info.get(3).toString().equals(" "))
                continue;
            if(ADrank.containsKey(info.get(3).toString()))
                ADrank.put(info.get(3).toString(),ADrank.get(info.get(3).toString())+1);
            else
                ADrank.put(info.get(3).toString(),1);
        }
        return ADrank;
    }


    /**
     * Auto an dprop teachers students hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> autoANDprop_teachersStudents(){
        HashSet<Long> Students_autoANDprop = new HashSet<>();                            //autoproposed students/teacher proposal
        Map<String, ArrayList<Object>> proposals= dataP;  //get data from proposal
        for(String keyProposals: proposals.keySet()){                                    //percorre propostas
            ArrayList<Object> proposal = proposals.get(keyProposals);                    //obtem informação de tais propostas
            if(!(proposal.get(5).toString().equals(" ")||proposal.get(5).toString().equals("0")))   //se contiver informação de atribuição
                Students_autoANDprop.add(Long.parseLong(proposal.get(5).toString()));               //adiciona o idStudent(long)
        }
        return Students_autoANDprop;
    }

    /**
     * Auto an dprop teachers students str hash set.
     *
     * @return the hash set
     */
    public HashSet<String> autoANDprop_teachersStudentsStr(){
        HashSet<String> Students_autoANDprop = new HashSet<>();                            //autoproposed students/teacher proposal
        Map<String, ArrayList<Object>> proposals= dataP;  //get data from proposal
        for(String keyProposals: proposals.keySet()){                                    //percorre propostas
            ArrayList<Object> proposal = proposals.get(keyProposals);                    //obtem informação de tais propostas
            if(!(proposal.get(5).toString().equals(" ")||proposal.get(5).toString().equals("0")))   //se contiver informação de atribuição
                Students_autoANDprop.add(keyProposals);               //adiciona o idStudent(long)
        }
        return Students_autoANDprop;
    }

    /**
     * Only teacher proposals students hash map.
     *
     * @return the hash map
     */
    public HashMap<String,String> onlyTeacherProposalsStudents(){
        //USED AT PHASE 4
        HashMap<String,String> Students_teacherPropos = new HashMap<>();      //list students autoproposed (TIPO :  T3 )
        Map<String, ArrayList<Object>> proposals= dataP; //get data from proposals
        for(String keyProposals: proposals.keySet()){                                   //roam proposal
            ArrayList<Object> proposal = proposals.get(keyProposals);       //get info of proposals
            if(!(proposal.get(5).toString().equals(" ") || proposal.get(5).toString().equals("0")) && proposal.get(0).toString().equals("T2")) { //if proposed by teacher
                Students_teacherPropos.put(keyProposals, proposal.get(4).toString());      //add

            }
        }
        return Students_teacherPropos;
    }


    private HashSet<Long> onlyAutoStudents(){
        HashSet<Long> Students_auto = new HashSet<>();      //list of autoproposal students (type :  T3 )
        Map<String, ArrayList<Object>> proposals= dataP; //get data from proposals
        for(String keyProposals: proposals.keySet()){                                   //roam proposal
            ArrayList<Object> proposal = proposals.get(keyProposals);       //get information from proposals
            if(!(proposal.get(5).toString().equals(" ")||proposal.get(5).toString().equals("0")) && proposal.get(0).toString().equals("T3")) //if autoproposal
                Students_auto.add(Long.parseLong(proposal.get(5).toString()));      //add
        }
        return Students_auto;
    }

    /**
     * To string string.
     *
     * @param column the column
     * @param filter the toStringfilter
     * @return the string
     */
    public String toString(int column, String filter) {

        String[] printTitles= {"ID", "Type", "branch", "Title", "Entity", "Email", "StudentNum"};
        int[] sizeTitles1= {6, 6, 6, 6, 6, 6, 6};
        String[] ord= {" ", " "," ", " ", " ", " ", " "};


        HashSet<String> stdChoosen = new HashSet<>();

        for (String key : dataP.keySet()) {
            stdChoosen.add(key);
        }
        return toString_compile(column, filter, "PROPOSALS: \n", stdChoosen, printTitles,sizeTitles1, ord);

    }

    /**
     * Number of cand int.
     *
     * @return the int
     */
    public int numberOfCand(){
        return dataP.size();
}

    /**
     * To string compile string.
     *
     * @param column      the column
     * @param filter      the toStringfilter
     * @param title       the title
     * @param stdChoosen  the std choosen
     * @param printTitles the print titles
     * @param sizeTitles  the size titles
     * @param ord         the ord
     * @return the string
     */
    public String toString_compile(int column, String filter, String title, HashSet<String> stdChoosen, String[] printTitles, int[] sizeTitles, String[] ord) {
        int countResults = 0, countFilters = 0,titlelinelength, lineLength = 0, k, sizet, j;
        boolean res;
        String ordervar = "↕ ";
        Object attr;
        StringBuilder sb = new StringBuilder();
        ArrayList<Object> GetKeyArray;
        if(!title.equals(""))
            sb.append("\n" + title + "\n");
        try {
            ord[column - 1] = ordervar; //icone of toStringfilter
        }catch (ArrayIndexOutOfBoundsException e){
            ord[0] = ordervar; //icone of toStringfilter
            column=1;
        }

        if (dataP == null || dataP.isEmpty())
            sb.append("\nThe list is empty!\n");
        else {

            for (String key : stdChoosen) {
                GetKeyArray = dataP.get(key);

                sizet = key.length();
                if (sizet > sizeTitles[0])
                    sizeTitles[0] = sizet;

                if (printTitles[0].length() > sizeTitles[0])
                    sizeTitles[0] = printTitles[0].length();

                k = 0;
                j = 0;

                for(String str : printTitles) {

                    if (k<6 && j>0) {

                        sizet = GetKeyArray.get(k).toString().length();

                        if (sizet > sizeTitles[j]) {
                            sizeTitles[j] = sizet;
                        }
                        if (str.length() > sizeTitles[j])
                            sizeTitles[j] = str.length();

                        k++;
                    }
                    j++;
                }
            }

            k = 0;
            for(String str : printTitles) {

                sb.append(" ".repeat((sizeTitles[k])/2)).append(ord[k]).append(str).append(" ".repeat((sizeTitles[k])/2)); //titles print
                k++;

            }

            titlelinelength = sb.length()-title.length();
            String tableLength = "━".repeat(titlelinelength); //line after titles
            sb.append("\n").append(tableLength).append("\n");

            HashMap<String, String> mp = new HashMap<>(); //order hasmap

            if (column == 1) {

                for (String key : stdChoosen) {
                    mp.put(key, key.toString());

                }
            } else {
                for (String key : stdChoosen) {
                    GetKeyArray= dataP.get(key);
                    mp.put(key, GetKeyArray.get(column - 2).toString());
                }
            }

            Map<String, String> sortedMap = HashMapComp.stringSortByComparator(mp);
            Set<Map.Entry<String, String>> set = sortedMap.entrySet();
            // Get an iterator
            Iterator<Map.Entry<String, String>> p = set.iterator();


            // Display elements
            while (p.hasNext()) {
                Map.Entry<String, String> me = p.next();

                GetKeyArray = dataP.get(me.getKey());

                res = GetKeyArray.stream().anyMatch((a) -> a.toString().contains(filter));
                lineLength = sb.length() - lineLength - titlelinelength;

                if (res || me.getKey().toString().contains(filter)) {
                    sb.append(" ").append(me.getKey()).append(" ".repeat(sizeTitles[0] - me.getKey().toString().length()));

                    j = 1;
                    for (int i = 0; i < printTitles.length-1; i++) {
                        attr = GetKeyArray.get(i);
                        if (Objects.equals(attr.toString(), "0"))
                            attr = "";

                        sb.append("\t|\t").append(attr).append(" ".repeat((sizeTitles[j]) - attr.toString().length()));
                        j++;
                    }
                    sb.append("\t\n");


                    countFilters++;
                }
                countResults++;
            }
            sb.append(tableLength).append("\n ").append(countFilters).append(" of ").append(countResults).append(" ");

        }
        return sb.toString();
    }
}
