package pt.isec.poe_deis_cl.model.data;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;

import java.io.Serializable;
import java.util.*;

/**
 * The type Phase 5.
 */
public class D5Consult  implements Serializable {

    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;
    /**
     * The D general.
     */
    DGeneral dGeneral;

    /**
     * Instantiates a new D 5 consult.
     *
     * @param dGeneral the d general
     */
    public D5Consult(DGeneral dGeneral) {

        this.dGeneral = dGeneral;
    }

    /**
     * List std with proposals assigned string.
     *
     * @return the string
     */
    public String listStdWithProposalsAssigned() {
        //list of students with assigned proposals. fetch to phase 3.
        HashSet<Long> stdAssigned = dGeneral.D3P.studentsWithPropAssigned(); //will look for students with assigned proposal
        String[] printTitles = {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " "};

        if (stdAssigned.isEmpty())
            return Errors.START_ERROR.getError() + "There's no students with a proposal assigned!\n";

        return dGeneral.D1S.toString_compile(1, "", "List of students with proposal assigned!\n", stdAssigned, printTitles, sizeTitles1, ord);
    }

    /**
     * List std without assig and cand string.
     *
     * @return the string
     */
    public String listStdWithoutAssigAndCand() {
        //list of students with no proposals assigned and with application options.
        HashSet<Long> students = dGeneral.D2C.remainStudentsWithCandidatures();
        String[] printTitles = {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " "};

        if (students.isEmpty())
            return Errors.START_ERROR.getError() + "NO STUDENTS WITHOUT ASSIGNMENT AND WITH CANDIDATURE!";

        return dGeneral.D1S.toString_compile(1, "", "List of students with candidature with no proposa!\n", students, printTitles, sizeTitles1, ord);
    }

    /**
     * Lis t with all proposals assigned string.
     *
     * @return the string
     */
    public String lisTWithAllProposalsAssigned() {
        //list of students with assigned proposals. fetch to phase 3.
        HashSet<String> stdAssigned = dGeneral.D3P.AllWithPropAssigned(); //will look for students with assigned proposal
        String[] printTitles = {"ID", "Type", "branch", "Title", "Entity", "Email", "StudentNum"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " ", " "};

        if (stdAssigned.isEmpty())
            return Errors.START_ERROR.getError() + "There's no students with a proposal assigned!\n";

        return dGeneral.D1P.toString_compile(1, "", "ASSIGNEDPROPOSALS AVAILABLE: \n", stdAssigned, printTitles, sizeTitles1, ord);
    }

    /**
     * List prop available string.
     *
     * @return the string
     */
    public String listPropAvailable() {
        //set of available proposals.
        HashSet<String> rmnProposals = dGeneral.D3P.remainProposals();

        String[] printTitles = {"ID", "Type", "branch", "Title", "Entity", "Email", "StudentNum"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " ", " "};

        if (rmnProposals.isEmpty())
            return Errors.START_ERROR.getError() + "NO ASSIGNEDPROPOSALS AVAILABLE AT THE MOMENT!";


        return dGeneral.D1P.toString_compile(1, "", "ASSIGNEDPROPOSALS AVAILABLE: \n", rmnProposals, printTitles, sizeTitles1, ord);
    }

    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {

        return (dGeneral.D1P.exportData(nameFile) &&
                dGeneral.D1T.exportData(nameFile) &&
                dGeneral.D1S.exportData(nameFile) &&
                dGeneral.D2C.exportData(nameFile) &&
                dGeneral.D3P.exportData(nameFile) &&
                dGeneral.D4A.exportData(nameFile));

    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {

        return (dGeneral.D1P.exportDelete() &&
                dGeneral.D1T.exportDelete() &&
                dGeneral.D1S.exportDelete() &&
                dGeneral.D2C.exportDelete() &&
                dGeneral.D3P.exportDelete() &&
                dGeneral.D4A.exportDelete());
    }

    /**
     * Occupied prop string.
     *
     * @return the string
     */
    public String occupiedProp() {
        //set of assigned proposals.
        HashSet<String> occupiedProp = dGeneral.D3P.OccupiedProposals();

        String[] printTitles = {"ID", "Type", "branch", "Title", "Entity", "Email", "StudentNum"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " ", " "};

        if (occupiedProp.isEmpty())
            return Errors.START_ERROR.getError() + "NO ASSIGNEDPROPOSALS OCCUPIED AT THE MOMENT!";


        return dGeneral.D1P.toString_compile(1, "", "ASSIGNEDPROPOSALS OCCUPIED: \n", occupiedProp, printTitles, sizeTitles1, ord);
    }


    /**
     * Advisors general status string.
     *
     * @return the string
     */
    public String advisorsGeneralStatus() {
        //number of orientations per teacher, on average, minimum, maximum.
        return dGeneral.D4A.advisorsGeneralStats();
    }

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    public HashMap<String,ArrayList<Object>> consultMode(int opc){
        HashMap<String,ArrayList<Object>> infoCons = new HashMap<>();
        ArrayList<Object> info ;
        switch (opc) {
            case 1 -> { // Students with assigned proposals
                ArrayList<Object> aux;
                infoCons = dGeneral.D3P.consultMode(3);
                for (String inf : infoCons.keySet()) {
                    aux = new ArrayList<>();
                    aux = infoCons.get(inf);
                    if (aux != null) {
                        aux.remove(aux.size() - 1);
                        aux.remove(aux.size() - 1);
                    }
                }
            }
            case 2 -> { // Students with candidatures and without assigned proposals
                HashSet<Long> studentsWithCand = dGeneral.D2C.remainStudentsWithCandidatures();
                for (Long num : studentsWithCand) {
                    if (!dGeneral.D1S.containsId(num))
                        continue;
                    info = new ArrayList<>();
                    info.addAll(dGeneral.D1S.getStudentList(num));
                    infoCons.put(num.toString(), info);
                }
            }
            case 3 -> { // Available proposals
                HashSet<String> occupiedProp = dGeneral.D3P.OccupiedProposals();

                HashSet<String> remainProposals = dGeneral.D3P.remainProposals();
                for (String num : remainProposals) {
                    if (!dGeneral.D1P.containsId(num) || occupiedProp.contains(num))
                        continue;
                    info = new ArrayList<>();
                    info.addAll(dGeneral.D1P.getInfoProp(num));
                    infoCons.put(num, info);
                }
            }
            case 4 -> { // Assigned Proposals
                HashSet<String> occupiedProp = dGeneral.D3P.OccupiedProposals();
                for (String num : occupiedProp) {
                    if (!dGeneral.D1P.containsId(num))
                        continue;
                    info = new ArrayList<>();
                    info.addAll(dGeneral.D1P.getInfoProp(num));
                    infoCons.put(num, info);
                }
            }
            case 5 -> { // All data proposal assigned
                Map<Long, String> atribProp = dGeneral.D3P.getData();
                for (Long num : atribProp.keySet()) {
                    if (!dGeneral.D1S.containsId(num))
                        continue;
                    info = new ArrayList<>();
                    info.add(dGeneral.D1S.getName(num));
                    info.add(atribProp.get(num));
                    infoCons.put(num.toString(), info);
                }
            }
        }

        //System.out.println("----------------------------------------------------------------------------------");
       // System.out.println(opc);
        //for(String a : infoCons.keySet()){
           // System.out.println(a.toString() + infoCons.get(a));
       // }
       // System.out.println("----------------------------------------------------------------------------------");

        return infoCons;
    }

    /**
     * Pie chart info observable list.
     *
     * @param opc the opc
     * @return the observable list
     */
    public ObservableList<PieChart.Data> pieChartInfo(int opc){
        ObservableList<PieChart.Data> pieData = null;
        switch (opc){
            case 1->{ // Distribuicao de estagios/projetos por ramos (DA/RAS/SI)
                HashSet<String> assignedprop =dGeneral.D3P.AllWithPropAssigned();
                int da,si,ras;
                da = si = ras = 0;
                for(String key : assignedprop){
                    if(dGeneral.D1P.getBranchType(key) == null)
                        continue;
                    switch (dGeneral.D1P.getBranchType(key)){
                        case "SI" -> si++;
                        case "RAS" -> ras++;
                        default -> da++;
                    }
                }
                pieData = FXCollections.observableArrayList(
                        new PieChart.Data("DA",da), new PieChart.Data("SI",si), new PieChart.Data("RAS",ras)
                );
            }
            case 2-> { // Percentagens e valores absolutos sobre propostas atribuidas e nao atribuidas
                //System.out.println();
                ArrayList<Integer> status = dGeneral.D3P.numberCandVSAssigned();
                pieData = FXCollections.observableArrayList(
                        new PieChart.Data("Proposals Available",status.get(0)), new PieChart.Data("Proposals assigned",status.get(1)));
            }
        }



        return pieData;
    }

    /**
     * Bar chart info xy chart . series.
     *
     * @param opc the opc
     * @return the xy chart . series
     */
    public XYChart.Series<String,Integer> barChartInfo(int opc){
        XYChart.Series<String,Integer> series = new XYChart.Series<>();
        switch (opc) {
            case 1->{// (GRAFICO DE BARRAS) TOP 5 empresas com mais estagios
                HashMap<String,Integer> top = dGeneral.D1P.topEntity();
                //for(String a : top.keySet())
                //    System.out.println(a + " " + top.get(a));
                //System.out.println("----------------------------------------------------");

                Map<String, Integer> rankedTop = HashMapComp.intSortByComparator(top);
                //System.out.println("Estou aqui");
                //for(String a : rankedTop.keySet())
                 //   System.out.println(a + " " + rankedTop.get(a));

                for(String a : rankedTop.keySet()) {
                    if(a.length() > 13){
                        String newString = new String();
                        newString = a.substring(0,10);
                        String strfinal = newString + "...";
                        series.getData().add(new XYChart.Data(strfinal, rankedTop.get(a)));
                    }
                    else
                        series.getData().add(new XYChart.Data(a, rankedTop.get(a)));
                }
            }

            case 2->{//(GRAFICO DE BARRAS) TOP 5 advisors com mais adivsorments
                HashMap<String,Integer> top = dGeneral.D4A.topAdvisors();
                //for(String a : top.keySet())
                //    System.out.println(a + " " + top.get(a));
                //System.out.println("----------------------------------------------------");
                Map<String, Integer> rankedTop = HashMapComp.intSortByComparator(top);
                //System.out.println("Estou aqui");
                //for(String a : rankedTop.keySet())
                 //   System.out.println(a + " " + rankedTop.get(a));

                for(String a : rankedTop.keySet()) {
                    series.getData().add(new XYChart.Data(a, rankedTop.get(a)));
                }
            }

        }
        return series;
    }
}
