
package pt.isec.poe_deis_cl.model.data;

import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;
import pt.isec.poe_deis_cl.utils.Validators;
import pt.isec.poe_deis_cl.utils.Utils;

import java.io.File;
import java.io.FileNotFoundException;

import java.io.*;
import java.util.*;

/**
 * Class description:
 * <br>
 * Student data
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class D1Students implements Serializable {

    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;

    /**
     * The Data s.
     */
    public Map<Long, ArrayList<Object>> dataS; //    {id,info}

    /**
     * The D general.
     */
    DGeneral dGeneral;

    /**
     * Instantiates a new D 1 students.
     *
     * @param dGeneral the d general
     */
    public D1Students(DGeneral dGeneral) {
        this.dataS = new HashMap<>();
        this.dGeneral = dGeneral;

    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public Map<Long, ArrayList<Object>> getData() {
        return dataS;
    }
    /**
     * Gets data.
     *
     * @return the data
     */

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(Map<Long, ArrayList<Object>> data) {
        this.dataS = data;
    }

    /**
     * Add data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean AddData(String nameFile) {
        String relativePath;
        if(nameFile.isEmpty())
            relativePath = "Resources/imports/alunos.csv";
        else
            relativePath= "Resources/imports/" + nameFile;

        long idNum = 0;
        boolean internshipBool = false;
        double gradeDouble = 0;
        File StudentFile = new File(relativePath);
        Scanner sc = null;
        try {
            sc = new Scanner(StudentFile);
        } catch (FileNotFoundException e) {

            return false;
        }

        sc.useDelimiter("[,;\r\n]");

        while ((sc.hasNext())) {
            String id = sc.next();
            try {
                idNum = Long.parseLong(id);
            } catch (NumberFormatException e) {
                sc.nextLine();
                continue;
            }

            if (dataS.containsKey(idNum)   ) {
                sc.nextLine();
                continue;
            }

            ArrayList<Object> student = dataS.get(idNum);  //data is the Hashmap
            if (dataS.get(idNum) == null) {
                student = new ArrayList<Object>();
                dataS.put(idNum, student); //inserts in the hasmap if it does not exist yet
            }

            for (int i = 0; i < 6; i++) {
                String getit;
                try {
                    getit = sc.next();
                } catch (NoSuchElementException e) {

                    dataS.clear();
                    return false;
                }

                switch (i) {
                    case 1 -> {
                        getit = containsStuMail(idNum, Validators.isStringValidEmail(getit)); //Checks valid email format
                        if(dGeneral.D1T.containsMail(getit).equals(getit)) {
                            dataS.remove(student);
                            sc.nextLine();
                            break;
                        }

                    }
                    case 2 -> getit = Validators.checkValidCourse(getit); //Checks valid double format

                    case 3 -> getit = Validators.checkValidBranch(getit); //Checks valid double format

                    case 4 -> {
                        getit = Validators.checkValidGrade(getit); //Checks valid double format
                        try {
                            gradeDouble = Double.parseDouble(getit);
                        } catch (NumberFormatException e) {
                            gradeDouble = 0.00;
                        }
                        student.add(i, gradeDouble);
                    }
                    case 5 -> {
                        getit = Validators.isStringBoolean(getit); //Checks if it is boolean
                        internshipBool = Boolean.parseBoolean(getit); //returns false if does not match true
                        student.add(i, internshipBool);
                    }
                }

                if (i <= 3)
                    student.add(i, getit);

            }

            if (sc.hasNext())
                sc.nextLine();
        }




        return true;

    }

    /**
     * Manual add student int.
     *
     * @param id         the id
     * @param name       the name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the int
     */
    public int manualAddStudent(String id, String name, String mail, String course, String branch, String grade, String internship){
        long Id;double Grade;Boolean Internship;
        ArrayList<Object> info = new ArrayList<>();
        try{
            Id = Long.parseLong(id);
            Grade = Double.parseDouble(grade);
            Internship =Boolean.parseBoolean(internship);
        }catch (Exception e) {
            return -1;
        }
        if(dataS.containsKey(Id))
            return -2;
        else if(dGeneral.D1T.containsMail(mail).equals(mail))
            return -3;
        else if(Grade < 0 || Grade > 1)
            return -4;
        info.add(name);
        info.add( Validators.isStringValidEmail(mail));
        info.add( Validators.checkValidCourse(course));
        info.add( Validators.checkValidBranch(branch));
        info.add(Grade);info.add(Internship);
        dataS.put(Id,info);
        return 0;
    }

    /**
     * Return data map.
     *
     * @return the map
     */
    public Map<Long, ArrayList<Object>> returnData(){
        return Map.copyOf(dataS);
    }

    /**
     * Edit student boolean.
     *
     * @param id         the id
     * @param name       the name
     * @param mail       the mail
     * @param course     the course
     * @param branch     the branch
     * @param grade      the grade
     * @param internship the internship
     * @return the boolean
     */
    public boolean editStudent(long id, String name, String mail, String course, String branch, double grade, boolean internship) {
        ArrayList<Object> student = dataS.get(id);
        if (student == null)
            return false;

        int i = 0;
        student.clear();
        student.add(i++, name);
        student.add(i++, Validators.isStringValidEmail(mail));
        student.add(i++, Validators.checkValidCourse(course));
        student.add(i++, Validators.checkValidBranch(branch));
        student.add(i++, grade);
        student.add(i, internship);


        return true;
    }


    /**
     * Delete boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean delete(String id) {
        long id_num = 0;
        try {
            id_num = Long.parseLong(id);
        } catch (Exception e) {
            return false;
        }
        if (!dataS.containsKey(id_num))
            return false;
        dataS.remove(id_num);
        return true;
    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        dataS.clear();
        return true;
    }

    /**
     * Is empty boolean.
     *
     * @return the boolean
     */
    public boolean isEmpty(){
        return dataS.isEmpty();
    }

    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {
        String relativePath;
        Utils.fileExists(GpeState.STUDENTS.toString(), "exports");
        String fileName = GpeState.STUDENTS + "_";
        String type = "";

        if(nameFile.isEmpty())
            relativePath = "Resources/exports/" + fileName + dGeneral.CurrentDate + ".csv";
        else
            relativePath= "Resources/exports/" + fileName  + nameFile;




        try {
            FileWriter studentWriter = new FileWriter(relativePath);

            if (dataS.isEmpty())
                return false;

            for (Long key : dataS.keySet()) {
                ArrayList<Object> Student = dataS.get(key);
                studentWriter.write(key.toString());
                for (int i = 0; i < 5; i++)
                    studentWriter.write("," + Student.get(i));
                studentWriter.write("\n");
            }

            studentWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {

        return Utils.exportDelete(GpeState.STUDENTS.toString());
    }

    /**
     * Gets hash student.
     *
     * @return the hash student
     */
    HashSet<Long> getHashStudent() {
        HashSet<Long> students = new HashSet<Long>();
        for (long number : dataS.keySet())
            students.add(number);
        return students;
    }

    /**
     * Gets student.
     *
     * @param id the id
     * @return the student
     */
    public String getStudent(long id) {
        StringBuilder sb = new StringBuilder();
        if (!containsId(id))
            return null;
        sb.append("\n  \uD83D\uDD7A ");
        ArrayList<Object> student = dataS.get(id);
        sb.append(student.get(0) + ": ");
        sb.append(id + " ");
        for (int i = 1; i < 5; i++)
            sb.append(student.get(i) + " \uD83D\uDD3F ");
        return sb.toString();
    }

    /**
     * Get students i ds hash set.
     *
     * @return the hash set
     */
    protected HashSet<Long> getStudentsIDs(){
        if(dataS.isEmpty())
            return null;
        HashSet<Long> studentsIDs = new HashSet<>();
        for(long studentID : dataS.keySet())
            studentsIDs.add(studentID);
        return studentsIDs;
    }

    /**
     * Get student list array list.
     *
     * @param id the id
     * @return the array list
     */
    public ArrayList<Object> getStudentList(long id){
        ArrayList<Object> info = new ArrayList<>();
        info.addAll(dataS.get(id));
        if(dataS.containsKey(id))
            return info;
        else
            return null;
    }

    /**
     * Get student list wprop array list.
     *
     * @param id the id
     * @return the array list
     */
    public ArrayList<Object> getStudentListWprop(long id){
        ArrayList<Object> info = new ArrayList<>();
        info.addAll(dataS.get(id));
        if(dGeneral.D3P.getProp(id) == null)
            info.add(0);
        else
             info.add(dGeneral.D3P.getProp(id));
        if(dataS.containsKey(id))
            return info;
        else
            return null;
    }

    /**
     * Contains id boolean.
     *
     * @param id the id
     * @return the boolean
     */
    public boolean containsId(long id) {
        return dataS.containsKey(id);
    }

    /**
     * Contains mail string.
     *
     * @param id    the id
     * @param email the email
     * @return the string
     */
    public String containsStuMail(long id, String email) {

        for (long key : dataS.keySet()) {
            ArrayList<Object> Student = dataS.get(key);
            if (Student.contains(email) && !(key == id))
                return Errors.EMAILOCCUPIED_ERROR.toString();
        }
        return email;
    }

    /**
     * Students have this mail boolean.
     *
     * @param mail the mail
     * @return the boolean
     */
    public boolean studentsHaveThisMail(String mail){
        for(long idNum : dataS.keySet()) {
            ArrayList<Object> student = dataS.get(idNum);
            if(student.contains(mail))
                return true;
        }
        return false;
    }

    /**
     * Get name string.
     *
     * @param idStd the id std
     * @return the string
     */
    protected String getName(Long idStd){
        if(idStd != 0) {
            ArrayList<Object> info = dataS.get(idStd);
            return info.get(0).toString();
        }
        return "";
    }

    /**
     * Get grade double.
     *
     * @param idStd the id std
     * @return the double
     */
    public Double getGrade(Long idStd){
        if(dataS.containsKey(idStd)) {
            ArrayList<Object> info = dataS.get(idStd);
            return Double.parseDouble(info.get(4).toString());
        }
        return 0.0;
    }

    /**
     * Amount of data.
     *
     * @return the int total quantity of students
     */
    protected int amountOF() {
        if (dataS.isEmpty())
            return 0;
        return dataS.size();
    }


    /**
     * Remain students hash set.
     *
     * @return the hash set
     */
    public HashSet<Long> remainStudents(){
        HashSet<Long> remainStudents = dGeneral.D2C.remainStudentsWithCandidatures();            //get student with atributtion
        HashSet<Long> allStudents = getStudentsIDs();    //get all students
        for(Long idStudent : allStudents)                                           //roam all students
            if(!remainStudents.contains(idStudent))                                 //if not contain
                remainStudents.add(idStudent);                                      //add

        return remainStudents;
    }

    /**
     * To string string.
     *
     * @param column the column
     * @param filter the toStringfilter
     * @return the string
     */
    public String toString(int column, String filter) {

        String[] printTitles= {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE", "INTERNSHIP"};
        int[] sizeTitles1= {6, 6, 6, 6, 6, 6, 6};
        String[] ord= {" ", " ", " ", " ", " ", " ", " "};


        HashSet<Long> stdChoosen = new HashSet<Long>();
        stdChoosen.addAll(dataS.keySet());

        return toString_compile(column, filter,"", stdChoosen, printTitles,sizeTitles1, ord);
    }

    /**
     * To string compile string.
     *
     * @param column      the column
     * @param filter      the toStringfilter
     * @param title       the title
     * @param stdChoosen  the std choosen
     * @param printTitles the print titles
     * @param sizeTitles  the size titles
     * @param ord         the ord
     * @return the string
     */
    public String toString_compile(int column, String filter, String title, HashSet<Long> stdChoosen, String[] printTitles, int[] sizeTitles, String[] ord) {
        int  countResults = 0, countFilters = 0,titlelinelength, lineLength = 0, k, numbchar=2, sizet, j;
        boolean res;
        String ordervar = "↕ ";
        StringBuilder sb = new StringBuilder();
        ArrayList<Object> GetKeyArray;
        if(!title.equals(""))
            sb.append("\n" + title + "\n");
        try {
            ord[column - 1] = ordervar; //icone of toStringfilter
        }catch (ArrayIndexOutOfBoundsException e){
            ord[0] = ordervar; //icone of toStringfilter
            column=1;
        }

        if (dataS == null || dataS.isEmpty())
            sb.append("\nThe list is empty!\n");
        else {

            for (Long key : stdChoosen) {
                GetKeyArray = dataS.get(key);

                sizet = key.toString().length();
                if (sizet > sizeTitles[0])
                    sizeTitles[0] = sizet;

                if (printTitles[0].length() > sizeTitles[0])
                    sizeTitles[0] = printTitles[0].length();

                k = 0;
                j = 0;

                for(String str : printTitles) {

                    if (k<6 && j>0) {

                        sizet = GetKeyArray.get(k).toString().length();

                        if (sizet > sizeTitles[j]) {
                            sizeTitles[j] = sizet;
                        }
                        if (str.length() > sizeTitles[j])
                            sizeTitles[j] = str.length();

                        k++;
                    }
                    j++;
                }
            }

            k = 0;
            for(String str : printTitles) {

                sb.append(" ".repeat((sizeTitles[k])/2)).append(ord[k]).append(str).append(" ".repeat((sizeTitles[k])/2)); //titles print
                k++;

            }

            titlelinelength = sb.length()-title.length();

            String tableLength = "━".repeat(titlelinelength); //line after titles
            sb.append("\n").append(tableLength).append("\n");

            HashMap<Long, String> mp = new HashMap<Long, String>(); //order hasmap

            if (column == 1) {
                for (Long key : stdChoosen) {
                    mp.put(key, key.toString());

                }

            } else {
                for (Long key : stdChoosen) {
                    GetKeyArray= dataS.get(key);
                    mp.put(key, GetKeyArray.get(column - 2).toString());
                }
            }

            Map<Long, String> sortedMap = HashMapComp.longSortByComparator(mp);
            Set<Map.Entry<Long, String>> set = sortedMap.entrySet();
            // Get an iterator
            Iterator<Map.Entry<Long, String>> p = set.iterator();


            // Display elements
            while (p.hasNext()) {
                Map.Entry<Long, String> me = p.next();

                GetKeyArray = dataS.get(me.getKey());

                res = GetKeyArray.stream().anyMatch((a) -> a.toString().contains(filter));
                lineLength = sb.length() - lineLength - titlelinelength;

                if (res || me.getKey().toString().contains(filter)) {
                    sb.append(" ").append(me.getKey()).append(" ".repeat(sizeTitles[0] - me.getKey().toString().length()));

                    j = 1;
                    for (int i = 0; i < printTitles.length-1; i++) {

                        sb.append("\t|\t").append(GetKeyArray.get(i)).append(" ".repeat((sizeTitles[j]) - GetKeyArray.get(i).toString().length()));
                        j++;
                    }
                    sb.append("\t\n");


                    countFilters++;
                }
                countResults++;
            }
            sb.append(tableLength).append("\n ").append(countFilters).append(" of ").append(countResults).append(" ");

        }
        return sb.toString();
    }

}
