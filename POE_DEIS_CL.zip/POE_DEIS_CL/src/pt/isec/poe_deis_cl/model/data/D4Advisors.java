package pt.isec.poe_deis_cl.model.data;


import javafx.collections.ObservableList;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.Validators;
import pt.isec.poe_deis_cl.utils.comparators.HashMapComp;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;

/**
 * Class description:
 * <br>
 * Advisors assignment data
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class D4Advisors implements Serializable{
    /**
     * The Serial version uid.
     */
    static final long serialVersionUID = 1L;

    /**
     * The Atrib advisors.
     */
    DGeneral dGeneral;
    /**
     * The Atrib advisors.
     */
    public Map<String, String> AtribAdvisors; //{ProposalID;ADVISOR}


    /**
     * Instantiates a new D 4 advisors.
     *
     * @param dGeneral the d general
     */
    public D4Advisors(DGeneral dGeneral) {
        this.AtribAdvisors = new HashMap<>();
        this.dGeneral = dGeneral;
    }




    /**
     * Sets phase 4 instance.
     *
     * @param phase4_instance the phase 4 instance
     */

    /**
     * Gets data.
     *
     * @return the data
     */
    public Map<String, String> getData() {
        return AtribAdvisors;
    }

    /**
     * Gets data.
     *
     * @param proposal the proposal
     * @param Tmail    the tmail
     * @return the data
     */


    public String editAdvisors(String proposal,String Tmail){
        if (!dGeneral.D3P.containsIDandProject(proposal))
            return "✘ -> Proposal is not assigned";
        if (proposal.isEmpty() || Tmail.isEmpty())
            return "✘ -> No proposal/mail has been introduced";
        AtribAdvisors.replace(proposal,AtribAdvisors.get(proposal),Tmail);

        return "✔ -> Advisor was attributed with success";
    }

    /**
     * Sets data.
     *
     * @param atribAdvisors the atrib advisors
     */


    public void setData(Map<String, String> atribAdvisors) {
        AtribAdvisors = atribAdvisors;
    }

    /**
     * Delete all boolean.
     *
     * @return the boolean
     */
    public boolean deleteAll() {
        if (AtribAdvisors.isEmpty())
            return false;
        else
            AtribAdvisors.clear();
        return true;
    }

    /**
     * Delete all boolean.
     *
     * @param proposal the proposal
     * @return the boolean
     */
    public boolean delete(String proposal) {
        if (AtribAdvisors.isEmpty() || !AtribAdvisors.containsKey(proposal))
            return false;
        else
            AtribAdvisors.remove(proposal);
        return true;
    }

    /**
     * Export data boolean.
     *
     * @param nameFile the name file
     * @return the boolean
     */
    public boolean exportData(String nameFile) {
        String relativePath;
        Utils.fileExists(GpeState.ADVISORS.toString(), "exports");
        String fileName = GpeState.ADVISORS + "_";
        String type = "";

        if(nameFile.isEmpty())
            relativePath = "Resources/exports/" + fileName + dGeneral.CurrentDate + ".csv";
        else
            relativePath= "Resources/exports/" + fileName  + nameFile;

        try {
            FileWriter teacherWriter = new FileWriter(relativePath);

            if (AtribAdvisors.isEmpty())
                return false;
            if (dGeneral.D3P.returnData().isEmpty())
                return false;

            for (String key : AtribAdvisors.keySet()) { //Checks all advisors assigned to proposals
                for (Long key1 : dGeneral.D3P.returnData().keySet()) { //Checks all Assigned proposals
                    if (key.equals(dGeneral.D3P.returnData().get(key1))) { //Keeps only the if there are assigned proposals
                        for (Long key2 : dGeneral.D1S.returnData().keySet()) { //gets all students
                            if (key1.equals(key2)) { //Keeps only the if there are assigned proposals
                                for (String key3 : dGeneral.D1T.returnData().keySet()) { //gets all teachers data
                                    if (key3.equals(AtribAdvisors.get(key))) { //Keeps only the if there are assigned proposals
                                        teacherWriter.write(dGeneral.D1T.returnData().get(key3));
                                        teacherWriter.write("," + AtribAdvisors.get(key));
                                        teacherWriter.write("," + dGeneral.D2C.getPreference(key1,key));
                                        teacherWriter.write("," + dGeneral.D3P.returnData().get(key1));
                                        teacherWriter.write("," + key2);
                                        for (Object k : dGeneral.D1S.returnData().get(key2))
                                            teacherWriter.write("," + k.toString());
                                    }
                                }
                            }

                        }
                    }
                }
                teacherWriter.write("\n");
            }
            teacherWriter.close();
            return true;
        } catch (IOException e) { //if file writer mandatory exception
            e.printStackTrace();
            return false;
        }

    }

    /**
     * Manual insert int.
     *
     * @param proposal the proposal
     * @param mail     the mail
     * @return the int
     */
//dGeneral.D3P.containsIDandProject(proposal) && dGeneral.D1T.containsMail(email).equals(email)
    public int manualInsert(String proposal, String mail) {
        if (!dGeneral.D3P.containsIDandProject(proposal))
            return -1;
        if(dGeneral.D1P.onlyTeacherProposalsStudents().containsKey(proposal))
            return -2;
        if (proposal.isEmpty() || mail.isEmpty())
            return -3;

        AtribAdvisors.put(proposal, Validators.isStringValidEmail(mail));
        return 0;
    }


    /**
     * Export delete boolean.
     *
     * @return the boolean
     */
    public boolean exportDelete() {
        return Utils.exportDelete(GpeState.ADVISORS.toString());
    }

    /**
     * Add auto designed advisor boolean.
     *
     * @return the boolean
     */
    public boolean addAutoDesignedAdvisor() {
        HashMap<String, String> onlyTeacherProposalsStudents = dGeneral.D1P.onlyTeacherProposalsStudents();        //get list of projects with assigned advisors

        for (String proposalID : onlyTeacherProposalsStudents.keySet()) {                                                 //cycles through the lis
            if (!AtribAdvisors.containsKey(proposalID) &&dGeneral.D3P.containsIDandProject(proposalID)) {     // If it has not been defined and has already been assigned to someone
                AtribAdvisors.put(proposalID, onlyTeacherProposalsStudents.get(proposalID));
            }
        }
        return true;
    }

    /**
     * Add manualadvisor boolean.
     *
     * @param proposal the proposal
     * @param email    the email
     * @return the boolean
     */
    public boolean addManualadvisor(String proposal, String email) {
        if (AtribAdvisors.containsKey(proposal) ||dGeneral.D1P.onlyTeacherProposalsStudents().containsKey(proposal)) { //if already has an advisor or proposal
            return false;
        }
        if (dGeneral.D3P.containsIDandProject(proposal) && dGeneral.D1T.containsMail(email).equals(email)) {//if project has been assigned to student and registered email
            AtribAdvisors.put(proposal, email);                                                                          //adds
            return true;
        }
        return false;
    }


    private HashSet<Long> getStudentWithAdvisorSet() {
/*
        if (AtribAdvisors.isEmpty())
            return null;
*/
        HashSet<Long> studentsID = new HashSet<>();
        for (String proposal : AtribAdvisors.keySet())               //cycle through Date
            studentsID.add(dGeneral.D3P.getStudent(proposal));  //Look for student by the assigned proposal and get its id


        return studentsID;

    }

    /**
     * Consult mode hash map.
     *
     * @param opc the opc
     * @return the hash map
     */
    public HashMap<String,ArrayList<Object>> consultMode(int opc){
        HashMap<String,ArrayList<Object>> infoCand = new HashMap<>();
        ArrayList<Object> info ;
        switch (opc){
            case 1->{ // All data
                for(String key : AtribAdvisors.keySet()){
                    info = new ArrayList<>();
                    info.add(AtribAdvisors.get(key));
                    infoCand.put(key,info);
                }

            }
            case 2-> { // Proposals with advisor
                HashSet<Long> studentsID = getStudentWithAdvisorSet();//students with proposal and associate advisor
                if(studentsID == null)
                    break;
                for (Long key : studentsID) {
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    info = new ArrayList<>();
                    info.add(dGeneral.D1S.getStudentList(key));
                    infoCand.put(key.toString(),info);
                }
            }
            case 3-> { // Assigned without advisor
                HashSet<Long> students = dGeneral.D1S.getStudentsIDs();
                for (Long key : students) {
                    if(!AtribAdvisors.containsValue(key)) {
                        if(!dGeneral.D1S.containsId(key))
                            continue;
                        info = new ArrayList<>();

                        info.add(dGeneral.D1S.getStudentList(key));
                        infoCand.put(key.toString(),info);
                    }
                }
            }
            case 4->{ // Without assignment
                HashSet<Long> students = dGeneral.D3P.studentsWithoutAssign();
                for(Long key : students){
                    if(!dGeneral.D1S.containsId(key))
                        continue;
                    info = new ArrayList<>();
                    info.add(dGeneral.D1S.getStudentList(key));
                    infoCand.put(key.toString(),info);
                }
            }
            case 5->{ // Statistics (if needed)
            }
        }
     /*
        for(String a : infoCand.keySet()){
            System.out.println(a.toString() + infoCand.get(a));
        }
        */
        return infoCand;
    }

    /**
     * Get list string.
     *
     * @param option the option
     * @param email  the email
     * @return the string
     */
    public String getList(int option,String email) {
        switch (option) {
            case 1:
                return getStudentsWithPropAndAdvisor();
            case 2:
                return getStudentsWithPropAndNoAdvisor();
            case 3:
                return advisorsGeneralStats();
            case 4:
                return advisor_teacherSpecifStatus(email);

        }
        return null;
    }

    /**
     * Top advisors hash map.
     *
     * @return the hash map
     */
    public HashMap<String,Integer> topAdvisors(){
        HashMap<String,Integer> ADrank = new HashMap<>();
        for(String advMail : AtribAdvisors.values()){
            if(ADrank.containsKey(advMail))
                ADrank.put(advMail,ADrank.get(advMail)+1);
            else
                ADrank.put(advMail,1);
        }
        return  ADrank;
    }

    private String getStudentsWithPropAndAdvisor() {
        if (AtribAdvisors.isEmpty())
            return "Empty List!";


        String[] printTitles = {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " "};


        HashSet<Long> studentsID = getStudentWithAdvisorSet();
        if (studentsID == null)
            return "Empty List!";

        StringBuilder sb = new StringBuilder();
        sb.append("Students with proposal and advisor assigned :\n");

        for (Long stdID : studentsID)
            sb.append(dGeneral.D1S.getStudent(stdID)).append("\n");

        return dGeneral.D1S.toString_compile(1, "", "Advisors list \n", studentsID, printTitles, sizeTitles1, ord);
    }

    private String getStudentsWithPropAndNoAdvisor() {
        if (AtribAdvisors.isEmpty())
            return "Empty List!";

        String[] printTitles = {"ID", "Name", "Mail", "Course", "BRANCH", "GRADE"};
        int[] sizeTitles1 = {6, 6, 6, 6, 6, 6};
        String[] ord = {" ", " ", " ", " ", " ", " "};

        HashSet<Long> studentsID = getStudentWithAdvisorSet();//students with proposal and associate advisor
        HashSet<Long> studentWithPropAssigned = dGeneral.D3P.studentsWithPropAssigned(); //students with associated proposal
        HashSet<Long> stdChoosen = new HashSet<Long>();


        if (studentWithPropAssigned == null)
            return "Empty List!";

        StringBuilder sb = new StringBuilder();
        sb.append("Students with only proposal assigned :\n");
        for (long studentProp : studentWithPropAssigned)
            if (!studentsID.contains(studentProp))
                stdChoosen.add(studentProp);


        return dGeneral.D1S.toString_compile(1, "", "Advisors list \n", stdChoosen, printTitles, sizeTitles1, ord);
    }

    /**
     * Get list string of the status of the advisors.
     *
     * @return the string
     */
    public String advisorsGeneralStats() { //number of orientations per professor, on average, minimum, maximum //USED AT PHASE 5
        StringBuilder sb = new StringBuilder();

        if (AtribAdvisors.isEmpty()) {   //see if there are advisors
            sb.append(" List of advisors is empty\n");
            return sb.toString();
        }



        sb.append("\uD83D\uDCCA Stats per advisor:\n");
        double quantTeachers = dGeneral.D1T.amountOF(); //number of teachers
        double quantAdvisorment = AtribAdvisors.size();         //number of guidelines
        double average = quantAdvisorment / quantTeachers;        //average
        int quant, min = 10, max = 0;
        for (String advisor : AtribAdvisors.values()) {      //loop through hashmap values
            quant = Collections.frequency(new ArrayList<String>(AtribAdvisors.values()), advisor);  //see the number of times that value appears
            if (quant < min)     //if smaller
                min = quant;
            else if (quant > max)    //if it's bigger
                max = quant;
        }
        sb.append("Average of orientations: ").append(average + "\n");
        sb.append("Maximum of orientations: ").append(max + "\n"); //SEE IF IT'S BY TEACHER OR ADVISOR!
        sb.append("Minimum of orientations: ").append(min + "\n");   //SEE IF IT'S BY TEACHER OR ADVISOR!
        sb.append("\n\uD83D\uDCCA Global Stats - Total Number of:\n");
        sb.append("Students:     ").append(dGeneral.D1S.amountOF() + "        ");
        sb.append("Teachers:   ").append(dGeneral.D1T.amountOF() + "        \n");
        sb.append("Orientations:  ").append((long) quantAdvisorment + "        ");
        sb.append("Proposals:  ").append(dGeneral.D1P.amountOF() + "\n");
        sb.append("Candidatures:  ").append(dGeneral.D2C.amountOF());
        return sb.toString();
    }

    /**
     * Get the string the number of orientations by a specific teacher.
     *
     * @param teacherMail the teacher mail
     * @return the string
     */
    public String advisor_teacherSpecifStatus(String teacherMail) {
        //USED AT PHASE 5


        if (AtribAdvisors.isEmpty())     //vê se existem orientadores
            return "List of advisors is empty";

        StringBuilder sb = new StringBuilder();
        if(teacherMail.equals("all")){
            for(String mail : dGeneral.D1T.dataT.keySet()) {
                int quant = Collections.frequency(new ArrayList<String>(AtribAdvisors.values()), mail);  //Count the number of times the mail value appears
                String name = dGeneral.D1T.getName(mail);  //search for the advisor's name by email
                if(quant != 0)
                    sb.append("\n").append(name).append(" ").append(quant);
            }
        }else{
                int quant = Collections.frequency(new ArrayList<String>(AtribAdvisors.values()), teacherMail);  //Count the number of times the mail value appears
                String name = dGeneral.D1T.getName(teacherMail);  //search for the advisor's name by email
                sb.append("Orientations by:\n").append(name).append(" ").append(quant);
                //System.out.println(sb);
        }
        return sb.toString();
    }
/*
    public Boolean getNotDataPossible(){
        return AtribAdvisors.isEmpty();
    }
*/

    /**
     * To string string.
     *
     * @param column the column
     * @param filter the toStringfilter
     * @return the string
     */
    public String toString(int column, String filter) {

        String[] printTitles = {"Proposal", "Name"};
        int[] sizeTitles1 = {8, 8};
        String[] ord = {" ", " "};

        if (AtribAdvisors.isEmpty())
            return Errors.START_ERROR.getError() + "Advisors list is empty!\n";
        HashSet<String> Choosen = new HashSet<String>();

        for (String idProp : AtribAdvisors.keySet()) {
            Choosen.add(idProp);
        }

        return toString_compile(column, filter, "Advisors list \n", Choosen, printTitles, sizeTitles1, ord);
    }

    /**
     * To string compile string.
     *
     * @param column      the column
     * @param filter      the toStringfilter
     * @param title       the title
     * @param Choosen     the choosen
     * @param printTitles the print titles
     * @param sizeTitles  the size titles
     * @param ord         the ord
     * @return the string
     */
    public String toString_compile(int column, String filter, String title, HashSet<String> Choosen, String[] printTitles, int[] sizeTitles, String[] ord) {
        int countResults = 0, countFilters = 0, titlelinelength, lineLength = 0, k, sizet;
        boolean res;
        String ordervar = "↕ ";
        StringBuilder sb = new StringBuilder();

        if (!title.equals(""))
            sb.append("\n" + title + "\n");

        ord[column - 1] = ordervar; //icone of toStringfilter

        if (AtribAdvisors == null || AtribAdvisors.isEmpty())
            return Errors.START_ERROR.getError() + "\nlist is empty!\n";
        else {

            for (String key : Choosen) {

                sizet = key.length();
                if (sizet > sizeTitles[0])
                    sizeTitles[0] = sizet;
                if (printTitles[0].length() > sizeTitles[0])
                    sizeTitles[0] = printTitles[0].length();


                sizet = AtribAdvisors.get(key).length();
                if (sizet > sizeTitles[1])
                    sizeTitles[1] = sizet;




                if (printTitles[1].length() > sizeTitles[1])
                    sizeTitles[1] = printTitles[1].length();
            }

            k = 0;
            for (String str : printTitles) {

                sb.append(" ".repeat((sizeTitles[k]) / 2)).append(ord[k]).append(str).append(" ".repeat((sizeTitles[k]) / 2)); //titles print
                k++;
            }

            titlelinelength = sb.length() + 4;
            String tableLength = "━".repeat(titlelinelength); //line after titles

            sb.append("\n").append(tableLength).append("\n");

            HashMap<String, String> mp = new HashMap<String, String>(); //order hasmap

            if (column == 2) {
                for (String key : Choosen) {
                    mp.put(key, key);
                }
            } else {
                for (String key : Choosen) {
                    mp.put(key, AtribAdvisors.get(key));
                }
            }

            Map<String, String> sortedMap = HashMapComp.stringSortByComparator(mp);
            Set<Map.Entry<String, String>> set = sortedMap.entrySet();
            // Get an iterator
            Iterator<Map.Entry<String, String>> p = set.iterator();


            // Display elements
            while (p.hasNext()) {
                Map.Entry<String, String> me = p.next();

                res = AtribAdvisors.get(me.getKey()).contains(filter);

                if (res || me.getKey().contains(filter)) {
                    lineLength = sb.length() - lineLength - titlelinelength;

                    sb.append(" ").append(" ".repeat((sizeTitles[0] - (me.getKey()).length()) / 2));
                    sb.append(" ").append(me.getKey()).append("\t\t|\t").append(dGeneral.D1T.getName(AtribAdvisors.get(me.getKey())));
                    sb.append(" ".repeat(((sizeTitles[1]) - AtribAdvisors.get(me.getKey()).length()) / 2)).append("\n");


                    countFilters++;

                }
                countResults++;
            }
            sb.append(tableLength).append("\n ").append(countFilters).append(" of ").append(countResults).append(" ");
        }


        return sb.toString();
    }


}
