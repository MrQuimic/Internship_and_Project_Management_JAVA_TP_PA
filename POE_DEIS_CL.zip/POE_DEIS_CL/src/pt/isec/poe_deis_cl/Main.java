package pt.isec.poe_deis_cl;


import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.ui.text.GpeUI;
import static javafx.application.Application.launch;

/**
 * Class description:
 * <br>
 * Main
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class Main {
    /**
     * Instantiates a new Main.
     */
    public Main() {
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {


        GpeContext fsm = new GpeContext();
        GpeUI ui = new GpeUI(fsm);
        //ui.start();
        ui.uiGuiOpt();


    }
}
