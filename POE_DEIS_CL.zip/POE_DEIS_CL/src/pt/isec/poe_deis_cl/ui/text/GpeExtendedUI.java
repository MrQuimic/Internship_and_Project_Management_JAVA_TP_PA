package pt.isec.poe_deis_cl.ui.text;


import javafx.application.Application;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.ui.gui.MainGui;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.utils.Input;
import pt.isec.poe_deis_cl.utils.Utils;
import pt.isec.poe_deis_cl.utils.Validators;

import java.io.File;
import java.util.*;


/**
 * The type Gpe extended ui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class GpeExtendedUI {

    /**
     * Edit students boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean editStudents(GpeContext fsm) {
        String id;
        long idNum = 0;
        double gradeDouble = 0;
        Boolean internshipBool = false;
        Scanner sc = new Scanner(System.in);
        System.out.print("\nPlease Input ID to edit (\"cancel\" to go back): ");
        id = sc.next();
        if (cancelOperation(id))
            return false;
        try {
            idNum = Long.parseLong(id);
        } catch (java.util.NoSuchElementException | NumberFormatException e) {
            Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
            return false;
        }


        if (fsm.containsId(idNum)) {

            String mail;
            String name;
            String course;
            String branch;
            String grade;
            String internship = "";
            String boolchoice;

            sc.useDelimiter("[\r\n]");


            do {
                System.out.print("\nName: ");
                name = sc.next();

                if (cancelOperation(name))
                    return false;

                else if (Validators.isStringInt(name).equals(Errors.INT_ERROR.getError()))
                    name = name.substring(0, 1).toUpperCase() + name.substring(1) + name.substring(0, 2).toUpperCase() + name.substring(2);

                if (Validators.checkValidName(name).equals(Errors.NAMELIMIT_ERROR.getError()))
                    System.err.print(Errors.NAMELIMIT_ERROR.getError());

            } while (Validators.checkValidName(name).equals(Errors.NAMELIMIT_ERROR.getError()));

            do {

                System.out.print("\nEmail: ");
                mail = sc.next();
                System.out.println(mail);
                if (cancelOperation(mail))
                    return false;
                else if (Validators.isStringValidEmail(mail).equals(Errors.EMAIL_ERROR.toString()))
                    System.err.print(Errors.EMAIL_ERROR.getError());
                if (fsm.containsStuMail(idNum, mail).equals(Errors.EMAILOCCUPIED_ERROR.toString()))
                    System.err.print(Errors.EMAILOCCUPIED_ERROR.getError());
            } while (Validators.isStringValidEmail(mail).equals(Errors.EMAIL_ERROR.toString()) || fsm.containsStuMail(idNum, mail).equals(Errors.EMAILOCCUPIED_ERROR.toString()));


            do {
                System.out.print("\nCourse: ");
                course = sc.next();
                if (cancelOperation(course))
                    return false;
                else if (Validators.checkValidCourse(course).equals(Errors.COURSE_ERROR.toString()))
                    System.err.print((Errors.COURSE_ERROR.getError()));

            } while (Validators.checkValidCourse(course).equals(Errors.COURSE_ERROR.toString()));


            do {
                System.out.print("\nBranch: ");
                branch = sc.next();
                if (cancelOperation(branch))
                    return false;
                else if (Validators.checkValidBranch(branch).equals(Errors.BRANCH_ERROR.toString()))
                    System.err.print(Errors.BRANCH_ERROR.getError());
            } while (Validators.checkValidBranch(branch).equals(Errors.BRANCH_ERROR.toString()));


            do {
                System.out.print("\nGrade: ");
                grade = sc.next();
                if (cancelOperation(grade))
                    return false;
                else if (Validators.checkValidGrade(grade).equals(Errors.DOUBLE_ERROR.toString()))
                    System.err.print(Errors.DOUBLE_ERROR.getError());
                else if (Validators.checkValidGrade(grade).equals(Errors.OUTOFBOUNDS_ERROR.toString()))
                    System.err.print(Errors.OUTOFBOUNDS_ERROR.getError());
                else
                    gradeDouble = Double.parseDouble(grade);


            } while (Validators.checkValidGrade(grade).matches(Errors.DOUBLE_ERROR.toString() + "|" + Errors.OUTOFBOUNDS_ERROR.toString()));

            do {
                System.out.print("\nInternship (1-True 2-False): ");
                boolchoice = sc.next();
                if (cancelOperation(boolchoice))
                    return false;
                else if (Objects.equals(boolchoice, "1"))
                    internship = "true";
                else if (Objects.equals(boolchoice, "2"))
                    internship = "false";

                if (!Objects.equals(boolchoice, "1") && !Objects.equals(boolchoice, "2"))
                    System.err.print(Errors.CHOICE_ERROR.getError());
                else
                    internshipBool = Boolean.parseBoolean(internship);


            } while (!Objects.equals(boolchoice, "1") && !Objects.equals(boolchoice, "2"));

            if (fsm.editStudents(idNum, name, mail, course, branch, gradeDouble, internshipBool)) {
                System.out.println("\n✔ Edited " + idNum + "\n");
                return true;
            }
        }

        Utils.errorPrint("\n" + Errors.CHOICE_ERROR.getError() + idNum + "\n");
        return false;
    }

    /**
     * Insert assignment boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean insertAssignment(GpeContext fsm){
        String proposal = " ";
        Long id ;
        Scanner sc = new Scanner(System.in);
        if (cancelOperation(proposal)) {
            System.out.println("Edit operation canceled");
            return false;
        }

        do{
            System.out.print("\nPlease Input ID of a proposal(\"cancel\" to go back): ");
            proposal = sc.nextLine();
            if (Validators.isStringValidProj(proposal).equals(Errors.PROJ_NUM_ERROR.toString()))
                 Utils.errorPrint("\n" + Errors.PROJ_NUM_ERROR.toString() + "\n\n");
        }while((Validators.isStringValidProj(proposal).equals(Errors.PROJ_NUM_ERROR.toString())));

        try {
            System.out.print("\nPlease Input ID of a student(\"cancel\" to go back): ");
            id = sc.nextLong();
        } catch (NumberFormatException e) {
            Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
            return false;
        } catch (InputMismatchException e) {
            Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
            return false;
        }
        fsm.assignManualProposal(id,proposal);

        return false;
    }

    /**
     * Edit teachers boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean editTeachers(GpeContext fsm) {
        String mail;
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\r\n]");


        System.out.print("\nPlease Input the mail to edit (\"cancel\" to go back): ");
        mail = sc.next();

        if (cancelOperation(mail))
            return false;


        if (Validators.isStringValidEmail(mail).equals(Errors.EMAIL_ERROR.toString())) {
            Utils.errorPrint("\n" + mail + Errors.EMAIL_ERROR.getError());
            return false;
        }


        if (!fsm.containsMail(mail).equals(Errors.EMAIL_ERROR.toString())) {
            String name;

            do {
                System.out.print("\nName: ");
                name = sc.next();

                if (cancelOperation(name))
                    return false;

                if (Validators.isStringInt(name).equals(Errors.INT_ERROR.toString()))
                    name = name.substring(0, 1).toUpperCase() + name.substring(1) + name.substring(0, 2).toUpperCase() + name.substring(2);

                if (Validators.checkValidName(name).equals(Errors.NAMELIMIT_ERROR.toString()))
                    System.err.print(Errors.NAMELIMIT_ERROR.getError());
            } while (Validators.checkValidName(name).equals(Errors.NAMELIMIT_ERROR.toString()));


            if (fsm.editTeachers(mail, name)) {
                System.out.println("\n✔ Edited " + mail + "\n");
                return true;
            }
            return true;
        }


        return false;
    }

    /**
     * Edit candidature boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean editCandidature(GpeContext fsm) {
        String id;
        long idNum = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("\nPlease Input ID to edit (\"cancel\" to finish): ");
        id = sc.nextLine();
        if (cancelOperation(id))
            return false;
        try {
            idNum = Long.parseLong(id);
        } catch (java.util.NoSuchElementException | NumberFormatException e) {
            Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
            return false;
        }


        if (!fsm.containsId(idNum)) {

            HashSet<String> newProjs = new HashSet<>();

            sc.useDelimiter("[\r\n]");

            System.out.println("\nProject ID: ");
            while (!(id = sc.next()).equalsIgnoreCase("cancel")) {

                if (!Validators.isStringValidProj(id).equals(Errors.PROJ_NUM_ERROR.toString())) {
                    System.out.println("ID Accepted : " + id);
                    newProjs.add(id);
                } else
                    System.out.println(Errors.ID_FORMAT.getError() + id);
                System.out.println("\nProject ID: ");
            }

            if (fsm.editCandidatures(idNum, newProjs)) {
                System.out.println("\n✔ Edited " + idNum + "\n");
                return true;
            }

        } else {
            Utils.errorPrint(Errors.ID_NOTFOUND_ERROR.getError());
        }
        return false;
    }

    /**
     * Edit proposals boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean editProposals(GpeContext fsm) {

        String id = " ";
        String type = "";
        Scanner sc = new Scanner(System.in);
        ArrayList<Object> newProposals = new ArrayList<>();
        System.out.print("\nPlease Input ID to edit (\"cancel\" to finish): ");
        //sc.useDelimiter("");
        sc.useDelimiter("[\r\n]");
        id = sc.next();
        if (cancelOperation(id)) {
            System.out.println("Edit operation canceled");
            return false;
        }

        if (Validators.isStringValidProj(id).equals(Errors.PROJ_NUM_ERROR.toString())) {
            Utils.errorPrint("\n" + Errors.PROJ_NUM_ERROR.toString() + "\n\n");
            fsm.refreshState();//  activeStateUI();
        } else if (fsm.containsId(Long.parseLong(id))) {
            Utils.errorPrint("\n Projet not found!\n\n");

        }
        if (id.isEmpty()) {
            fsm.refreshState();//activeStateUI();
        }

        do {
            System.out.print("\nPlease Input the type of proposal (\"cancel\" to go back): ");
            type = sc.next();
            if (cancelOperation(type)) {
                System.out.println("Edit operation canceled");
                return false;
            }
        } while (!type.matches("T1|T2|T3"));

        newProposals = switch (type){
            case "T1" -> editProposalsT1(id, fsm);
            case "T2" -> editProposalsT2(id, fsm);
            case "T3" -> editProposalsT3(id, fsm);
            default -> null;
        };
        if (newProposals != null)
            if (fsm.editProposals(id, newProposals)) {
                System.out.println("\n✔ Edited " + id + "\n");

            }
        Utils.errorPrint(Errors.ID_NOTFOUND_ERROR.getError());
        fsm.refreshState();//activeStateUI();
        return false;
    }


    private ArrayList<Object> editProposalsT1(String id, GpeContext fsm) {
        long idNum;
        String values;
        Scanner sc = new Scanner(System.in);
        ArrayList<Object> newProposals = new ArrayList<>();
        sc.useDelimiter("[\r\n]");
        newProposals.add("T1");
        System.out.print("Branch: ");
        values = sc.next();
        newProposals.add(Validators.checkValidBranch(values));
        System.out.print("Title of the Internship: ");
        values = sc.next();
        newProposals.add(values);
        System.out.print("Host entity: ");
        values = sc.next();
        newProposals.add(values);
        newProposals.add(" "); //adiconar espaço para docente
        System.out.print("Assigned number:");
        values = sc.next();
        if (!values.equals("null")) {
            try {
                idNum = Long.parseLong(values);
            } catch (java.util.NoSuchElementException | NumberFormatException e) {
                Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
                return null;
            }
            newProposals.add(idNum);

        } else
            newProposals.add(0);
        return newProposals;
    }


    private ArrayList<Object> editProposalsT2(String id, GpeContext fsm) {
        long idNum;
        String values;
        String mail = "";
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\r\n]");
        ArrayList<Object> newProposals = new ArrayList<>();
        newProposals.add("T2");
        System.out.print("Branch: ");
        values = sc.next();
        newProposals.add(Validators.checkValidBranch(values));
        System.out.print("Title of the Project: ");
        mail = sc.next();
        newProposals.add(values);
        System.out.print("Teacher mail: ");
        values = sc.next();
        newProposals.add(Validators.isStringValidEmail(values));
        System.out.print("Assigned number: ");
        values = sc.next();
        if (!values.equals("null")) {
            try {
                idNum = Long.parseLong(values);
            } catch (java.util.NoSuchElementException | NumberFormatException e) {
                Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
                return null;
            }
            if (fsm.containsId(idNum) && !fsm.containsMail(mail).equals(Errors.EMAILNOTFOUND_ERROR.toString()))
                newProposals.add(idNum);
            else {
                Utils.errorPrint(Errors.ID_NOTFOUND_ERROR.toString() + idNum);
                return null;
            }
        } else
            newProposals.add(0);
        return newProposals;

    }

    private ArrayList<Object> editProposalsT3(String id, GpeContext fsm) {
        long idNum;
        String values;
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\r\n]");
        ArrayList<Object> newProposals = new ArrayList<>();
        newProposals.add("T3");
        newProposals.add(" "); //adiciona branch
        System.out.print("Title : ");
        values = sc.nextLine();
        newProposals.add(values);
        newProposals.add(" "); //adiciona mail
        System.out.print("Assigned number: ");
        values = sc.next();
        if (!values.equals("null")) {
            try {
                idNum = Long.parseLong(values);
            } catch (java.util.NoSuchElementException | NumberFormatException e) {
                Utils.errorPrint(Errors.LONG_ERROR.getError() + e + " \n");
                return null;
            }
            if (fsm.containsId(idNum))
                newProposals.add(idNum);
            else {
                Utils.errorPrint(Errors.ID_NOTFOUND_ERROR.toString() + idNum);
                return null;
            }
        }

        return newProposals;
    }


    /**
     * Manual insert p 4 boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    Boolean manualInsertP4(GpeContext fsm) {

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\r\n]");
        String proposal, email;
        System.out.print("\n - Fill the data for manual insert - \n ");

        System.out.print("Proposal: ");
        proposal = sc.next();
        if (cancelOperation(proposal))
            return false;

        do {
            System.out.print("Email: ");
            email = sc.next();
            if (cancelOperation(email))
                return false;

        }while (Validators.isStringValidEmail(email).equals(Errors.EMAIL_ERROR.toString()));


        fsm.addManualadvisor(proposal, email);


        return true;
    }

    /**
     * Manual insert p 4 boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    Boolean editP4Advisors(GpeContext fsm) {

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\r\n]");
        String proposal, email;
        System.out.print("\n - Fill the data for edit advisor on proposal -  ( 0 - cancel) \n ");

        System.out.print("Proposal: ");
        proposal = sc.next();
        if (cancelOperation(proposal))
         return false;

        do {
            System.out.print("Email: ");
            email = sc.next();
            if (cancelOperation(email))
                return false;

        }while (Validators.isStringValidEmail(email).equals(Errors.EMAIL_ERROR.toString()));



            System.out.print(fsm.editAdvisors(proposal, email));

        return true;
    }

    private void manualInsert(){
        //Atribuição manual de propostas disponíveis aos alunos sem atribuição ainda definida.

    }


    /**
     * Order boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean order(GpeContext fsm) {
        int id=0;
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter(""); //for empty allowed
        System.out.println("\nPlease Input the Column number to order: ");

        try {
            id = sc.nextInt();
        } catch (InputMismatchException e) {
            id = 1;
        }
            System.out.println(fsm.consult(id, ""));



        return false;
    }

    /**
     * Filter boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean filter(GpeContext fsm) {
        String filter ="";
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter(""); //for empty allowed
        System.out.println("\nPlease Input the string to filter: ");

        filter = sc.nextLine();




        System.out.println(fsm.consult(1, filter));

        return true;
    }


    /**
     * Delete boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean delete(GpeContext fsm) {
        String id;
        Scanner sc = new Scanner(System.in);
        System.out.println("\nPlease Input ID to delete: \n");
        id = sc.nextLine();


        if (confirmOperation("Are you sure you want to remove " + id + " data? ")) {
            if (fsm.delete(id)) {
                System.out.println("\n✔ Deleted " + id + "\n");

                return true;

            } else {
                Utils.errorPrint("\n" + Errors.ID_NOTFOUND_ERROR.getError() + id + "\n");

                return false;
            }
        }

        return false;
    }


    /**
     * Delete all boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean deleteAll(GpeContext fsm) {
        if (confirmOperation("Are you sure you want to remove all data?")) {
            if (fsm.deleteAll()) {

                return true;
            }
        }

        return false;
    }

    /**
     * Export remove boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean exportRemove(GpeContext fsm) {
        if (confirmOperation("Are you sure you want to remove all exports from this categorie?")) {
            if (fsm.exportDelete()) {

                return true;
            }
            return false;
        }

        return false;
    }


    /**
     * Insert p 1 p 2 boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean insertP1P2(GpeContext fsm) {
        if (confirmOperation("Are you sure you want to remove all exports from this categorie?")) {
            if (fsm.exportDelete()) {

                return true;
            }
            return false;
        }

        return false;
    }


    /**
     * Credits.
     */
    void credits() {
        System.out.println("\n ✎ Authors:\n" +
                " Carlos Santos  {Email: a2003035578@isec.pt}\n" +
                " Leonardo Sousa {Email: a2019129243@isec.pt}\n\n" +
                " ⌛ Date 2022/04/05\n\n" +
                " ⚑ This pratical assignement was carried out in an academic context \nfor the subject of Advanced Programming at ISEC!");


    }

    /**
     * Info.
     */
    void info() {
        //Scanner sc = new Scanner(System.in);
        System.out.println("\n ⚑ Application to support the management of projects and \n internships in the department of computer Science and Engineering at ISEC");
        System.out.println("\n\n ↕ Symbol to indicate the column that is being ordered");
        System.out.println("\n ⧉ When closing the phase the data will be auto assigned, but u can also assign it manually");
        System.out.print("\n Filters will, when chosen , exclude automatically the other filters that would make a list empty");
        System.out.println("\n  ⛛ Filter chosen, \uD83D\uDCA2 Filter excluded");
        System.out.println("\n\n  Import path: \n \uD83D\uDCC2 " + System.getProperty("user.dir")+"/Resources/imports");
        System.out.println("\n  Export path: \n \uD83D\uDCC2 " + System.getProperty("user.dir")+"/Resources/exports");

        //TODO Check if need to clean
       // System.out.println("\n\t\t\t\t\t\t MainGui development you can check it out. (❗ This option will quit the text application ❗)");

      //  System.out.println("\n\t\t\t\t\t\t Do you wish to proceed? (1 - confirm , 0 - cancel)");

        /*
                if(sc.nextInt() == 1) {
                    System.out.println("\n\t\t\t\t\t\t The gui is launched.\n\n");
                    //String[] a = new String[0];
                    //MainGui.main( a);
                    try {
                        Application.launch(MainGui.class, "");
                        System.exit(0);
                    }catch(Exception e){

                    }

                }
        */
    }

    /**
     * Confirm operation boolean.
     *
     * @param conf the conf
     * @return the boolean
     */
    static boolean confirmOperation(String conf) {
        String opc = "";
        int opc_num = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("\n" + conf + " (1-Confirm | 2-Cancel)" + "\n");
        opc = sc.next();

        //  if (cancelOperation("opc"))
        //   return false;

        try {
            opc_num = Integer.parseInt(opc);
        } catch (java.util.InputMismatchException | NumberFormatException e) {
            System.out.println("NEED A INTEGER!");
            return false;
        }


        return opc_num == 1;
    }


    /**
     * Cancel operation boolean.
     *
     * @param scan the scan
     * @return the boolean
     */
    public boolean cancelOperation(String scan) {
        if (scan.equalsIgnoreCase("cancel")) {
            System.out.println("✔ Operation canceled");
            return true;
        }
        return false;
    }

    /**
     * Finish operation boolean.
     *
     * @param scan the scan
     * @return the boolean
     */
    public boolean finishOperation(String scan) {
        if (scan.equalsIgnoreCase("ok")) {
            System.out.println("✔ Done");
            return true;
        }
        return false;
    }

    /**
     * Save data boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean saveData(GpeContext fsm) {

        if (confirmOperation(" !This option will remove current save point \n\nAre you sure you want save? ")) {

            System.out.println("\n✔ DATA saved " + "\n");

            if (fsm.save())
                return true;
            else
                System.out.println(Errors.EXCEPTION_GENERAL_ERROR.getError() + "\n DATA not saved" + "\n");

        }

        System.out.println("\n -- DATA not saved --" + "\n");
        return false;

    }


    /**
     * Load data boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    public boolean loadData(GpeContext fsm) {

        if (confirmOperation(" !This option will change current DATA\n\nAre you sure you want LOAD? ")) {

            System.out.println("\n✔ DATA LOADED " + "\n");

            if (fsm.load())
                return true;
            else
                System.out.println(Errors.EXCEPTION_GENERAL_ERROR.getError() + "\n DATA not loaded" + "\n");

        }

        System.out.println("\n -- DATA not loaded --" + "\n");
        return false;

    }

    /**
     * Clear save points.
     *
     * @param fsm the fsm
     */
    void clearSavePoints(GpeContext fsm) { //reset
        if (confirmOperation("Are you sure you want to erase SavePoint and current data" + " data? ")) {
            if (fsm.ClearData()) {
                if ( fsm.save()) {
                    File dir = new File("Resources/exports/");
                    Utils.deleteFolder(dir);
                    System.out.println("\n ✔ SavePoint was cleared");

                }
            }

        } else {
            System.out.println("\n - Operation Canceled has requested - ");

        }
    }

    /**
     * Quit.
     *
     * @param fsm the fsm
     */
    void quit(GpeContext fsm) {
        if (confirmOperation("Are you sure you want to quit?")) {
            fsm.save();
            System.exit(0);
        }

    }

    /**
     * Admin open phase boolean.
     *
     * @param fsm the fsm
     * @return the boolean
     */
    boolean adminOpenPhase(GpeContext fsm) {
        String filter1, filter2;
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter(""); //for empty allowed
        System.out.println("\nAdmin - Super Manage Phases:");
        filter1 = sc.nextLine();
            System.out.println("\n1- Open all | 2 - close all");
            filter2 = sc.nextLine();
            if(filter2.equals("1")) {

                if (!fsm.admin(1, filter1)) {
                    Utils.errorPrint("Wrong Password!");
                    return false;
                }
                System.out.println("\n✔ Done!");

            }else if(filter2.equals("2")) {
                if(!fsm.checkEmpty()){
                    fsm.admin(2, filter1);
                    System.out.println("\n✔ Done!");
                } else {
                    Utils.errorPrint("\n" + Errors.GENERAL_ERROR.getError() + " Not enough data!\n");
                }
            }


        return true;
    }

    /**
     * Icon data string.
     *
     * @param fsm the fsm
     * @return the string
     */
    String iconData(GpeContext fsm) {
        String withData_Teachers = "", withData_Students = "", withData_Proposals = "",withData = "";

        if(!fsm.getNotDataPossible(GpeState.TEACHERS))
            withData_Teachers = "❱";
        if(!fsm.getNotDataPossible(GpeState.STUDENTS))
            withData_Students = "❱";
        if(!fsm.getNotDataPossible(GpeState.PROPOSALS))
            withData_Proposals = "❱";


        if (fsm.getPhase() == 1)
            withData = withData_Teachers + withData_Students + withData_Proposals;
        else if (fsm.getPhase() == 2 && !fsm.getNotDataPossible(GpeState.CANDIDATURE))
            withData = "❱";
        else if (fsm.getPhase() == 3 && !fsm.getNotDataPossible(GpeState.ASSIGNEDPROPOSALS))
            withData = "❱";
        else if (fsm.getPhase() == 4 && !fsm.getNotDataPossible(GpeState.ADVISORS))
            withData = "❱";
        else if (fsm.getPhase() == 5)
            withData = "";
        return withData;
    }

    /**
     * Edit assig proposals int.
     *
     * @param fsm the fsm
     * @return the int
     */
    int editAssigProposals(GpeContext fsm){

        ArrayList<Object> info =  fsm.attributedProposals();

            if(info.isEmpty())
                System.out.println("\n[Phase 3] - Manual fix overlapsing proposals - \nThis list will keep showing until all proposals are fixed:\n");
            long std1=0, std2=0, std3=0, std4=0, std5=0, std6=0, std7=0, std8=0, std9=0, std10=0;
            do{
                info =  fsm.attributedProposals();
                if(info.isEmpty())
                    return 0;

                String proposal = info.get(0).toString();
                std1= Long.parseLong(info.get(1).toString());
                std2= Long.parseLong(info.get(2).toString());
                System.out.println("Tie on proposal "+ proposal + ":");


                int size = info.size();
                System.out.println("Student 1 - " + fsm.getStudent(std1) + " \uD83D\uDDF4" + fsm.stdCand(std1));
                System.out.println("Student 2 - " + fsm.getStudent(std2) + " \uD83D\uDDF4" + fsm.stdCand(std2));
                if (size >3) {
                    std3 = Long.parseLong(info.get(3).toString());
                    System.out.println("Student 3 - " + fsm.getStudent(std3) + " \uD83D\uDDF4" + fsm.stdCand(std3));
                }
                if (size > 4) {
                    std4 = Long.parseLong(info.get(4).toString());
                    System.out.println("Student 4 - " + fsm.getStudent(std4) + " \uD83D\uDDF4" + fsm.stdCand(std4));
                }
                if (size > 5) {
                    std5 = Long.parseLong(info.get(5).toString());
                    System.out.println("Student 5 - " + fsm.getStudent(std5) + " \uD83D\uDDF4" + fsm.stdCand(std5));
                }

                if (size > 6) {
                    std6 = Long.parseLong(info.get(6).toString());
                    System.out.println("Student 6 - " + fsm.getStudent(std6) + " \uD83D\uDDF4" + fsm.stdCand(std6));
                }

                if (size > 7) {
                    std7 = Long.parseLong(info.get(7).toString());
                    System.out.println("Student 7 - " + fsm.getStudent(std6) + " \uD83D\uDDF4" + fsm.stdCand(std7));
                }
                if (size > 8) {
                    std5 = Long.parseLong(info.get(8).toString());
                    System.out.println("Student 8 - " + fsm.getStudent(std5) + " \uD83D\uDDF4" + fsm.stdCand(std8));
                }

                if (size > 9) {
                    std6 = Long.parseLong(info.get(9).toString());
                    System.out.println("Student 9 - " + fsm.getStudent(std6) + " \uD83D\uDDF4" + fsm.stdCand(std9));
                }

                if (size > 10) {
                    std7 = Long.parseLong(info.get(10).toString());
                    System.out.println("Student 10 - " + fsm.getStudent(std6) + " \uD83D\uDDF4" + fsm.stdCand(std10));
                }

                switch (Input.chooseOptionZeroOff("Escolha o aluno:",
                        String.valueOf(std1),
                        String.valueOf(std2),String.valueOf(std3),
                        String.valueOf(std4),String.valueOf(std5),
                        String.valueOf(std6),String.valueOf(std7),String.valueOf(std8),
                        String.valueOf(std9),String.valueOf(std10) + "\n\n", "Cancel")){
                    case 1->
                            fsm.manualInsert(String.valueOf(std1),proposal);
                    case 2->
                            fsm.manualInsert(String.valueOf(std2),proposal);
                    case 3->
                            fsm.manualInsert(String.valueOf(std3),proposal);
                    case 4->
                            fsm.manualInsert(String.valueOf(std4),proposal);
                    case 5->
                            fsm.manualInsert(String.valueOf(std5),proposal);
                    case 6->
                            fsm.manualInsert(String.valueOf(std6),proposal);
                    case 7->
                            fsm.manualInsert(String.valueOf(std7),proposal);
                    case 8->
                            fsm.manualInsert(String.valueOf(std8),proposal);
                    case 9->
                            fsm.manualInsert(String.valueOf(std9),proposal);
                    case 10->
                            fsm.manualInsert(String.valueOf(std10),proposal);
                    case 11-> {
                        System.out.println("Cancelled");
                        return 0;
                    }
                }
            }while(!info.isEmpty());
            return 0;
        }


}
