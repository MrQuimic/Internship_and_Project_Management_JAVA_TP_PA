package pt.isec.poe_deis_cl.ui.text;

/**
 * Class description:
 * • GpeUI
 * • Class that should provide an interface
 * suitable for the defined states
 * • This class must not implement any logic
 * regarding the application rules
 * • He must...
 * • present useful information for the user to carry out the
 * your options
 * • provide the interaction mechanisms that allow
 * trigger the appropriate state transitions
 *
 * @author Carlos Santos {@literal <a2003035578@isec.pt>}
 * @author Leonardo Sousa {@literal <a2019129243@isec.pt>}
 * @date 2022/04/05
 */


import javafx.application.Application;
import pt.isec.poe_deis_cl.model.fsm.GpeContext;
import pt.isec.poe_deis_cl.ui.gui.MainGui;
import pt.isec.poe_deis_cl.utils.Errors;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.utils.Input;
import pt.isec.poe_deis_cl.utils.Utils;

import java.util.Scanner;

/**
 * The type Gpe ui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class GpeUI extends GpeExtendedUI {
    /**
     * The Fsm.
     */
    GpeContext fsm;
    /**
     * The Finish.
     */
    boolean finish = false;
    /**
     * The Gui launch.
     */
    boolean guiLaunch = false;

    /**
     * Instantiates a new Gpe ui.
     *
     * @param fsm the fsm
     */
    public GpeUI(GpeContext fsm) {
        this.fsm = fsm;
    }


    /**
     * Ui gui opt.
     */


    /**
     * Start.
     */
    public void start() {
        String top = "";
        String saveData = "\uD83D\uDCBE Save Data";
        String gui = "\uD83D\uDCBB GUI";

        if (guiLaunch) {
            gui = "_\uD83D\uDCBB GUI";
        }

        if (fsm.checkEmpty()) { // primeira entrada no programa faz load
            fsm.load();
            saveData = "_\uD83D\uDCBE Save Data";
        } else {

            top = "\n  □ Phase: " + fsm.getPhase() + "\n  □ Closed Phases: " + fsm.getClosePhase();
        }


        while (!this.finish) {
            switch (Input.chooseOptionAlternative("\n ⧉ " + "Main Menu" + top + "  ",
                    "\uD83D\uDD01 Phases",  saveData, "✎ Info", "\uD83D\uDDEC Credits", "\uD83D\uDCA5 Reset",gui, "✖ Quit")) {
                case 1 -> activeStateUI();
                case 2 -> {saveData(fsm);
                    activeStateUI();}
                case 3 -> info();
                case 4 -> credits();
                case 5 -> {
                    clearSavePoints(fsm);
                    activeStateUI();}
                case 6 -> {uiGuiOpt();}
                case 7 -> quit(fsm);
                case 991 -> {
                    if (adminOpenPhase(fsm))
                        activeStateUI();
                }
            }
        }
    }

    /**
     * Ui gui opt.
     */
    public void uiGuiOpt(){
        Scanner sc = new Scanner(System.in);
        int opt;
        guiLaunch = true;  //TODO TEMP5
        Application.launch(MainGui.class, ""); //TODO TEMP


        System.out.println("\n\t\t\t\t\t\t ⧉ POE_DEIS CL - DEIS-ISEC");
        System.out.println("\n\t\t\t\t\t\t Do you wish to proceed? (1 - GUI , 0 - UI)");
        opt = sc.nextInt();

        if(opt == 1) {
            guiLaunch = true;
            System.out.println("\nThe gui is launched! (To continue on text mode relaunch the application and choose option UI)\n\n");
            Application.launch(MainGui.class, "");
        }
        else {
            //Utils.clearConsole();
            start();
        }

    }
    private void activeStateUI() {
        int LineComplete = 28, indexChoose = 0;
        if (fsm.getPhase() == 5) { // primeira entrada no programa faz load
            ConsultP5();
        }

        String titleReptline = "―".repeat((LineComplete - 2) / 2),
                menuInBetweenSpace = " ".repeat(15),
                menuInSmallSpace = " ".repeat(5),
                bkLineConsultActions = "\n" + titleReptline + " Consult " + titleReptline + "",
                bkLinePhasesActions = "\n" + titleReptline + " Manage " + titleReptline + "",
                bkLineMenu = "\n" + titleReptline + "  Menu  " + titleReptline + "\n",
                bkLinePhases = "\n" + titleReptline + " Phases " + titleReptline + "\n", previous = "",
                advance = "", closePhase = "", inactivePhase = "", inactivePhaseNext = "", nofilterorder = "", nofilterorder2 = "", f1Menu = "", bkLineclosePhase = "",
                bkLinePrevious = "", bkLineAdvance = "", f1ActiveS = "", f1ActiveT = "", f1ActiveP = "", f1ActiveBreak = "",
                withData_Teachers = " ", withData_Students = " ", withData_Proposals = " ", withData = " ", exportExists = "", noData = "", noDataChange = "", teachStudentDataOn="";


        if (this.fsm.getState() == GpeState.STUDENTS || this.fsm.getState() == GpeState.TEACHERS
                || this.fsm.getState() == GpeState.PROPOSALS) {
            previous = "⇢ ";
        }
        if (this.fsm.getState() == GpeState.CONSULT || this.fsm.getState() == GpeState.ADVISORS) {
            advance = "⇢ ";
        }

        if (this.fsm.getState() == GpeState.CONSULT || fsm.getPhase() > fsm.getClosePhase() + 1 || fsm.getPhase() < fsm.getClosePhase() + 1) {
            closePhase = "_";
        }

        if (advance.equals("_")) {
            if (closePhase.equals("_")) {
                bkLinePrevious = bkLineMenu;
            } else {
                bkLineAdvance = menuInBetweenSpace;
                bkLineclosePhase = bkLineMenu;
            }
        } else {
            if (closePhase.equals("_")) {
                bkLinePrevious = menuInBetweenSpace + "  ";
                bkLineAdvance = bkLineMenu;
            } else {
                if (previous.equals("_")) {
                    bkLineAdvance = "   " + menuInBetweenSpace;
                } else {
                    bkLineAdvance = "\n";
                }

                bkLinePrevious = menuInBetweenSpace + "  ";
                bkLineclosePhase = bkLineMenu;
            }
        }
        if ((fsm.getClosePhase() + 1 != fsm.getPhase()))
            inactivePhase = "⇢ ";

        if ((fsm.getClosePhase() + 1 < fsm.getPhase()))
            inactivePhaseNext = "⇢ ";

        if (fsm.getPhase() == 3) {
            nofilterorder = "_";
            nofilterorder2 = bkLinePhasesActions + "\n";
        }

        if (fsm.getPhase() > 1)
            f1Menu = "_";

        if (this.fsm.getState() == GpeState.STUDENTS) {
            f1ActiveS = "_";
        } else if (this.fsm.getState() == GpeState.TEACHERS) {
            f1ActiveT = "_";
        } else if (this.fsm.getState() == GpeState.PROPOSALS) {
            f1ActiveP = "_";
        }

        if (!Utils.fileExists(this.fsm.getState().toString(), "exports") && inactivePhase.equals("")) {
            exportExists = "⇢ ";
        }

        if (f1ActiveP == "_")
            f1ActiveBreak = "\n";


        if (!fsm.getNotDataPossible(GpeState.TEACHERS))
            withData_Teachers = "❱";
        if (!fsm.getNotDataPossible(GpeState.STUDENTS))
            withData_Students = "❱";
        if (!fsm.getNotDataPossible(GpeState.PROPOSALS)) //send GPESTATE.PROPOSALS
            withData_Proposals = "❱";


            if (fsm.getNotDataPossible(GpeState.TEACHERS)
                    || fsm.getNotDataPossible(GpeState.STUDENTS)
                    || fsm.getNotDataPossible(GpeState.PROPOSALS)){
                closePhase = "_";
            }


        withData = iconData(fsm);

        if (this.fsm.getState() == GpeState.STUDENTS) {
            f1ActiveS = "_";
            if (fsm.getNotDataPossible(GpeState.STUDENTS))
                noData = "⇢ ";
        } else if (this.fsm.getState() == GpeState.TEACHERS) {
            f1ActiveT = "_";
            if (fsm.getNotDataPossible(GpeState.TEACHERS))
                noData = "⇢ ";
        } else if (this.fsm.getState() == GpeState.PROPOSALS) {
            f1ActiveP = "_";
            if (fsm.getNotDataPossible(GpeState.PROPOSALS))
                noData = "⇢ ";
        } else if (this.fsm.getState() == GpeState.CANDIDATURE) {
            if (fsm.getNotDataPossible(GpeState.CANDIDATURE))
                noData = "⇢ ";
        } else if (this.fsm.getState() == GpeState.ASSIGNEDPROPOSALS) {
            if (fsm.getNotDataPossible(GpeState.ASSIGNEDPROPOSALS))
                noData = "⇢ ";
        } else if (this.fsm.getState() == GpeState.ADVISORS) {
            if (fsm.getNotDataPossible(GpeState.ADVISORS))
                noData = "⇢ ";
        }

        if(fsm.getNotDataPossible(GpeState.TEACHERS) || fsm.getNotDataPossible(GpeState.STUDENTS))
            teachStudentDataOn = "⇢ ";

        String[] consultChoose = {
                //Consult
                "Consult" + menuInSmallSpace + nofilterorder2,
                "Order" + menuInSmallSpace,
                "Filter"
                        + bkLinePhasesActions + "\n",//Manage
                "Edit   " + menuInBetweenSpace,
                "Insert\n",
                "Delete " + menuInBetweenSpace,
                "Delete All\n",
                "Exports" + menuInBetweenSpace,
                "Exports Remove"
                        + bkLinePhases, //Phases

                "Back  " + bkLinePrevious,
                "Next " + bkLineAdvance,
                "Close Phase" + (fsm.getPhase()) + bkLineclosePhase,
                "Teachers " + withData_Teachers + " ".repeat(13),
                "Students " + withData_Students + " ".repeat(13) + f1ActiveBreak,
                "Proposals " + withData_Proposals + "\n",
                "Main"
        };

        noDataChange = noData;

        if (nofilterorder.equals("⇢ ") && noData.equals("⇢ "))
            noData = "";

        if (inactivePhase.equals("⇢ ") && noDataChange.equals("⇢ "))
            noDataChange = "";


        switch (Input.chooseOptionNoBreaks("\n ⧉ " + this.fsm.getState()
                        + "\n  \uD83D\uDD03 Phase: " + fsm.getPhase() + " " + withData
                        + "\n  \uD83D\uDD13 Closed: " + fsm.getClosePhase() + "  " + bkLineConsultActions,
                noData  + consultChoose[indexChoose], //consult
                nofilterorder + noData  + consultChoose[indexChoose + 1], //order
                nofilterorder + noData  + consultChoose[indexChoose + 2], //Filter
                noDataChange + inactivePhase  + consultChoose[indexChoose + 3], //edit
                inactivePhase + consultChoose[indexChoose + 4], //Insert
                noDataChange + inactivePhase +  consultChoose[indexChoose + 5], //Delete
                noDataChange + inactivePhase  +  consultChoose[indexChoose + 6], //Delete All
                noData  +  consultChoose[indexChoose + 7], //Export
                exportExists + consultChoose[indexChoose + 8], //Export Remove
                previous + consultChoose[indexChoose + 9], // Back
                advance + consultChoose[indexChoose + 10],  //Next
                closePhase + noDataChange + inactivePhase + consultChoose[indexChoose + 11], //Close Phase
                f1Menu + f1ActiveT + consultChoose[indexChoose + 12], //Teachers
                f1Menu + f1ActiveS + consultChoose[indexChoose + 13], //Students
                f1Menu + f1ActiveP + teachStudentDataOn + consultChoose[indexChoose + 14], //Proposals
                consultChoose[indexChoose + 15] + "\n\n")) { //Main
            case 1: //consult
                if (!inactivePhaseNext.equals("⇢ ") && !noData.equals("⇢ ")) {//if inactive fase or no data impossible to choose

                    if (fsm.getPhase() > 1) {
                        ConsultP2P3P4();
                    } else
                        System.out.println(this.fsm.consult(1, ""));
                    this.activeStateUI();
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;
            case 2: //order
                if (!noData.equals("⇢ ")) {//if inactive fase or no data impossible to choose

                    if (fsm.getPhase() != 3) {
                        if (!inactivePhaseNext.equals("⇢ ")) {//if inactive fase impossible to choose
                            this.order(fsm);
                            activeStateUI();
                        } else {
                            Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                        }
                    }
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;
            case 3://filter
                if (!noData.equals("⇢ ")) {//if inactive fase or no data impossible to choose
                    if (fsm.getPhase() != 3) {
                        if (!inactivePhaseNext.equals("⇢ ")) {//if inactive fase impossible to choose
                            this.filter(fsm);
                            activeStateUI();
                        } else {
                            Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                        }
                    }
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;
            case 4://edit
                if (!inactivePhase.equals("⇢ ") && !noData.equals("⇢ ")) {//if inactive fase impossible to choose


                    switch (this.fsm.getState()) {
                        case STUDENTS -> this.editStudents(fsm);
                        case TEACHERS -> this.editTeachers(fsm);
                        case CANDIDATURE -> this.editCandidature(fsm);
                        case PROPOSALS -> this.editProposals(fsm);
                        case ASSIGNEDPROPOSALS -> this.editAssigProposals(fsm);
                        case ADVISORS -> this.editP4Advisors(fsm);

                    }
                    fsm.save();
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;
            case 5://Insert


                if (!inactivePhase.equals("⇢ ")) {//if inactive fase impossible to choose
                    if(!fsm.isEmpty())
                        insertData(fsm);
                    else{
                        /*System.out.println("You left data to add in the other states, want add proposals without them? (yes - 1,no - 0)");
                        Scanner sc = new Scanner(System.in);
                        int resp = sc.nextInt();*/
                        //if(resp == 1)
                        insertData(fsm);

                    }

                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();

                break;
            case 6://Delete
                if (!inactivePhase.equals("⇢ ") && !noData.equals("⇢ ")) {//if inactive fase impossible to choose
                    if (this.delete(fsm)) {
                        System.out.println("\n✔ Deleted sucessufully!\n");
                        fsm.save();
                        this.fsm.refreshState();
                    } else
                        Utils.errorPrint("\n" + Errors.DELETE_ERROR.getError() + "\n");
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;

            case 7://Delete All
                if (!inactivePhase.equals("⇢ ") && !noData.equals("⇢ ")) {//if inactive fase impossible to choose
                    if (deleteAll(fsm)) {
                        System.out.println("\n✔ All imported data from this categorie deleted Sucessufully!\n");
                        this.fsm.refreshState();
                    } else
                        Utils.errorPrint("\n" + Errors.DELETE_ALL_ERROR.getError() + "\n");
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }

                activeStateUI();
                break;

            case 8://Export
                if (!inactivePhaseNext.equals("⇢ ") && !noData.equals("⇢ ")) {//if inactive fase impossible to choose
                    exportData(fsm);
                    activeStateUI();
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                break;
            case 9://Export remove
                if (!inactivePhaseNext.equals("⇢ ") && !exportExists.equals("⇢ ")) {//if inactive fase impossible to choose
                    if (exportRemove(fsm)) {
                        System.out.println("\n✔ Export data from this categorie removed!\n");
                        this.fsm.refreshState();
                    } else
                        Utils.errorPrint("\n" + Errors.EXPORT_REMOVE_ERROR.getError() + "\n");
                    activeStateUI();
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }

                break;
            case 10: //Back
                if (!previous.equals("⇢ ")) {//if previous empty shows
                    this.fsm.previousPhase();
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;
            case 11://Next
                if (!advance.equals("⇢ ") || fsm.getPhase() != 4) { //if advance empty shows
                    this.fsm.advancePhase();
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();


                break;
            case 12://Close Phase
                if (!closePhase.equals("_")  && !inactivePhase.equals("⇢ ") && !noData.equals("⇢ ")) { //if advance empty shows

                    if (fsm.getPhase() == 3) { // primeira entrada no programa faz load


                        if(fsm.attributedProposals().isEmpty()){

                            if (this.fsm.closePhase())
                                fsm.save();
                            else
                                Utils.errorPrint(Errors.CLOSESTATE_ERROR.getError());

                        }else {
                            System.out.println(Errors.GENERAL_ERROR.getError() + " You cannot close the phase, students are tied! Please edit:\n\n");
                            this.editAssigProposals(fsm);
                        }

                    }else {



                        if (this.fsm.closePhase())
                            fsm.save();
                        else
                            Utils.errorPrint(Errors.CLOSESTATE_ERROR.getError());
                    }
                } else {
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                }
                activeStateUI();
                break;
            case 13://Teachers
                if (!f1Menu.equals("_")) //if advance empty shows
                    this.fsm.f1_teachers();
                else
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                activeStateUI();
                break;
            case 14://Students
                if (!closePhase.equals("_")) //if advance empty shows
                    this.fsm.f1_students();
                else
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                activeStateUI();
                break;
            case 15: //Proposal
                if (!f1Menu.equals("_") && !teachStudentDataOn.equals( "⇢ ")) //if advance empty shows
                    this.fsm.f1_propProj();
                else
                    Utils.errorPrint("\n" + Errors.OPTION_NOTVALID_ERROR.getError() + "\n");
                activeStateUI();
                break;
            case 16: //Main Menu
                start();
                break;
            default:
                activeStateUI();
                break;
        }
    }

    private boolean insertData(GpeContext fsm) {

        if (fsm.getPhase() == 3 || fsm.getPhase() == 4) {
            if (this.InsertP3P4()) {
                System.out.println("\n✔ Dados adicionados!\n");
                fsm.save();
                this.fsm.refreshState();
                return true;
            } else {
                Utils.errorPrint("\n" + Errors.FILENOTFOUND_ERROR.getError() + "\n");
                return false;
            }
        } else {
            Scanner sc = new Scanner(System.in);
            sc.useDelimiter("[\r\n]");
            String nameFile="";
            System.out.print("\n - Insert data - \n ");

            if (confirmOperation("Insert with default name?")) {

                if (this.fsm.insert(nameFile)) {
                    System.out.println("\n✔ Dados adicionados!\n");
                    fsm.save();
                    this.fsm.refreshState();
                    return true;
                } else{
                    Utils.errorPrint("\n" + Errors.FILENOTFOUND_ERROR.getError() + "\n");
                    return false;
                }


            }else{

                do {
                    System.out.print("Please insert the name of a file you wish to import: ");

                    nameFile = sc.next();

                    if (cancelOperation(nameFile))
                        return false;

                    if(nameFile.length()>4) {
                        if (!nameFile.endsWith(".csv"))
                            nameFile = nameFile + ".csv";
                    }else{
                        nameFile = nameFile + ".csv";
                    }


                    System.out.println("\n" + nameFile);
                    if(!Utils.fileExists(nameFile, "imports"))
                        System.out.println("\n✘ -> Ficheiro inexistente! (cancel - to quit || \"d\" to load default file)\n");

                    if(Utils.checkEmptyFile(nameFile))
                        System.out.println("\n✘ -> Ficheiro vazio! (cancel - to quit || \"d\" to load default file )\n");


                }while (!Utils.fileExists(nameFile, "imports") && !Utils.checkEmptyFile(nameFile) && !nameFile.equals("d.csv"));

                if(Utils.fileExists(nameFile, "imports") || nameFile.equals("d.csv")) {
                    if(nameFile.equals("d.csv"))
                        nameFile="";

                    this.fsm.insert(nameFile);
                }

            }
        }

        return false;

    }

    private boolean exportData(GpeContext fsm) {

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("[\r\n]");
        String nameFile="";
        System.out.print("\n - Export data - \n ");

        if (confirmOperation("Insert with default name for export?")) {

            if (this.fsm.export(nameFile)) {
                System.out.println("\n✔ Dados exportados!\n");
                fsm.save();
                this.fsm.refreshState();
                return true;
            } else{
                Utils.errorPrint("\n" + Errors.FILENOTFOUND_ERROR.getError() + "\n");
                return false;
            }


        }else{


            System.out.print("Please insert the name of a file you wish to export: (cancel - to quit || \"d\" to load default file)\n");

            nameFile = sc.next();

            if (cancelOperation(nameFile))
                return false;

            if(nameFile.length()>4) {
                if (!nameFile.endsWith(".csv"))
                    nameFile = nameFile + ".csv";
            }else{
                nameFile = nameFile + ".csv";
            }


            if(nameFile.equals("d.csv"))
                nameFile="";

            this.fsm.export(nameFile);

        }


        return false;

    }


    private void ConsultP2P3P4() {
        int LineComplete = 50, indexChoose = 0, indexChooseTitles = 0;

        String menuInSmallSpace = " ".repeat(10);
        String phase2 = "", phase3 = "", phase4 = "", filter1, filter2,filter3,filter4,filter5,filter6,filter7,filter8;


        String[] consultTitleChooseI = {
                "―".repeat(3) + " Student Lists P2 " + "―".repeat(3),
                "  Proposals and Internship ", //P2
                "―".repeat(3) + " Student Lists P3 " + "―".repeat(3),
                "  Projects / Internship  ", //P3
                "―".repeat(3) + " Advisor Lists P4 " + "―".repeat(3),
                "―".repeat(3) + "  Menu  " + "―".repeat(3),
                //P4
        };
        int[] consultTitleSize = {
                (LineComplete - consultTitleChooseI[0].length() - 8) / 2,
                (LineComplete - consultTitleChooseI[1].length() - 4) / 2, //P2
                (LineComplete - consultTitleChooseI[2].length() - 8) / 2,
                (LineComplete - consultTitleChooseI[3].length() - 4) / 2, //P3
                (LineComplete - consultTitleChooseI[4].length() - 8) / 2, //P4
                (LineComplete - consultTitleChooseI[5].length() - 12) / 2}; //Menu

        String[] consultTitleChoose = {
                " \n" + "―".repeat(consultTitleSize[0]) + consultTitleChooseI[0] + "―".repeat(consultTitleSize[0]) + "\n",
                " \n" + "―".repeat(consultTitleSize[1]) + consultTitleChooseI[1] + "―".repeat(consultTitleSize[1]) + " \n\n", //P2

                " \n" + "―".repeat(consultTitleSize[2]) + consultTitleChooseI[2] + "―".repeat(consultTitleSize[2]) + " \n",
                " \n" + "―".repeat(consultTitleSize[3]) + consultTitleChooseI[3] + "―".repeat(consultTitleSize[3]) + " \n\n", //P3

                " \n" + "―".repeat(consultTitleSize[4]) + consultTitleChooseI[4] + "―".repeat(consultTitleSize[4]) + " \n", //P4
                " \n" + "―".repeat(consultTitleSize[5]) + consultTitleChooseI[5] + "―".repeat(consultTitleSize[5]) + " \n"  // Menu
        };

        if(fsm.filterIsActive(1))
            filter1 = " ⛛";
        else
            filter1 = "";
        if(fsm.filterIsActive(2))
            filter2 = " ⛛";
        else
            filter2 = "";
        if(fsm.filterIsActive(3))
            filter3 = " ⛛";
        else
            filter3 = "";
        if(fsm.filterIsActive(4))
            filter4 = " ⛛";
        else
            filter4 = "";
        if(fsm.filterIsActive(1))
            filter5 = " ⛛";
        else
            filter5 = "";
        if(fsm.filterIsActive(2))
            filter6 = " ⛛";
        else
            filter6 = "";
        if(fsm.filterIsActive(3))
            filter7 = " ⛛";
        else
            filter7 = "";
        if(fsm.filterIsActive(4))
            filter8 = " ⛛";
        else
            filter8 = "";

        if(filter1.equals(" ⛛")) {
            filter2 = " \uD83D\uDCA2";
        }
        if(filter2.equals(" ⛛")) {
            filter1 = " \uD83D\uDCA2";
        }

        if(filter3.equals(" ⛛")){
            filter4 = " \uD83D\uDCA2";

        }
        if(filter4.equals(" ⛛")) {
            filter3 = " \uD83D\uDCA2";
        }
        if(filter5.equals(" ⛛")){
            filter6 = " \uD83D\uDCA2";
        }
        if(filter6.equals(" ⛛")) {
            filter5 = " \uD83D\uDCA2";
        }
        if(filter7.equals(" ⛛")){
            filter8 = " \uD83D\uDCA2";
        }
        if(filter8.equals(" ⛛")) {
            filter7 = " \uD83D\uDCA2";
        }
        if (this.fsm.getState() == GpeState.CANDIDATURE) {
            phase3 = "_";
            phase4 = "_";
            consultTitleChoose[indexChooseTitles + 2] = "";
            consultTitleChoose[indexChooseTitles + 3] = "";
            consultTitleChoose[indexChooseTitles + 4] = "";
        } else if (this.fsm.getState() == GpeState.ASSIGNEDPROPOSALS) {
            phase2 = "_";
            phase4 = "_";
            consultTitleChoose[indexChooseTitles] = "";
            consultTitleChoose[indexChooseTitles + 1] = "";
            consultTitleChoose[indexChooseTitles + 4] = "";
        } else if (this.fsm.getState() == GpeState.ADVISORS) {
            phase2 = "_";
            phase3 = "_";
            consultTitleChoose[indexChooseTitles] = "";
            consultTitleChoose[indexChooseTitles + 1] = "";
            consultTitleChoose[indexChooseTitles + 2] = "";
            consultTitleChoose[indexChooseTitles + 3] = "";
        }

        String filterstr = "Filter ";
        String[] consultChoose = {
                //P2
                "All Proposals" + menuInSmallSpace, "Assigned Candidature\n",
                "Auto-Proposal" + menuInSmallSpace, "Without Candidature\n" + consultTitleChoose[indexChooseTitles + 1],
                "Student Auto-Proposals" + filter1 + menuInSmallSpace + "\n", "Teachers Proposals" + filter2 +"\n", //P2
                "Proposals With Candidature" + filter3 + "" + menuInSmallSpace + "\n", "Proposals Without Candidature" + filter4 + "\n"
                + consultTitleChoose[5],

                //P3
                "Auto-Proposals    " + " ".repeat(6), "Registered Candidature\n",
                "Assigned Proposals" + " ".repeat(6),
                "without assignement\n"
                        + consultTitleChoose[indexChooseTitles + 3],

                "Student Auto-Proposals " + filter5 + menuInSmallSpace + "\n", "Teachers Proposals" + filter6 +"\n", //P3
                "Available Proposals " + filter7 + menuInSmallSpace + "\n", "Assigned Proposals" + filter8 +"\n",

                //P4
                "All data     \n",
                "Proposals with Advisor\n", "Assigned without Advisor\n", "Statistics\n",
                "Without assignement\n"
        };

        switch (Input.chooseOptionNoBreaksChangeOptNum(" \uD83D\uDCC4 Consult " + fsm.getState() + "\n" + consultTitleChoose[indexChooseTitles] + consultTitleChoose[indexChooseTitles + 2] + consultTitleChoose[indexChooseTitles + 4],
                phase2 + consultChoose[indexChoose],
                phase2 + consultChoose[indexChoose + 1],
                phase2 + consultChoose[indexChoose + 2],
                phase2 + consultChoose[indexChoose + 3],
                phase2 + consultChoose[indexChoose + 4],
                phase2 + consultChoose[indexChoose + 5],
                phase2 + consultChoose[indexChoose + 6],
                phase2 + consultChoose[indexChoose + 7]
                        + "\n ",
                phase3 + consultChoose[indexChoose + 8],
                phase3 + consultChoose[indexChoose + 9],
                phase3 + consultChoose[indexChoose + 10],
                phase3 + consultChoose[indexChoose + 11],
                phase3 + consultChoose[indexChoose + 12],
                phase3 + consultChoose[indexChoose + 13],
                phase3 + consultChoose[indexChoose + 14],
                phase3 + consultChoose[indexChoose + 15] + consultTitleChoose[5] + "\n ",

                phase4 + consultChoose[indexChoose + 16],
                phase4 + consultChoose[indexChoose + 17],
                phase4 + consultChoose[indexChoose + 18],
                phase4 + consultChoose[indexChoose + 19],
                phase4 + consultChoose[indexChoose + 20] + consultTitleChoose[5] + "\n ",
                "Menu" + menuInSmallSpace + menuInSmallSpace, "Main-Menu"
                        + "\n\n")) {
            case 1:
                if (fsm.getPhase() == 2) {
                    fsm.resetFilter();
                    System.out.println(this.fsm.consult(1, ""));
                }
                this.ConsultP2P3P4();
                break;
            case 2:
                fsm.resetFilter();
                if (fsm.getPhase() == 2) {
                    fsm.resetFilter();
                    System.out.println(fsm.ToStringSelector(2));
                }
                ConsultP2P3P4();
                break;
            case 3:
                fsm.resetFilter();
                if (fsm.getPhase() == 2) {
                    fsm.resetFilter();
                    System.out.println(fsm.ToStringSelector(1));
                }
                ConsultP2P3P4();
                break;
            case 4:
                fsm.resetFilter();
                if (fsm.getPhase() == 2) {
                    fsm.resetFilter();
                    System.out.println(fsm.ToStringSelector(3));
                }
                ConsultP2P3P4();
                break;

            case 5:
                if (fsm.getPhase() == 2 && !filter1.equals(" \uD83D\uDCA2") && !filter2.equals(" ⛛")) {
                    System.out.println(fsm.toStringfilter(1));
                }
                ConsultP2P3P4();
                break;
            case 6:
                if (fsm.getPhase() == 2 && !filter2.equals(" \uD83D\uDCA2") && !filter1.equals(" ⛛")) {
                    System.out.println(fsm.toStringfilter(2));
                }
                ConsultP2P3P4();
                break;
            case 7:
                if (fsm.getPhase() == 2 && !filter3.equals(" \uD83D\uDCA2") && !filter4.equals(" ⛛")) {
                    System.out.println(fsm.toStringfilter(3));
                }
                ConsultP2P3P4();
                break;
            case 8:
                if (fsm.getPhase() == 2 && !filter4.equals(" \uD83D\uDCA2") && !filter3.equals(" ⛛")) {
                    System.out.println(fsm.toStringfilter(4));
                }
                ConsultP2P3P4();
                break;
            case 9:
                if (fsm.getPhase() == 3) {
                    fsm.resetFilter();
                    System.out.println(fsm.listStudents(1));
                }
                ConsultP2P3P4();
                break;
            case 10:
                if (fsm.getPhase() == 3) {
                    fsm.resetFilter();
                    System.out.println(fsm.listStudents(2));
                }
                ConsultP2P3P4();
                break;
            case 11:
                if (fsm.getPhase() == 3) {
                    fsm.resetFilter();
                    System.out.println(fsm.listStudents(3));
                }
                ConsultP2P3P4();
                break;
            case 12:
                if (fsm.getPhase() == 3) {
                    fsm.resetFilter();
                    System.out.println(fsm.listStudents(4));
                }
                ConsultP2P3P4();
                break;
            case 13:
                if (fsm.getPhase() == 3 && !filter5.equals(" \uD83D\uDCA2") && !filter6.equals(" ⛛")) {
                    System.out.println(fsm.filter(1));
                }
                ConsultP2P3P4();
                break;
            case 14:
                if (fsm.getPhase() == 3 && !filter6.equals(" \uD83D\uDCA2") && !filter5.equals(" ⛛")) {
                    System.out.println(fsm.filter(2));
                }
                ConsultP2P3P4();
                break;
            case 15:
                if (fsm.getPhase() == 3 && !filter7.equals(" \uD83D\uDCA2") && !filter8.equals(" ⛛")) {
                    System.out.println(fsm.filter(3));
                }
                ConsultP2P3P4();
                break;
            case 16:
                if (fsm.getPhase() == 3 && !filter8.equals(" \uD83D\uDCA2") && !filter7.equals(" ⛛")) {
                    System.out.println(fsm.filter(4));
                }
                ConsultP2P3P4();
                break;
            case 17:
                if (fsm.getPhase() == 4)
                    System.out.println(this.fsm.consult(1, ""));
                ConsultP2P3P4();
                break;
            case 18:
                if (fsm.getPhase() == 4)
                    System.out.println(fsm.getList(1,""));
                ConsultP2P3P4();
                break;
            case 19:
                if (fsm.getPhase() == 4)
                    System.out.println(fsm.getList(2,""));
                ConsultP2P3P4();
                break;
            case 20:
                if (fsm.getPhase() == 4)
                    System.out.println(fsm.getList(3,""));
                ConsultP2P3P4();
                break;
            case 21:
                if (fsm.getPhase() == 4)
                    System.out.println(fsm.getList(4,""));
                ConsultP2P3P4();
                break;
            case 22:
                if (fsm.getPhase() == 2 )
                    fsm.resetFilter();
                if (fsm.getPhase() == 3 )
                    fsm.resetFilter();
                activeStateUI(); //go back
                break;
            case 23:
                if (fsm.getPhase() == 2 )
                    fsm.resetFilter();
                if (fsm.getPhase() == 3 )
                    fsm.resetFilter();
                start(); //Main Menu
                break;
        }
    }


    private boolean InsertP3P4() {
        int LineComplete = 30, indexChoose = 0, indexChooseTitles = 0;
        String menuInSmallSpace = " ".repeat(10);
        String bkLineP3 = "―".repeat(3) + " Proposal Attribuion  " + "―".repeat(3);
        String bkLineP4 = "―".repeat(3) + " Advisors Assignment " + "―".repeat(3);
        String bkLineMenu = "―".repeat(3) + " Menu " + "―".repeat(3);
        String phase3 = "";
        String phase4 = "";


        int[] consultTitleSize = {
                (LineComplete - bkLineP3.length() + 6) / 2,
                (LineComplete - bkLineP4.length() + 6) / 2,
                (LineComplete - bkLineMenu.length()) / 2}; //Menu

        String[] consultTitleChoose = {
                " \n" + "―".repeat(consultTitleSize[0]) + bkLineP3 + "―".repeat(consultTitleSize[0]) + "\n", //P3
                " \n" + "―".repeat(consultTitleSize[1]) + bkLineP4 + "―".repeat(consultTitleSize[1]) + " \n",
                " \n" + "―".repeat(consultTitleSize[2]) + bkLineMenu + "―".repeat(consultTitleSize[2]) + " \n" //P4
        };

        if (this.fsm.getState() == GpeState.ASSIGNEDPROPOSALS) {
            phase4 = "_";

            consultTitleChoose[indexChooseTitles + 1] = "";

        } else if (this.fsm.getState() == GpeState.ADVISORS) {

            phase3 = "_";

            consultTitleChoose[indexChooseTitles] = "";
        }

        String filterstr = "Filter ";

        String[] consultChoose = {
                "Automatic     ", "Automatic available\n", //P3
                "Manual with Student\n",

                "Automatic" + " ".repeat(3) + menuInSmallSpace, "Manual\n"};//P4

        switch (Input.chooseOptionNoBreaksChangeOptNum(" \uD83D\uDCC4 Insert " + fsm.getState() + "\n"
                        + consultTitleChoose[indexChooseTitles]
                        + consultTitleChoose[indexChooseTitles + 1]
                        + menuInSmallSpace,
                phase3 + consultChoose[indexChoose],
                phase3 + consultChoose[indexChoose + 1],
                phase3 + consultChoose[indexChoose + 2] + consultTitleChoose[2] + "",
                phase4 + consultChoose[indexChoose + 3],
                phase4 + consultChoose[indexChoose + 4] + consultTitleChoose[2] + "",
                "Menu" + " ".repeat(8) + menuInSmallSpace, "Main-Menu"
                        + "\n\n")) {
            case 1:
                if (fsm.getPhase() == 3) {
                    fsm.atributeAutoProposals();
                }
                activeStateUI();
                break;
            case 2:
                if (fsm.getPhase() == 3)
                    fsm.atributeProposals();
                activeStateUI();
                break;
            case 3:
                if (fsm.getPhase() == 3)
                    insertAssignment(fsm);
                activeStateUI();
                break;
            case 4:
                if (fsm.getPhase() == 4)
                    if (fsm.addAutoDesignedAdvisor())
                        System.out.println("\n✔ Automatic assignment");
                activeStateUI();
                break;

            case 5:
                if (fsm.getPhase() == 4)
                    manualInsertP4(fsm);
                activeStateUI();
                break;
            case 6:
                activeStateUI(); //go back
                break;
            case 7:
                start(); //Main Menu
                break;

        }
        return true;
    }

    private void ConsultP5() {
        int LineComplete = 28, indexChoose = 0;

        String titleReptline = "―".repeat((LineComplete - 2) / 2),
                menuInBetweenSpace = " ".repeat(15),
                bkLineConsultActions = "\n" + titleReptline + " Consult " + titleReptline + "",
                bkLineExportActions = "\n" + titleReptline + " Export " + titleReptline + "",
                bkLineMenu = "\n" + titleReptline + "  Menu  " + titleReptline + "\n", previous = "", withData = "",exportExists = "⇢ ";

        if (this.fsm.getState() == GpeState.STUDENTS || this.fsm.getState() == GpeState.TEACHERS
                || this.fsm.getState() == GpeState.PROPOSALS) {
            previous = "_";
        }


        withData = iconData(fsm);

        if (Utils.fileExists(GpeState.TEACHERS.toString(), "exports") ||
                Utils.fileExists(GpeState.STUDENTS.toString(), "exports") ||
                Utils.fileExists(GpeState.PROPOSALS.toString(), "exports") ||
                Utils.fileExists(GpeState.CANDIDATURE.toString(), "exports") ||
                Utils.fileExists(GpeState.ASSIGNEDPROPOSALS.toString(), "exports") ||
                Utils.fileExists(GpeState.ADVISORS.toString(), "exports") ||
                Utils.fileExists(GpeState.CONSULT.toString(), "exports")){
            exportExists = " ";
        }

        String[] consultChoose = {
                //Consult
                "Students with assigned Proposals\n",
                "Students with candidature with no Proposals\n",
                "Available Proposals\n",
                "Assigned Proposals  \n",
                "Advisor Stats\n" + bkLineExportActions + "\n",
                "_ ",
                "_ ",
                "Exports" + menuInBetweenSpace,
                "Exports Remove"
                        + bkLineMenu, //Phases
                "Main"

        };


        switch (Input.chooseOptionNoBreaks(" ⧉ " + this.fsm.getState()
                        + "\n  \uD83D\uDD03 Phase: " + fsm.getPhase() + " " + withData
                        + "\n  \uD83D\uDD13 Closed " + "  " + bkLineConsultActions,
                consultChoose[indexChoose],
                consultChoose[indexChoose + 1],
                consultChoose[indexChoose + 2],
                consultChoose[indexChoose + 3],
                consultChoose[indexChoose + 4],
                consultChoose[indexChoose + 5],
                consultChoose[indexChoose + 6],
                consultChoose[indexChoose + 7],
                exportExists + consultChoose[indexChoose + 8],
                consultChoose[indexChoose + 9] + "\n\n")) {
            case 1:
                System.out.println(fsm.listStdWithProposalsAssigned());
                ConsultP5();
                break;
            case 2:
                System.out.println(fsm.listStdWithoutAssigAndCand());
                ConsultP5();
                break;
            case 3:
                System.out.println(fsm.listPropAvailable());
                ConsultP5();
                break;
            case 4:
                System.out.println(fsm.lisTWithAllProposalsAssigned());
                ConsultP5();
                break;
            case 5:
                System.out.println(fsm.advisorsGeneralStatus());
                ConsultP5();
                break;
            case 6:
                Utils.errorPrint(Errors.OPTION_NOTVALID_ERROR.getError());
                ConsultP5();
                break;
            case 7:
                ConsultP5();
                Utils.errorPrint(Errors.OPTION_NOTVALID_ERROR.getError());
                break;
            case 8:
                exportData(fsm);
                ConsultP5();
                break;
            case 9:
                if(exportExists.equals(" ")) {
                    if (exportRemove(fsm)) {
                        System.out.println("\n✔ Export data from this categorie removed!\n");
                        this.fsm.refreshState();
                    } else
                        Utils.errorPrint("\n" + Errors.EXPORT_REMOVE_ERROR.getError() + "\n");
                }else{
                    Utils.errorPrint("\n" + Errors.EXPORT_REMOVE_ERROR.getError() + "\n");

                }
                ConsultP5();
                break;
            case 10:
                start();
                break;
        }
    }





}


