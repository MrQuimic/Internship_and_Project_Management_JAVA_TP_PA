package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;
import pt.isec.poe_deis_cl.ui.gui.resources.SoundManager;
/**
 * Class description:
 *
 * Credits
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */

/**
 * The type Root pane.
 */
public class Credits extends BorderPane {

    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;
    /**
     * The Background.
     */
    Color background = Color.LIGHTGRAY;
    /**
     * The Nr meta 1.
     */
    int nrMeta1,
    /**
     * The Nr meta 2.
     */
    nrMeta2,
    /**
     * The Nr custom.
     */
    nrCustom;
    /**
     * The Button meta 1.
     */
    Button buttonMeta1,
    /**
     * The Button meta 2.
     */
    buttonMeta2,
    /**
     * The Button custom.
     */
    buttonCustom,
    /**
     * The Btn menu.
     */
    btnMenu;
    /**
     * The Text field.
     */
    TextField textField;
    private Label lbStatus;
    private Label lbStatus2;

    /**
     * Instantiates a new Root pane.
     *
     * @param gpeManager the gpe manager
     */
    public Credits(GpeManager gpeManager){
        this.gpeManager = gpeManager;
        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {

        setPadding(new Insets(5));
        buttonMeta1 = new Button("ISEC");
        buttonMeta1.setMinWidth(100);
        buttonMeta1.setId("buttonMeta1");
        buttonMeta2 = new Button("Project");
        buttonMeta2.setMinWidth(100);
        buttonMeta2.setId("buttonMeta1");
        btnMenu = new Button("Main Menu");
        btnMenu.setMinWidth(100);
        btnMenu.setId("buttonMainMenu2");
        btnMenu.setAlignment(Pos.CENTER);
        this.setCenter(btnMenu);
        HBox hbox = new HBox();
        hbox.getChildren().addAll(buttonMeta2, btnMenu, buttonMeta1);
        hbox.setSpacing(30);
        setTop(hbox);
        hbox.setAlignment(Pos.TOP_CENTER);
        lbStatus = new Label();
        lbStatus2 = new Label();
        lbStatus.setPrefWidth(Integer.MAX_VALUE);
        lbStatus.setStyle("-fx-background-color: rgba(73,69,69,0.08);-fx-font-family: 'Courrier New'; -fx-font-size: 16;");
        lbStatus.setPadding(new Insets(10));
        lbStatus.setBorder(new Border(new BorderStroke(Color.DARKGRAY,
                BorderStrokeStyle.SOLID,CornerRadii.EMPTY,new BorderWidths(1))));

        lbStatus2.setPrefWidth(Integer.MAX_VALUE);
        lbStatus2.setPadding(new Insets(2));
        lbStatus2.setPadding(new Insets(2));
        lbStatus2.setBorder(new Border(new BorderStroke(Color.DARKGRAY,
                BorderStrokeStyle.SOLID,CornerRadii.EMPTY,new BorderWidths(2))));

        lbStatus2.setStyle("-fx-background-color: rgba(73,69,69,0.08);-fx-font-family: 'Courrier New'; -fx-font-size: 16;");
        this.setBottom(lbStatus);
        this.setCenter(lbStatus2);
    }

    private void registerHandlers() {

        btnMenu.setOnAction(event -> {
            gpeManager.setMenuOpt(MenuOpt.STARTMENU);

        });


            gpeManager.addPropertyChangeListener(evt -> { update(); });


        buttonMeta1.setOnAction(actionEvent -> {
            background = Color.LIGHTGOLDENRODYELLOW;
            if (nrMeta2 < 20)
                nrMeta2++;
            update();
        });
        buttonMeta2.setOnAction(actionEvent -> {
            background = Color.LIGHTGRAY;
            if (nrMeta1 < 20)
                nrMeta1++;
            update();
        });
        /*
        buttonCustom.addEventFilter(ActionEvent.ACTION, actionEvent -> {
            try {
                background = Color.valueOf(textField.getText());
            } catch (Exception e){
                textField.setStyle("-fx-control-inner-background-color: #ffffff;");
                textField.setStyle("-fx-background-color: rgba(255,9,0,0.47);");
                background = Color.BLACK;
                textField.requestFocus();

            }
            nrCustom++;
            update();
        });


        textField.setOnKeyPressed(keyEvent -> {
            textField.setStyle("-fx-control-inner-background-color: #ffffff;");
            textField.setStyle("-fx-background-color: #ffffff;");

            if(keyEvent.getCode() == KeyCode.ENTER){
                textField.requestFocus();
                buttonCustom.fire();

            }

        });
*/

    }


    private void update() {
/*

            if (gpeManager.getState() != GpeState.TEACHERS) {
                this.setVisible(false);
                return;
            }

 */
            if(gpeManager.getMenuOpt()==MenuOpt.CREDITS) {
                this.setVisible(true);
                SoundManager.play("637996__davejf__melody-loop-110-bpm.mp3");

            }else{
                this.setVisible(false);

                SoundManager.play(" ");

             }


        setBackground(new Background(new BackgroundFill(background, CornerRadii.EMPTY, Insets.EMPTY)));

        lbStatus.setText(String.format(" ⚑ Grades: \n  Objective 1: %d -- Objective 2: %d \n  SetColor: %d", nrMeta1, nrMeta2, nrCustom));

        if (nrMeta1 == 20 || nrMeta2 == 20 || nrCustom == 20) {
            lbStatus2.setText(String.format("" +
                    "\uD83D\uDCAF \uD83D\uDCAA \uD83D\uDCAB Winner!!!! That is perfect score for our Objective! Thank you!" +
                    "\uD83D\uDC96" +
                    "\n\n\n ✎ Authors:\n" +
                    " Carlos Santos  {Email: a2003035578@isec.pt}\n" +
                    " Leonardo Sousa {Email: a2019129243@isec.pt}\n\n"));
        } else {

            lbStatus2.setText(String.format("\n ⚑ Application to support the management of projects and \n internships in the department of computer Science and Engineering at ISEC"+
                    "\n\n ↕ Symbol to indicate the column that is being ordered" +
                    "\n ⧉ When closing the phase the data will be auto assigned, but you can also assign it manually" +
                    "\n Filters will, when chosen , exclude automatically the other filters that would make a list empty" +
                    "\n  ⛛ Filter chosen, \uD83D\uDCA2 Filter excluded" +
                    "\n\n  Import path: \n \uD83D\uDCC2 " + System.getProperty("user.dir")+"/Resources/imports"+
                    "\n  Export path: \n \uD83D\uDCC2 " + System.getProperty("user.dir")+"/Resources/exports \n ✎ Authors:\n" +
                    " Carlos Santos  {Email: a2003035578@isec.pt}\n" +
                    " Leonardo Sousa {Email: a2019129243@isec.pt}\n\n" +
                    " ⌛ Date 2022/06/18\n\n" +
                    " ⚑ This pratical assignment was carried out in an academic context \nfor the subject of Advanced Programming at ISEC!"));



        }

    }
}