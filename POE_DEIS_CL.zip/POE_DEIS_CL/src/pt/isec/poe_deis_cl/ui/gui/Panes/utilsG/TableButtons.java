package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.*;

import javafx.scene.layout.VBox;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Table pane.
 */
public class TableButtons extends BorderPane {


    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The Btn menu.
     */
    Button btnMenu,
    /**
     * The Btn cancel.
     */
    btnCancel,
    /**
     * The Btn visible.
     */
    btnVisible,
    /**
     * The Btn edit.
     */
    btnEdit;
    /**
     * The Cell del button.
     */
    DellCellButton cellDelButton;

    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Delete alert.
     */
    Alert deleteAlert;
    /**
     * The Vbox.
     */
    VBox vbox,
    /**
     * The Vbox 1.
     */
    vbox1,
    /**
     * The V insert manual.
     */
    vInsertManual;
    /**
     * The Text field.
     */
    TextField textField[];
    /**
     * The Text label.
     */
    Label textLabel[];

    /**
     * The Labeltext.
     */
    String labeltext,
    /**
     * The Label close.
     */
    labelClose = "";

    /**
     * The Label handler.
     */
    Label labelHandler;

    /**
     * The Hbox changes.
     */
    HBox hboxChanges,
    /**
     * The Hbox phase 1.
     */
    hboxPhase1,
    /**
     * The Hbox temp message.
     */
    hboxTempMessage;
    /**
     * The Pcs.
     */
    PropertyChangeSupport pcs;
    /**
     * The C update.
     */
    PropertyChangeSupport cUpdate;


    /**
     * The Start col.
     */
    int startCol;
    /**
     * The Table view.
     */
    TableView tableView;
    /**
     * The Column map key.
     */
    String[] columnMapKey;
    /**
     * The Data col name.
     */
    TableColumn<Map, String>[] dataColName;
    /**
     * The Map string table column.
     */
    TableColumn<Map, String> mapStringTableColumn;
    /**
     * The M insert manual.
     */
    Button mInsertManual,
    /**
     * The M undo.
     */
    mUndo,
    /**
     * The M redo.
     */
    mRedo,
    /**
     * The M insert.
     */
    mInsert,
    /**
     * The M delete all.
     */
    mDeleteAll;
    /**
     * The M export.
     */
    Button mExport,
    /**
     * The M export delete.
     */
    mExportDelete,
    /**
     * The M save.
     */
    mSave;
    /**
     * The M student.
     */
    Button mStudent,
    /**
     * The M teachers.
     */
    mTeachers,
    /**
     * The M proposals.
     */
    mProposals;

    /**
     * The Bottom border.
     */
    BottomInfo bottomBorder;
    /**
     * The Combo box.
     */
    ComboBox comboBox;
    /**
     * The Menu bar.
     */
    MenuBarConsult menuBar;

    /**
     * The Table update.
     */
    PropertyChangeSupport tableUpdate;


    /**
     * Instantiates a new Table buttons.
     *
     * @param gpeManager           the gpe manager
     * @param tempMessage          the temp message
     * @param tableView            the table view
     * @param columnMapKey         the column map key
     * @param mapStringTableColumn the map string table column
     * @param dataColName          the data col name
     * @param menuBar              the menu bar
     * @param deleteAlert          the delete alert
     * @param btnCancel            the btn cancel
     * @param vInsertManual        the v insert manual
     * @param comboBox             the combo box
     * @param label                the label
     * @param labelClose           the label close
     * @param bottomBorder         the bottom border
     */
    public TableButtons(GpeManager gpeManager, Text tempMessage, TableView tableView, String[] columnMapKey, TableColumn<Map, String> mapStringTableColumn, TableColumn<Map, String>[] dataColName, MenuBarConsult menuBar, Alert deleteAlert, Button btnCancel, VBox vInsertManual, ComboBox comboBox, Label label, Label labelClose, BottomInfo bottomBorder) {

        this.gpeManager = gpeManager;
        this.tempMessage = tempMessage;
        this.tableView = tableView;
        this.columnMapKey = columnMapKey;
        this.mapStringTableColumn = mapStringTableColumn;
        this.dataColName = dataColName;
        this.menuBar = menuBar;
        this.btnCancel = btnCancel;
        this.comboBox = comboBox;
        this.vInsertManual = vInsertManual;
        this.labeltext = label.getText();
        this.labelHandler = label;
        this.labelClose = labelClose.getText();
        this.bottomBorder = bottomBorder;

        tableUpdate = new PropertyChangeSupport(this);
        cUpdate = new PropertyChangeSupport(this);
        pcs = new PropertyChangeSupport(this);
        createViews();
        registerHandlers();
        update();

    }

    /**
     * Add property change listener.
     *
     * @param listener the listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    /**
     * Add table update change listener.
     *
     * @param listener the listener
     */
    public void addTableUpdateChangeListener(PropertyChangeListener listener) {
        tableUpdate.addPropertyChangeListener(listener);
    }


    private void createViews() {
        CSSManager.applyCSS(this, "styles.css");
        mInsertManual = new Button("Manual Insert");
        mInsertManual.setId("button-39");
        mUndo = new Button("Undo");
        mUndo.setId("button-39");
        mUndo.setMinWidth(55);
        mRedo = new Button("Redo");
        mRedo.setId("button-39");
        mRedo.setMinWidth(55);
        mExport = new Button("Export");
        mExport.setId("button-39");
        mExportDelete = new Button("Export Delete");
        mExportDelete.setId("button-39");
        mSave = new Button("Save");
        mSave.setId("button-39");
        mSave.setMinWidth(55);
        mInsert = new Button("Insert");
        mInsert.setId("button-39");
        mDeleteAll = new Button("Delete All");
        mDeleteAll.setId("button-39");
        mStudent = new Button("Students");
        mStudent.setId("button-39");
        mTeachers = new Button("Teachers");
        mTeachers.setId("button-39");
        mProposals = new Button("Proposals");
        mProposals.setId("button-39");
        this.setCenter(vInsertManual);
        vInsertManual.setVisible(false);
        btnVisible = new Button("Visible");
        btnVisible.setId("button-39");
        btnVisible.setMinWidth(55);
        btnEdit = new Button("Edit");
        btnEdit.setId("buttonNoEdit");
        btnEdit.setMinWidth(55);

        tempMessage = new Text("");


        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);


        textField = new TextField[7];
        textLabel = new Label[7];
        tempMessage.setStyle("-fx-font-weight: bold;");

        vbox1 = new VBox();

        vbox1.setSpacing(5);
        vbox1.setPadding(new Insets(0, 0, 0, 1));
        hboxTempMessage = new HBox();
        hboxTempMessage.getChildren().add(tempMessage);
        hboxTempMessage.setAlignment(Pos.CENTER);


        hboxChanges = new HBox();


        hboxChanges.getChildren().addAll(btnEdit, mInsert, mInsertManual, mUndo, mRedo);


        hboxChanges.setSpacing(5);
        hboxChanges.setAlignment(Pos.TOP_CENTER);
        hboxPhase1 = new HBox();
        if(labeltext.endsWith("PHASE I"))
            hboxPhase1.getChildren().addAll(mStudent, mTeachers, mProposals);

        hboxPhase1.setSpacing(5);
        hboxPhase1.setPadding(new Insets(0.0, 0.0, 0.0, 10.0));
        hboxPhase1.setAlignment(Pos.TOP_CENTER);


             vbox1.getChildren().addAll(hboxTempMessage, hboxChanges, hboxPhase1);

        if(!labelClose.equals("Closed"))
            hboxChanges.setVisible(true);
        else
            hboxChanges.setVisible(false);


        vbox1.setMinWidth(600);
        vbox1.setAlignment(Pos.CENTER);
        vbox1.setSpacing(10);

        if (gpeManager.getState() == GpeState.PROPOSALS) //editable columns
            startCol = 2;
        else
            startCol = 1;

        UtilsGui.registerTableHandlers(btnEdit, btnVisible, columnMapKey, dataColName, tableView, startCol);

        this.setCenter(vbox1);
        HBox hBox = new HBox(vbox1);
        hBox.setAlignment(Pos.TOP_CENTER);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(3, 3, 3, 3));

        HBox.setHgrow(vbox1, Priority.ALWAYS);
        this.setCenter(hBox);


    }

    private void registerHandlers() {


        menuBar.getMEdIT().setOnAction(evt -> {
            btnEdit.fire();
        });

        mTeachers.setOnAction(evt -> {
            gpeManager.f1_teachers();
            tempMessage.setVisible(true);
            tempMessage.setText("Teacher - Phase 1...");

            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();

        });
        mStudent.setOnAction(evt -> {
            gpeManager.f1_students();
            update();
            tempMessage.setVisible(true);
            tempMessage.setText("Students - Phase 1...");

            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();


        });
        mProposals.setOnAction(evt -> {
            gpeManager.f1_propProj();
            update();
            tempMessage.setVisible(true);
            tempMessage.setText("Proposals - Phase 1...");

            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();


        });
        mDeleteAll.setOnAction(evt -> {
            menuBar.mDeleteAll.fire();
            comboBox.setValue("All Data");

        });


        mExportDelete.setOnAction(evt -> {
            if (gpeManager.exportDelete()) {
                tempMessage.setText("Exported files removed...");
                tempMessage.setFill(Color.GREEN);
            } else {
                tempMessage.setText("Error removing export files...");
                tempMessage.setFill(Color.RED);
            }
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();
        });


        mInsert.setOnAction(evt -> {
            menuBar.mInsert.fire();

        });

        mInsertManual.setOnAction(evt ->{
            menuBar.getMInsert().fire();
        });

        mExport.setOnAction(evt -> {
            if (gpeManager.export()) {
                tempMessage.setText("Data Exported...");
                tempMessage.setFill(Color.GREEN);
            } else {
                tempMessage.setText("Error exporting data...");
                tempMessage.setFill(Color.RED);
            }
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();

        });

        mUndo.setOnAction(evt -> {
            gpeManager.undo();
        });
        mRedo.setOnAction(evt -> {
            gpeManager.redo();
        });
        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });


        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });



        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });




    }

    /**
     * Phase open close.
     *
     * @param labelClose             the label close
     * @param hboxChanges_Status     the hbox changes status
     * @param hboxPhase1_Status      the hbox phase 1 status
     * @param hboxTempMessage_Status the hbox temp message status
     */
    public void phaseOpenClose(String labelClose, Boolean hboxChanges_Status, Boolean hboxPhase1_Status, Boolean hboxTempMessage_Status) {
        this.labelClose = labelClose;
        hboxChanges.setVisible(hboxChanges_Status);
        hboxPhase1.setVisible(hboxPhase1_Status);
        hboxTempMessage.setVisible(hboxTempMessage_Status);

        update();
    }


    /**
     * Update tbl inner buttons.
     *
     * @param gpeManager           the gpe manager
     * @param tableView            the table view
     * @param columnMapKey         the column map key
     * @param mapStringTableColumn the map string table column
     * @param dataColName          the data col name
     */
    public void UpdateTblInnerButtons(GpeManager gpeManager, TableView tableView, String[] columnMapKey, TableColumn<Map, String> mapStringTableColumn, TableColumn<Map, String>[] dataColName) {
        this.gpeManager = gpeManager;
        this.tableView = tableView;
        this.columnMapKey = columnMapKey;
        this.mapStringTableColumn = mapStringTableColumn;
        this.dataColName = dataColName;

        update();
    }


        private void update() {
        mStudent.setDisable(false);
        mProposals.setDisable(false);
        mTeachers.setDisable(false);


        if (gpeManager.getState() == GpeState.STUDENTS) {
            mStudent.setText("Students");
            mStudent.setDisable(true);
        } else if (gpeManager.getState() == GpeState.TEACHERS) {
            mTeachers.setText("Teachers");
            mTeachers.setDisable(true);
        } else if ((gpeManager.getState() == GpeState.PROPOSALS)) {
            mProposals.setText("Proposals");
            mProposals.setDisable(true);
        } else if ((gpeManager.getState() == GpeState.CANDIDATURE)) {

            mProposals.setDisable(true);
        } else if ((gpeManager.getState() == GpeState.ASSIGNEDPROPOSALS)) {

            mProposals.setDisable(true);
        } else if ((gpeManager.getState() == GpeState.ADVISORS)) {

            mProposals.setDisable(true);
        } else if ((gpeManager.getState() == GpeState.CONSULT)) {

            mProposals.setDisable(true);
        }


    }




}