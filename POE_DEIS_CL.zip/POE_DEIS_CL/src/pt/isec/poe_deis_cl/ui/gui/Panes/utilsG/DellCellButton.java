package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;

import java.util.Map;
import java.util.Optional;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Dell cell button.
 */
public class DellCellButton extends TableCell<Record, Boolean> {


    /**
     * The Cell del button.
     */
    Button cellDelButton = new Button("✘");

    /**
     * The Combo box.
     */
    ComboBox comboBox;

    /**
     * The Temp message.
     */
    Text tempMessage;

    /**
     * The Buttondelete.
     */
    ButtonType buttondelete;

    /**
     * Gets m insert.
     *
     * @param s        the s
     * @param comboBox the combo box
     * @return the m insert
     */
    public Button getMInsert(TableColumn<Map, String> s, ComboBox comboBox) {

        this.comboBox = comboBox;

        return cellDelButton;

    }


    /**
     * Instantiates a new Dell cell button.
     *
     * @param s           the s
     * @param deleteAlert the delete alert
     * @param tempMessage the temp message
     * @param gpeManager  the gpe manager
     * @param name        the name
     * @param id          the id
     * @param comboBox    the combo box
     */
    public DellCellButton(TableColumn<Map, String> s, Alert deleteAlert, Text tempMessage, GpeManager gpeManager, int name, int id, ComboBox comboBox) {
        this.comboBox = comboBox;
        this.tempMessage = tempMessage;

        cellDelButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent t) {
                System.out.println((s.getTableView().getItems().get(DellCellButton.this.getIndex()).values().toArray()[name].toString()).equals("José Qualquer"));



                    deleteAlert.setTitle("Delete?");
                    deleteAlert.setContentText("Are you sure you want to delete " + s.getTableView().getItems().get(DellCellButton.this.getIndex()).values().toArray()[name] + " ?");
                    deleteAlert.setHeaderText("");
                    buttondelete = new ButtonType("Delete", ButtonBar.ButtonData.YES);

                    ButtonType buttonCancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                    deleteAlert.getButtonTypes().setAll(buttonCancel, buttondelete);
                    Optional<ButtonType> result = deleteAlert.showAndWait();
                    if (result.get() == buttondelete) {

                        buttondelete = new ButtonType("Delete", ButtonBar.ButtonData.YES);
                        if (gpeManager.delete(s.getTableView().getItems().get(DellCellButton.this.getIndex()).values().toArray()[id].toString())) {
                            tempMessage.setText("Item removed...");
                            tempMessage.setFill(Color.GREEN);
                            gpeManager.save();
                            getMInsert(s, comboBox);
                            tempMessage.setVisible(true);
                            PauseTransition pause = new PauseTransition(Duration.seconds(2));
                            pause.setOnFinished(e -> tempMessage.setText(null));
                            pause.play();

                        } else {
                            tempMessage.setText("Error removing ");
                            tempMessage.setFill(Color.RED);
                            gpeManager.save();
                            tempMessage.setVisible(true);
                            PauseTransition pause = new PauseTransition(Duration.seconds(2));
                            pause.setOnFinished(e -> tempMessage.setText(null));
                            pause.play();
                        }
                        comboBox.setValue("Empty");
                        comboBox.setValue("All Data");
                        tempMessage.setVisible(true);

                    }
                }

        });
    }

    //Display button if the row is not empty
    @Override
    protected void updateItem(Boolean t, boolean empty) {
        super.updateItem(t, empty);

        if (!empty) {

            setGraphic(cellDelButton);
        }else{

            setGraphic(null);
        }
        cellDelButton.setId("cellDelButton");
    }


}