package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;

import java.util.*;

import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import javafx.util.StringConverter;
import pt.isec.poe_deis_cl.ui.gui.Panes.utilsG.*;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Table p 1 students.
 */
public class TableP1Students extends BorderPane {

    /**
     * The Btn insert.
     */
    Button btnInsert,
    /**
     * The Btn cancel.
     */
    btnCancel;

    /**
     * The Btn new.
     */
    Button btnNew = new Button("New Record");
    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Delete alert.
     */
    Alert deleteAlert;
    /**
     * The Vbox.
     */
    VBox vbox,
    /**
     * The V insert manual.
     */
    vInsertManual;
    /**
     * The Hbox.
     */
    HBox hboxtableButtons,
    /**
     * The Hbox combo box.
     */
    hboxComboBox,
    /**
     * The H box tbtns.
     */
    HBoxTbtns,
    /**
     * The Hbox lables.
     */
    hboxLables,
    /**
     * The H box.
     */
    hBox;

    /**
     * The Stack pane.
     */
    StackPane stackPane;
    /**
     * The Text field.
     */
    TextField textField[];
    /**
     * The Text label.
     */
    Label textLabel[],
    /**
     * The Label.
     */
    label;
    /**
     * The Menu bar.
     */
    MenuBarConsult menuBar;
    /**
     * The Label close.
     */
    Label labelClose;
    /**
     * The Table buttons.
     */
    TableButtons tableButtons;
    /**
     * The Table top buttons.
     */
    TableTopButtons tableTopButtons;
    /**
     * The Cell del button.
     */
    DellCellButton cellDelButton;

    /**
     * The Bottom border.
     */
    BottomInfo bottomBorder;
    /**
     * The Combo box.
     */
    ComboBox comboBox;

    /**
     * The Phase.
     */
    String phase = "";

    /**
     * The Predef table width.
     */
    int predefTableWidth;
    /**
     * The Table view.
     */
    TableView tableView;

    /**
     * The Data col name.
     */
    TableColumn<Map, String> dataColName[];

    /**
     * The Col delete.
     */
    TableColumn col_delete;
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The Data s.
     */
    Map<Long, ArrayList<Object>> dataS;

    /**
     * The Column map key.
     */
    String[] ColumnMapKey = {"Id", "Name", "Mail", "Course", "Branch", "Grade", "Internship"};

    /**
     * Instantiates a new Table p 1 students.
     *
     * @param gpeManager       the gpe manager
     * @param predefTableWidth the predef table width
     */
    public TableP1Students(GpeManager gpeManager, int predefTableWidth) {
        this.gpeManager = gpeManager;
        dataS = (Map<Long, ArrayList<Object>>) gpeManager.getDataAll(GpeState.STUDENTS);

        if (gpeManager.getClosePhase() >=1)
            phase = "Closed";

        this.predefTableWidth = predefTableWidth;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {

        CSSManager.applyCSS(this, "tableViewP1Students.css");

        vbox = new VBox();
        tempMessage = new Text("");
        tempMessage.setStyle("-fx-font-weight: bold;");
        btnCancel = new Button("Cancel");
        btnInsert = new Button("Submit");
        vInsertManual = new VBox();

        label = new Label("Students -  PHASE I");
        label.setVisible(true);
        label.setId("StatusPhase");
        labelClose = new Label(phase);
        labelClose.setVisible(true);
        labelClose.setId("StatuslabelClose");

        comboBox = new ComboBox();
        comboBox.setValue("All Data");



        CreateTable(phase, ColumnMapKey);

        bottomBorder = new BottomInfo(gpeManager, tableView.getItems().size());


        menuBar = new MenuBarConsult(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, deleteAlert, comboBox, label, labelClose, bottomBorder);
        menuBar.setVisible(true);
        menuBar.setId("MenuBar");

        AnchorPane aPane = new AnchorPane();
        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
        tableButtons = new TableButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose, bottomBorder);
        this.setBottom(tableButtons);
        tableButtons.setVisible(true);
        VBox.setVgrow(tableButtons, Priority.ALWAYS);

        hboxComboBox = new HBox();
        hboxComboBox.getChildren().addAll(tableButtons);
        hboxComboBox.setAlignment(Pos.CENTER);


        hboxComboBox.setPadding(new Insets(0, 2, 2, 2));

        tableTopButtons = new TableTopButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose);
        tableTopButtons.setVisible(true);
        this.setRight(tableTopButtons);
        tableTopButtons.setId("tableTopButtons");
        HBox hb1 = new HBox(tableTopButtons);
        hb1.setAlignment(Pos.TOP_RIGHT);
        HBoxTbtns = new HBox();
        hboxLables = new HBox();

        HBox.setHgrow(hboxLables, Priority.ALWAYS);
        hboxLables.getChildren().addAll(label, labelClose);
        hboxLables.setAlignment(Pos.CENTER);
        hboxLables.setPadding(new Insets(0, 100, 0, 0));
        HBoxTbtns.getChildren().addAll(menuBar, hboxLables, hb1);
        HBoxTbtns.setAlignment(Pos.TOP_LEFT);
        HBoxTbtns.setPadding(new Insets(3, 0, 0, 0));
        this.setTop(HBoxTbtns);

        vbox.getChildren().addAll(HBoxTbtns, tableView,tempMessage, hboxComboBox);
        vbox.setPrefWidth(700);
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10);


        AnchorPane.setTopAnchor(btnCancel, 50.0);
        AnchorPane.setTopAnchor(btnInsert, 10.0);
        AnchorPane.setLeftAnchor(btnCancel, 600.0);
        AnchorPane.setLeftAnchor(btnInsert, 598.0);

        aPane.getChildren().setAll(btnCancel, btnInsert);
        vInsertManual.setMaxSize(600, 500);
        vInsertManual.setAlignment(Pos.CENTER);
        vInsertManual.setSpacing(5);

        vInsertManual.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        Label lbEdit = new Label("Insert" + gpeManager.getState().toString());
        lbEdit.setStyle("-fx-font: 16 arial;");
        lbEdit.setAlignment(Pos.CENTER);

        vInsertManual.getChildren().addAll(lbEdit);

        textField = new TextField[ColumnMapKey.length];
        textLabel = new Label[ColumnMapKey.length];

        for (int i = 0; i < ColumnMapKey.length; i++) {
            textField[i] = new TextField();
            textLabel[i] = new Label(ColumnMapKey[i]);
            textField[i].setMaxSize(250, 20);
            vInsertManual.getChildren().addAll(textLabel[i], textField[i]);
        }

        vInsertManual.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(1.5))));
        vInsertManual.getChildren().add(aPane);

        vInsertManual.setVisible(false);

        stackPane = new StackPane(vbox, vInsertManual);
        stackPane.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, CornerRadii.EMPTY, Insets.EMPTY)));
        this.setCenter(stackPane);


        hBox = new HBox(stackPane);
        hBox.setAlignment(Pos.TOP_CENTER);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(0, 0, 0, 0));

        this.setCenter(hBox);
        hBox.setHgrow(vbox, Priority.ALWAYS);
        hBox.setHgrow(tableView, Priority.ALWAYS);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setPrefWidth(predefTableWidth);

        /*
        if (dataS.size() == 0)
            tableView.setMaxHeight(90);
        else{
            tableView.setMaxHeight(dataS.size() * 30);
                }
        */

        setBottom(bottomBorder);

    }

    private void CreateTable(String phase,  String[] ColumnMapKey) {

        tableView = new TableView<>(generateDataInMap());
        tableView.setId("table-view");
        tableView.setEditable(true);


        dataColName = new TableColumn[ColumnMapKey.length];
        col_delete = new TableColumn<>("");
        col_delete.setId("col_delete");
        col_delete.setEditable(false);
        col_delete.setReorderable(false);
        col_delete.setSortable(false);
        col_delete.setPrefWidth(50);


        col_delete.setCellFactory(
                new Callback<TableColumn<Record, Boolean>, TableCell<Record, Boolean>>() {

                    @Override
                    public TableCell<Record, Boolean> call(TableColumn<Record, Boolean> p) {

                       return cellDelButton = new DellCellButton(dataColName[0], deleteAlert, tempMessage, gpeManager, 6, 3, comboBox);




                    }

                });

        col_delete.setCellValueFactory(new MapValueFactory(col_delete));
        tableView.getColumns().setAll(col_delete);

        if (!phase.equals("Closed")) {
            col_delete.setVisible(true);
        }else{
            col_delete.setVisible(false);
        }
        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i] = new TableColumn<>(ColumnMapKey[i]);
            dataColName[i].setId("col_" + i);

            dataColName[i].setCellValueFactory(new MapValueFactory(ColumnMapKey[i]));
            dataColName[i].setMinWidth(100);
            dataColName[i].setPrefWidth(150);
            dataColName[i].setEditable(false);
            dataColName[i].setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Map, String>>() {
                @Override
                public void handle(TableColumn.CellEditEvent<Map, String> mapStringCellEditEvent) {


                    EditsPhases.editP1Students(mapStringCellEditEvent.getNewValue(), mapStringCellEditEvent.getRowValue().values(), mapStringCellEditEvent.getTablePosition(), gpeManager, tempMessage);

                }
            });
        }
        dataColName[0].setPrefWidth(110);
        dataColName[1].setPrefWidth(150);
        dataColName[2].setPrefWidth(200);
        dataColName[3].setPrefWidth(80);
        dataColName[4].setPrefWidth(120);
        dataColName[5].setPrefWidth(80);
        dataColName[6].setPrefWidth(80);

        tableView.getSelectionModel().setCellSelectionEnabled(true);


        tableView.getColumns().addAll(dataColName);

        Callback<TableColumn<Map, String>, TableCell<Map, String>>
                cellFactoryForMap = (TableColumn<Map, String> p) ->
                new TextFieldTableCell(new StringConverter() {
                    @Override
                    public String toString(Object t) {
                        return t.toString();
                    }

                    @Override
                    public Object fromString(String string) {
                        return string;
                    }
                });

        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i].setCellFactory(cellFactoryForMap);
        }


    }

    private ObservableList<Map> generateDataInMap() {

        String[] ValuesName = new String[ColumnMapKey.length];
        int max = dataS.size();
        ObservableList<Map> allData = FXCollections.observableArrayList();


        int j = 0;
        for (Object key : dataS.keySet()) {
            Map<String, String> dataRow = new HashMap<>();
            ArrayList<Object> a = dataS.get(key);

            ValuesName[0] = String.valueOf(key);
            dataRow.put(ColumnMapKey[0], ValuesName[0]);

            for (int i = 0; i < ColumnMapKey.length - 1; i++) {
                ValuesName[i + 1] = a.get(i).toString();
                dataRow.put(ColumnMapKey[i + 1], ValuesName[i + 1]);
            }
            allData.add(dataRow);
            j++;
        }


        return allData;
    }


    private void registerHandlers() {

        btnCancel.setOnAction(evt -> {
            vbox.setVisible(true);
            vInsertManual.setVisible(false);
            UpdateTableView();
        });


        menuBar.getMInsert().setOnAction(evt -> {
            vInsertManual.setVisible(true);
            vbox.setVisible(false);
            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());


        });




        btnInsert.setOnAction(evt -> {
            gpeManager.saveUndo();


            if (
                    gpeManager.manualInsertStudent(textField[0].getText(), textField[1].getText(),
                            textField[2].getText(), textField[3].getText(), textField[4].getText(), textField[5].getText(),
                            textField[6].getText()) == 0)
                tempMessage.setText("Student " + textField[1].getText() + " added!");
            else
                tempMessage.setText("Error adding student!");
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();

            tableButtons.UpdateTblInnerButtons(gpeManager, tableView,  ColumnMapKey,  dataColName[0], dataColName);
            setTop(vbox);
            UpdateTableView();
            btnCancel.fire();


            gpeManager.redo();

        });


        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });

        menuBar.addPropertyChangeListener(evt -> {
            update();
            UpdateTableView();

        });

        gpeManager.addTableUpdateListener(evt -> {
            UpdateTableView();

        });

        tableButtons.addTableUpdateChangeListener(evt -> {
            UpdateTableView();
        });

        gpeManager.addUndoRedoListener(evt -> {

            dataS.putAll((Map<Long, ArrayList<Object>>) gpeManager.getDataAll(GpeState.STUDENTS));
            update();
            UpdateTableView();
        });

        gpeManager.addcloseUpdateListener(evt -> {
            update();
            phase = "Closed";
            labelClose.setText("Closed");
            configAdapter();
        });
    }


    private void UpdateTableView() {

        tableView.setItems(generateDataInMap());
        vbox.setPrefWidth(predefTableWidth);
        tableView.setMaxWidth(predefTableWidth);
        tableView.setVisible(true);
        vbox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setAlignment(Pos.TOP_CENTER);

        vInsertManual.setVisible(false);
        stackPane = new StackPane(vbox, vInsertManual);
        this.setCenter(stackPane);



    }

    private void configAdapter() {

        if (gpeManager.getClosePhase() >= 1) {


            phase = "Closed";
            labelClose.setText("Closed");
            menuBar.phaseOpenClose("", false, true, false, true, false, true);
            tableTopButtons.phaseOpenClose("", false, true, false, false);
            tableButtons.phaseOpenClose("", false, true, true);
            col_delete.setVisible(false);


        } else {

            phase = "";
            labelClose.setText("");
            tableButtons.phaseOpenClose("", true, true, true);
            col_delete.setVisible(true);
            if (!gpeManager.checkOneEmptyP1()) {

                menuBar.phaseOpenClose("", true, true, false, false, true, false);
                tableTopButtons.phaseOpenClose("", false, false, true, true);
                UpdateTableView();
            } else {


                menuBar.phaseOpenClose("", true, true, false, false, false, false);
                tableTopButtons.phaseOpenClose("", false, false, false, true);
            }
        }
        bottomBorder.BottomInfoUpdate(gpeManager, dataS.size());
    }

    private void update() {


     if (gpeManager.getMenuOpt() == MenuOpt.IN_STATE && gpeManager.getState() == GpeState.STUDENTS) {

            configAdapter();

            this.setVisible(true);
            return;
        }
        this.setVisible(false);
    }

}
