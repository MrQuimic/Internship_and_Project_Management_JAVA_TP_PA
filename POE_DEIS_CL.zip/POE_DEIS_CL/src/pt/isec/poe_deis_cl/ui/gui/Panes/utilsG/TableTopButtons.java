package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Map;
import java.util.Objects;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Table pane.
 */
public class TableTopButtons extends BorderPane {


    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The Btn menu.
     */
    Button btnMenu,
    /**
     * The Btn insert.
     */
    btnInsert,
    /**
     * The Btn cancel.
     */
    btnCancel,
    /**
     * The Btn visible.
     */
    btnVisible,
    /**
     * The Btn edit.
     */
    btnEdit,
    /**
     * The Btn back phase.
     */
    btnBackPhase,
    /**
     * The Btn next phase.
     */
    btnNextPhase;
    /**
     * The Cell del button.
     */
    DellCellButton cellDelButton;

    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Delete alert.
     */
    Alert deleteAlert;
    /**
     * The Vbox.
     */
    VBox vbox,
    /**
     * The Vbox 1.
     */
    vbox1,
    /**
     * The V insert manual.
     */
    vInsertManual;
    /**
     * The Text field.
     */
    TextField textField[];
    /**
     * The Text label.
     */
    Label textLabel[];
    /**
     * The Labeltext.
     */
    String labeltext,
    /**
     * The Label close.
     */
    labelClose = "";

    /**
     * The Label handler.
     */
    Label labelHandler;

    /**
     * The Root.
     */
    BorderPane root;
    /**
     * The Pcs.
     */
    PropertyChangeSupport pcs;
    /**
     * The Conf alert.
     */
    Alert confAlert;

    /**
     * The Start col.
     */
    int startCol;
    /**
     * The Table view.
     */
    TableView tableView;
    /**
     * The Column map key.
     */
    String[] columnMapKey;
    /**
     * The Data col name.
     */
    TableColumn<Map, String>[] dataColName;
    /**
     * The Map string table column.
     */
    TableColumn<Map, String> mapStringTableColumn;
    /**
     * The M insert manual.
     */
    Button mInsertManual,
    /**
     * The M delete.
     */
    mDelete,
    /**
     * The M undo.
     */
    mUndo,
    /**
     * The M redo.
     */
    mRedo,
    /**
     * The M insert.
     */
    mInsert,
    /**
     * The M delete all.
     */
    mDeleteAll;
    /**
     * The M export.
     */
    Button mExport,
    /**
     * The M export delete.
     */
    mExportDelete,
    /**
     * The M save.
     */
    mSave;
    /**
     * The M student.
     */
    Button mStudent,
    /**
     * The M teachers.
     */
    mTeachers,
    /**
     * The M proposals.
     */
    mProposals;
    /**
     * The M next f.
     */
    Button mNextF,
    /**
     * The M close f.
     */
    mCloseF,
    /**
     * The M back f.
     */
    mBackF;

    /**
     * The Combo box.
     */
    ComboBox comboBox;
    /**
     * The Menu bar.
     */
    MenuBarConsult menuBar;

    /**
     * The Table update.
     */
    PropertyChangeSupport tableUpdate;
    /**
     * The C update.
     */
    PropertyChangeSupport cUpdate;

    /**
     * Instantiates a new Table top buttons.
     *
     * @param gpeManager           the gpe manager
     * @param tempMessage          the temp message
     * @param tableView            the table view
     * @param columnMapKey         the column map key
     * @param mapStringTableColumn the map string table column
     * @param dataColName          the data col name
     * @param menuBar              the menu bar
     * @param deleteAlert          the delete alert
     * @param btnCancel            the btn cancel
     * @param vInsertManual        the v insert manual
     * @param comboBox             the combo box
     * @param label                the label
     * @param labelClose           the label close
     */
    public TableTopButtons(GpeManager gpeManager, Text tempMessage, TableView tableView, String[] columnMapKey, TableColumn<Map, String> mapStringTableColumn, TableColumn<Map, String>[] dataColName, MenuBarConsult menuBar, Alert deleteAlert, Button btnCancel, VBox vInsertManual, ComboBox comboBox, Label label, Label labelClose) {
        this.gpeManager = gpeManager;
        this.tempMessage = tempMessage;
        this.tableView = tableView;
        this.columnMapKey = columnMapKey;
        this.mapStringTableColumn = mapStringTableColumn;
        this.dataColName = dataColName;
        this.menuBar = menuBar;
        this.btnCancel = btnCancel;
        this.comboBox = comboBox;
        this.vInsertManual = vInsertManual;
        this.labeltext = label.getText();
        this.labelHandler = label;
        this.labelClose = labelClose.getText();
        tableUpdate = new PropertyChangeSupport(this);
        cUpdate = new PropertyChangeSupport(this);
        pcs = new PropertyChangeSupport(this);
        createViews();
        registerHandlers();
        update();

    }

    /**
     * Add property change listener.
     *
     * @param listener the listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    /**
     * Add table update change listener.
     *
     * @param listener the listener
     */
    public void addTableUpdateChangeListener(PropertyChangeListener listener) {
        tableUpdate.addPropertyChangeListener(listener);
    }


    private void createViews() {
        CSSManager.applyCSS(this, "styles.css");

        btnEdit = new Button("Edit");
        btnEdit.setId("button-39");
        mSave = new Button("Save");
        mSave.setId("mSave");
        mSave.setMinWidth(55);

        mNextF = new Button(" → ");
        mNextF.setId("BackNextArrow");
        mCloseF = new Button("\uD83D\uDD12 Close");
        mCloseF.setId("mCloseF");
        mBackF = new Button(" ← ");
        mBackF.setId("BackNextArrow");


        btnMenu = new Button("Main");
        btnMenu.setId("buttonMainMenu");

        btnEdit = new Button("Edit");
        btnEdit.setId("buttonNoEdit");
        btnEdit.setMinWidth(55);



        tempMessage = new Text("");


        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);


        textField = new TextField[7];
        textLabel = new Label[7];
        tempMessage.setStyle("-fx-font-weight: bold;");

        vbox1 = new VBox();


        vbox1.setSpacing(5);
        vbox1.setPadding(new Insets(0, 0, 0, 0));
        HBox hbox0 = new HBox();
        hbox0.getChildren().add(tempMessage);
        hbox0.setAlignment(Pos.CENTER);

        HBox hbox1 = new HBox();
        hbox1.getChildren().addAll(btnMenu);
        hbox1.setSpacing(5);

        HBox hbox2 = new HBox();
        hbox2.getChildren().addAll(mCloseF, hbox1, mSave, mBackF, mNextF);
        mBackF.setVisible(false);
        mNextF.setVisible(false);

        hbox2.setSpacing(7);


        vbox1.getChildren().addAll( hbox2);

        vbox1.setAlignment(Pos.CENTER);
        vbox1.setSpacing(7);

        this.setCenter(vbox1);
        HBox hBox = new HBox(vbox1);
        hBox.setAlignment(Pos.TOP_CENTER);
        hBox.setSpacing(7);
        hBox.setPadding(new Insets(3, 0, 3, 0));

        HBox.setHgrow(vbox1, Priority.ALWAYS);
        this.setCenter(hBox);


    }

    /**
     * Gets closed.
     *
     * @return the closed
     */
    public String gettClosed() {
        return this.labelClose;
    }
    private void registerHandlers() {


        mSave.setOnAction(evt -> {
            gpeManager.save();
        });


        btnMenu.setOnAction(evt -> {
            gpeManager.setMenuOpt(MenuOpt.STARTMENU);
        });

        mCloseF.setOnAction(evt -> {
            comboBox.setValue("All Data");
            menuBar.mCloseF.fire();
            cUpdate.firePropertyChange(null, null, null);
            if(gpeManager.getClosePhase() ==4) {
                gpeManager.save();
            }
        });

        mNextF.setOnAction(evt -> {
            comboBox.setValue("All Data");
            gpeManager.advancePhase();
        });
        mBackF.setOnAction(evt -> {
            comboBox.setValue("All Data");
            gpeManager.previousPhase();
        });



    }

    /**
     * Add close update change listener.
     *
     * @param listener the listener
     */
    public void addCloseUpdateChangeListener(PropertyChangeListener listener) {
        cUpdate.addPropertyChangeListener(listener);
    }

    /**
     * Phase open close.
     *
     * @param labelClose         the label close
     * @param hboxmBackF_Status  the hboxm back f status
     * @param hboxmNextF_Status  the hboxm next f status
     * @param hboxmCloseF_Status the hboxm close f status
     * @param hboxmSave_Status   the hboxm save status
     */
    public void phaseOpenClose(String labelClose, Boolean hboxmBackF_Status, Boolean hboxmNextF_Status, Boolean hboxmCloseF_Status, Boolean hboxmSave_Status) {
        this.labelClose = labelClose;
        mBackF.setVisible(hboxmBackF_Status);
        mNextF.setVisible(hboxmNextF_Status);
        mCloseF.setVisible(hboxmCloseF_Status);
        mSave.setVisible(hboxmSave_Status);


        update();
    }

    private void update() {



    }

}

