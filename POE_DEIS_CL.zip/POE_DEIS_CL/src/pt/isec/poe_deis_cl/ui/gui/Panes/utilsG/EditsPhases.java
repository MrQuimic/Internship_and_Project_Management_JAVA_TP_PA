package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import pt.isec.poe_deis_cl.model.GpeManager;

import java.util.*;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Edits phases.
 */
public class EditsPhases {


    /**
     * Edit p 1 students.
     *
     * @param changedVal  the changed val
     * @param values      the values
     * @param tableColumn the table column
     * @param gpeManager  the gpe manager
     * @param tempMessage the temp message
     */
    public static void editP1Students(String changedVal, Collection values, TablePosition<Map, String> tableColumn, GpeManager gpeManager, Text tempMessage) {


        String d0 = values.toArray()[4].toString(); //Course
        String d1 = values.toArray()[2].toString(); //GRADE
        String d2 = values.toArray()[0].toString(); //NR STUDENT
        String d3 = values.toArray()[3].toString(); //MAIL
        String d4 = values.toArray()[5].toString(); //INTERSHIP
        String d5 = values.toArray()[1].toString(); //BRANCH
        String d6 = values.toArray()[6].toString(); //NAME

        if (tableColumn.getColumn() == 4) //course
            d0 = changedVal;
        else if (tableColumn.getColumn() == 6) {
            d1 = changedVal;
        } else if (tableColumn.getColumn() == 0) {
            d2 = changedVal;
        } else if (tableColumn.getColumn() == 3) {
            d3 = changedVal;
        } else if (tableColumn.getColumn() == 5) {
            d4 = changedVal;
        } else if (tableColumn.getColumn() == 1) {
            d5 = changedVal;
        } else if (tableColumn.getColumn() == 2) {
            d6 = changedVal;
        }
        System.out.println(tableColumn.getColumn());

        System.out.println(values.toString());
/*
        System.out.println(d0);
        System.out.println(d1);
        System.out.println(d2);
        System.out.println(d3);
        System.out.println(d4);
        System.out.println(d5);
        System.out.println(d6);
*/

        if (gpeManager.editStudents(Long.parseLong(d3),
                d6, d2, d0, d5, Double.parseDouble(d1), Boolean.parseBoolean(d4))) {
            tempMessage.setText("Student edited...");
            tempMessage.setFill(Color.GREEN);

            gpeManager.save();

        } else {
            tempMessage.setText("Error editing student...");
            tempMessage.setFill(Color.RED);
        }

    }

    /**
     * Edit p 1 teachers.
     *
     * @param changedVal  the changed val
     * @param values      the values
     * @param tableColumn the table column
     * @param gpeManager  the gpe manager
     * @param tempMessage the temp message
     */
    public static void editP1Teachers(String changedVal, Collection values, TablePosition<Map, String> tableColumn, GpeManager gpeManager, Text tempMessage) {


        System.out.println(tableColumn.getColumn());

        System.out.println(changedVal);

        String d = values.toString();

        System.out.println(d);


        String d0 = values.toArray()[0].toString(); //Name
        String d1 = values.toArray()[1].toString(); //Mail


        if (tableColumn.getColumn() == 2)
            d0 = changedVal;
        else if (tableColumn.getColumn() == 1) {
            d1 = changedVal;
        }

        System.out.println("name " + d0);
        System.out.println("mail " + d1);


        if (gpeManager.editTeachers(d1,
                d0)) {
            tempMessage.setText("Teacher edited...");
            tempMessage.setFill(Color.GREEN);

            gpeManager.save();

        } else {
            tempMessage.setText("Error editing Teacher...");
            tempMessage.setFill(Color.RED);
        }


    }

    /**
     * Edit p 1 proposals.
     *
     * @param changedVal  the changed val
     * @param values      the values
     * @param tableColumn the table column
     * @param gpeManager  the gpe manager
     * @param tempMessage the temp message
     */
    public static void editP1Proposals(String changedVal, Collection values, TablePosition<Map, String> tableColumn, GpeManager gpeManager, Text tempMessage) {

        System.out.println(tableColumn.getColumn());

        System.out.println(changedVal);

        String d = values.toString();

        System.out.println(d);


        String d0 = values.toArray()[1].toString(); //NUMBER
        String d1 = values.toArray()[0].toString(); //NAME


        if (tableColumn.getColumn() == 0)
            d0 = changedVal;
        else if (tableColumn.getColumn() == 1) {
            d1 = changedVal;
        }

        System.out.println(d0);
        System.out.println(d1);


        if (gpeManager.editTeachers(d0,
                d1)) {
            tempMessage.setText("Proposal edited...");
            tempMessage.setFill(Color.GREEN);

            gpeManager.save();

        } else {
            tempMessage.setText("Error Proposal Teacher...");
            tempMessage.setFill(Color.RED);
        }
    }

    /**
     * Edit p 2 candidatures.
     *
     * @param changedVal  the changed val
     * @param values      the values
     * @param tableColumn the table column
     * @param gpeManager  the gpe manager
     * @param tempMessage the temp message
     */
    public static void editP2Candidatures(String changedVal, Collection values, TablePosition<Map, String> tableColumn, GpeManager gpeManager, Text tempMessage) {

        String d0 = values.toArray()[1].toString(); //number
        String d1 = values.toArray()[0].toString(); //proposal




        if (tableColumn.getColumn() == 1)
            d0 = changedVal;
        else if (tableColumn.getColumn() == 0) {
            d1 = changedVal;
        }

        Scanner sc = new Scanner(changedVal);
        HashSet<String> Cand = new HashSet<>();
        sc.useDelimiter("[,\n]");
        while(sc.hasNext() ){
            String info = sc.next();
            Cand.add(info);
        }

        if (gpeManager.editCandidatures(Long.parseLong(d0),
                Cand)) {
            tempMessage.setText("Proposal edited...");
            tempMessage.setFill(Color.GREEN);
            gpeManager.save();

        } else {
            tempMessage.setText("Error Proposal Teacher...");
            tempMessage.setFill(Color.RED);
        }


    }


    /**
     * Edit p 4 advisors.
     *
     * @param changedVal  the changed val
     * @param values      the values
     * @param tableColumn the table column
     * @param gpeManager  the gpe manager
     * @param tempMessage the temp message
     */
    public static void editP4Advisors(String changedVal, Collection values, TablePosition<Map, String> tableColumn, GpeManager gpeManager, Text tempMessage) {


        System.out.println(tableColumn.getColumn());

        System.out.println(changedVal);

        String d = values.toString();

        System.out.println(d);


        String d0 = values.toArray()[1].toString(); //NUMBER
        String d1 = values.toArray()[0].toString(); //NAME


        if (tableColumn.getColumn() == 0)
            d0 = changedVal;
        else if (tableColumn.getColumn() == 1) {
            d1 = changedVal;
        }

        System.out.println(d0);
        System.out.println(d1);

        String textEditAdvisors = gpeManager.editAdvisors(d0, d1);

        if (textEditAdvisors.equals("Advisor was attributed with success")) {
            tempMessage.setText(textEditAdvisors);
            tempMessage.setFill(Color.GREEN);

            gpeManager.save();

        } else {
            tempMessage.setText(textEditAdvisors);
            tempMessage.setFill(Color.RED);
        }

    }


}





