package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Callback;
import javafx.util.Duration;
import javafx.util.StringConverter;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;
import pt.isec.poe_deis_cl.ui.gui.Panes.utilsG.*;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;

import java.util.*;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */


/**
 * The type Table pane.
 */
public class TableP4Advisors extends BorderPane {

    /**
     * The Btn insert.
     */
    Button btnInsert,
    /**
     * The Button advisor stat.
     */
    buttonAdvisorStat,
    /**
     * The Btn cancel.
     */
    btnCancel;

    private Label lbConsult;
    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Delete alert.
     */
    Alert deleteAlert;

    /**
     * The Vbox.
     */
    VBox vbox,
    /**
     * The Vbox table view.
     */
    vboxTableView,
    /**
     * The Vbox label view.
     */
    vboxLabelView,
    /**
     * The Vbox advisorstat.
     */
    vboxAdvisorstat,
    /**
     * The V insert manual.
     */
    vInsertManual;

    /**
     * The Stack pane chart.
     */
    StackPane stackPaneChart;
    /**
     * The Hbox.
     */
    HBox hboxtableButtons,
    /**
     * The Hbox combo box.
     */
    hboxComboBox,
    /**
     * The H box tbtns.
     */
    HBoxTbtns,
    /**
     * The Hbox lables.
     */
    hboxLables,
    /**
     * The H box advisors.
     */
    hBoxAdvisors;
    /**
     * The Text field.
     */
    TextField textField[],
    /**
     * The Text advidor stat.
     */
    textAdvidorStat;
    /**
     * The Text label.
     */
    Label textLabel[],
    /**
     * The Label.
     */
    label,
    /**
     * The Lb consult 2.
     */
    lbConsult2,
    /**
     * The Text label advidor stat.
     */
    textLabelAdvidorStat;
    /**
     * The Menu bar.
     */
    MenuBarConsult menuBar;
    /**
     * The Label close.
     */
    Label labelClose;
    /**
     * The Table buttons.
     */
    TableButtons tableButtons;
    /**
     * The Table top buttons.
     */
    TableTopButtons tableTopButtons;
    /**
     * The Cell del button.
     */
    DellCellButton cellDelButton;

    /**
     * The Bottom border.
     */
    BottomInfo bottomBorder;
    /**
     * The Combo box.
     */
    ComboBox comboBox;

    /**
     * The Phase.
     */
    String phase = "";

    /**
     * The Predef table width.
     */
    int predefTableWidth;
    /**
     * The Table view.
     */
    TableView tableView;

    /**
     * The Data col name.
     */
    TableColumn<Map, String> dataColName[];

    /**
     * The Col delete.
     */
    TableColumn col_delete;
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The Stack pane.
     */
    StackPane stackPane;

    /**
     * The Data a.
     */
    Map<String, ArrayList<Object>> dataA;

    /**
     * The Column map key.
     */
    String[] ColumnMapKey = {"Proposal", "Advisor"};

    /**
     * The Choices.
     */
    String choices[] = {"All Data", "Proposal List", "Proposals With Advisors", "Assigned Without Advisors", "Without Assignment", "Advisor Stats"};


    /**
     * Instantiates a new Table pane.
     *
     * @param gpeManager       the gpe manager
     * @param predefTableWidth the predef table width
     */
    public TableP4Advisors(GpeManager gpeManager, int predefTableWidth) {
        this.gpeManager = gpeManager;
        dataA = new HashMap<>();

        comboBox = new ComboBox(FXCollections.observableArrayList(choices));

        if (gpeManager.getClosePhase() >= 4)
            phase = "Closed";

        this.predefTableWidth = predefTableWidth;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {

        CSSManager.applyCSS(this, "TableP4Advisors.css");

        vbox = new VBox();
        vInsertManual = new VBox();
        tempMessage = new Text("");
        tempMessage.setStyle("-fx-font-weight: bold;");
        btnCancel = new Button("Cancel");
        btnInsert = new Button("Submit");


        Label label = new Label("Advisors -  PHASE IV");
        label.setVisible(true);
        label.setId("StatusPhase");
        labelClose = new Label(phase);
        labelClose.setVisible(true);
        labelClose.setId("StatuslabelClose");

        comboBox = new ComboBox(FXCollections.observableArrayList(choices));
        comboBox.setValue("All Data");

        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
        CreateTable(phase, ColumnMapKey);

        bottomBorder = new BottomInfo(gpeManager, tableView.getItems().size());

        menuBar = new MenuBarConsult(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, deleteAlert, comboBox, label, labelClose, bottomBorder);
        menuBar.setVisible(true);
        menuBar.setId("MenuBar");


        AnchorPane aPane = new AnchorPane();
        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
        tableButtons = new TableButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose, bottomBorder);
        this.setBottom(tableButtons);
        tableButtons.setVisible(true);
        VBox.setVgrow(tableButtons, Priority.ALWAYS);

        VBox vobxTempMessage = new VBox();

        vobxTempMessage.getChildren().addAll(tempMessage,tableButtons);
        vobxTempMessage.setAlignment(Pos.CENTER);
        hboxtableButtons = new HBox();
        hboxtableButtons.getChildren().addAll(vobxTempMessage);
        hboxtableButtons.setAlignment(Pos.CENTER);
        hboxtableButtons.setPadding(new Insets(0, 2, 2, 2));

        hboxComboBox = new HBox();
        hboxComboBox.getChildren().addAll(comboBox);
        hboxComboBox.setAlignment(Pos.CENTER);

        tableTopButtons = new TableTopButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose);
        tableTopButtons.setVisible(true);
        this.setRight(tableTopButtons);
        tableTopButtons.setId("tableTopButtons");
        HBox hb1 = new HBox(tableTopButtons);
        hb1.setAlignment(Pos.TOP_RIGHT);
        HBoxTbtns = new HBox();
        hboxLables = new HBox();

        HBox.setHgrow(hboxLables, Priority.ALWAYS);
        hboxLables.getChildren().addAll(label, labelClose);
        hboxLables.setAlignment(Pos.CENTER);
        hboxLables.setPadding(new Insets(0, 50, 0, 0));
        HBoxTbtns.getChildren().addAll(menuBar, hboxLables, hb1);
        HBoxTbtns.setAlignment(Pos.TOP_LEFT);
        HBoxTbtns.setPadding(new Insets(3, 0, 0, 0));
        this.setTop(HBoxTbtns);
        lbConsult = new Label();
        lbConsult.setPrefSize(410,410);
        vboxTableView = new VBox();
        vboxTableView.getChildren().addAll(tableView);

        lbConsult.setAlignment(Pos.BASELINE_CENTER);


        textLabelAdvidorStat = new Label("Insert Advisor Email:");
        textLabelAdvidorStat.setPrefWidth(150);
        textLabelAdvidorStat.setStyle("-fx-underline: true;-fx-font-weight: 700;-fx-padding: 5");
        textAdvidorStat =new TextField("all");
        textAdvidorStat.setPrefWidth(225);
        textAdvidorStat.setMaxWidth(225);
        textAdvidorStat.setPadding(new Insets(5, 5, 5, 10));
        buttonAdvisorStat = new Button("Ok");
        buttonAdvisorStat.setId("buttonAdvisorStat");

        lbConsult2 = new Label(" ");
        lbConsult2.setText(gpeManager.advisor_teacherSpecifStatus(textAdvidorStat.getText()));

        lbConsult2.setPadding(new Insets(10, 0, 0, 0));

        vboxAdvisorstat = new VBox();
        vboxAdvisorstat.getChildren().addAll(textLabelAdvidorStat, textAdvidorStat,buttonAdvisorStat, lbConsult2);

        vboxLabelView = new VBox();
        hBoxAdvisors = new HBox();
        hBoxAdvisors.getChildren().addAll(lbConsult, vboxAdvisorstat);

        vboxLabelView.getChildren().addAll(hBoxAdvisors);
        vboxAdvisorstat.setPadding(new Insets(110, 0, 0, 50));
        hBoxAdvisors.setVisible(false);
        stackPaneChart = new StackPane(

                vboxLabelView,
                vboxTableView
        );
        hBoxAdvisors.setVisible(false);

        stackPaneChart.setStyle("-fx-background-radius: 10px 10px 10px 10px;-fx-background-color:#ecedee;");
        vbox.getChildren().addAll(HBoxTbtns, hboxComboBox, stackPaneChart, hboxtableButtons);
        vbox.setPrefWidth(700);
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10);



        AnchorPane.setTopAnchor(btnCancel, 50.0);
        AnchorPane.setTopAnchor(btnInsert, 10.0);
        AnchorPane.setLeftAnchor(btnCancel, 600.0);
        AnchorPane.setLeftAnchor(btnInsert, 598.0);



        aPane.getChildren().addAll(btnCancel, btnInsert);
        vInsertManual.setMaxSize(600, 400);
        vInsertManual.setAlignment(Pos.CENTER);
        vInsertManual.setSpacing(5);

        vInsertManual.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        Label lbEdit = new Label("Insert proposal");
        lbEdit.setStyle("-fx-font: 16 arial;");
        lbEdit.setAlignment(Pos.CENTER);

        vInsertManual.getChildren().addAll(lbEdit);


        textField = new TextField[ColumnMapKey.length];
        textLabel = new Label[ColumnMapKey.length];

        String[] mInsertLabel = {"Proposal id", "Advisor"};

        for (int i = 0; i < mInsertLabel.length; i++) {
            textField[i] = new TextField();
            textLabel[i] = new Label(mInsertLabel[i]);
            textLabel[i].setAlignment(Pos.CENTER);
            textField[i].setMaxSize(250, 20);
            vInsertManual.getChildren().addAll(textLabel[i], textField[i]);
        }

        vInsertManual.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(1.5))));
        vInsertManual.getChildren().add(aPane);

        vInsertManual.setVisible(false);

        StackPane stackPane = new StackPane(vbox, vInsertManual);
        stackPane.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, CornerRadii.EMPTY, Insets.EMPTY)));
        this.setCenter(stackPane);


        HBox hBox = new HBox(stackPane);
        hBox.setAlignment(Pos.TOP_CENTER);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(0, 0, 0, 0));

        this.setCenter(hBox);
        hBox.setHgrow(vbox, Priority.ALWAYS);
        hBox.setHgrow(tableView, Priority.ALWAYS);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setPrefWidth(predefTableWidth);


        setBottom(bottomBorder);
    }

    private void CreateTable(String phase,  String[] ColumnMapKey) {


        tableView = new TableView<>(generateDataInMap());
        tableView.setId("table-view");

        tableView.setEditable(true);

        dataColName = new TableColumn[ColumnMapKey.length];
        col_delete = new TableColumn<>("");
        col_delete.setId("col_delete");
        col_delete.setEditable(false);
        col_delete.setReorderable(false);
        col_delete.setSortable(false);

            col_delete.setCellFactory(
                    new Callback<TableColumn<Record, Boolean>, TableCell<Record, Boolean>>() {
                        @Override
                        public TableCell<Record, Boolean> call(TableColumn<Record, Boolean> p) {

                            return cellDelButton = new DellCellButton(dataColName[0], deleteAlert, tempMessage, gpeManager, 0, 1, comboBox);

                        }
                    });

        col_delete.setCellValueFactory(new MapValueFactory(col_delete));
        tableView.getColumns().addAll(col_delete);

        if (!phase.equals("Closed")) {
            col_delete.setVisible(true);
        }



        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i] = new TableColumn<>(ColumnMapKey[i]);
            dataColName[i].setId("col_" + i);

            dataColName[i].setCellValueFactory(new MapValueFactory(ColumnMapKey[i]));
            dataColName[i].setMinWidth(130);
            dataColName[i].setPrefWidth(140);
            dataColName[i].setEditable(false);
            dataColName[i].setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Map, String>>() {
                @Override
                public void handle(TableColumn.CellEditEvent<Map, String> mapStringCellEditEvent) {

                    EditsPhases.editP4Advisors(mapStringCellEditEvent.getNewValue(), mapStringCellEditEvent.getRowValue().values(), mapStringCellEditEvent.getTablePosition(), gpeManager, tempMessage);
                }
            });

        }


        tableView.getSelectionModel().setCellSelectionEnabled(true);

        tableView.getColumns().addAll(dataColName);


        Callback<TableColumn<Map, String>, TableCell<Map, String>>
                cellFactoryForMap = (TableColumn<Map, String> p) ->
                new TextFieldTableCell(new StringConverter() {
                    @Override
                    public String toString(Object t) {
                        if(t == null )
                            return "AAAAAAAA";
                        return t.toString();
                    }

                    @Override
                    public Object fromString(String string) {
                        return string;
                    }
                });

        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i].setCellFactory(cellFactoryForMap);
        }
    }

    private ObservableList<Map> generateDataInMap() {

        String[] ValuesName = new String[ColumnMapKey.length];


        int max = dataA.size();

        ObservableList<Map> allData = FXCollections.observableArrayList();

        ArrayList<Object> a;
        int j = 0;
        for (Object key : dataA.keySet()) {
            Map<Object, Object> dataRow = new HashMap<>();
            if (ColumnMapKey.length > 2) {
                ArrayList<Object> aa = dataA.get(key);
                a = (ArrayList<Object>) aa.get(0);
            }else {
                a = dataA.get(key);
            }
            ValuesName[0] = String.valueOf(key);
            dataRow.put(ColumnMapKey[0], ValuesName[0]);
            for (int i = 0; i < ColumnMapKey.length - 1; i++) {
                ValuesName[i + 1] = a.get(i).toString();
                dataRow.put(ColumnMapKey[i + 1], ValuesName[i + 1]);
            }
            allData.add(dataRow);
            j++;
        }


        return allData;
    }


    private void registerHandlers() {


        btnCancel.setOnAction(evt -> {
            this.setCenter(vbox);

            vInsertManual.setVisible(false);
        });

        menuBar.getMInsert().setOnAction(evt -> {
            this.setCenter(vInsertManual);
            vInsertManual.setVisible(true);
            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
        });

        btnInsert.setOnAction(evt -> {
            gpeManager.saveUndo();

            if (gpeManager.manualInsert(textField[0].getText(), textField[1].getText()) == 0)
                tempMessage.setText("Advisor " + textField[1].getText() + " added!");
            else
                tempMessage.setText("Error adding teacher!");


            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();

            btnCancel.fire();
        });

        buttonAdvisorStat.setOnAction(evt -> {

            lbConsult2.setText(gpeManager.advisor_teacherSpecifStatus(textAdvidorStat.getText()));
            vboxAdvisorstat.getChildren().setAll(textLabelAdvidorStat, textAdvidorStat,buttonAdvisorStat, lbConsult2);
            gpeManager.saveRedo();

        });


        comboBox.setOnAction(evt -> {
            dataA.clear();

            switch (comboBox.getValue().toString()) {
                case "All Data" -> {

                    dataA.putAll(gpeManager.consultMode(1));
                    comboBox.setValue("Proposal List");
                }
                case "Proposal List" -> {

                    dataA.putAll(gpeManager.consultMode(1));
                    comboBox.setValue("Proposal List");
                }
                case "Proposals With Advisors" -> {

                    dataA.putAll(gpeManager.consultMode(2));
                    comboBox.setValue("Proposals With Advisors");
                }
                case "Assigned Without Advisors" -> {

                    dataA.putAll(gpeManager.consultMode(3));
                    comboBox.setValue("Assigned Without Advisors");
                }
                case "Without Assignment" -> {

                    dataA.putAll(gpeManager.consultMode(4));
                    comboBox.setValue("Without Assignment");
                }
                case "Advisor Stats" -> {

                    comboBox.setValue("Advisor Stats");
                }
            }

            if (comboBox.getValue() == "Proposal List") {
                ColumnMapKey = new String[]{"Proposal", "Advisor"};
            }
            else {
                ColumnMapKey = new String[]{"Id", "Name", "Mail", "Course", "Branch", "Grade", "Internship"};
            }



            if(comboBox.getValue().equals("Advisor Stats")) {
                hBoxAdvisors.setVisible(true);
                vboxTableView.setVisible(false);
                lbConsult.setText(String.format(gpeManager.advisorsGeneralStatus()));

                hBoxAdvisors.getChildren().setAll(lbConsult, vboxAdvisorstat);

                vboxLabelView.getChildren().setAll(hBoxAdvisors);
                vbox.getChildren().setAll(HBoxTbtns, hboxComboBox, stackPaneChart, hboxtableButtons);

                tableButtons.setVisible(false);

            }else {

                vboxTableView.setVisible(true);
                hBoxAdvisors.setVisible(false);
                tableButtons.setVisible(true);
                CreateTable(phase, ColumnMapKey);
                vboxTableView.getChildren().setAll(tableView);
                vbox.getChildren().setAll(HBoxTbtns, hboxComboBox, stackPaneChart, hboxtableButtons);
                tableButtons.UpdateTblInnerButtons(gpeManager, tableView,  ColumnMapKey,  dataColName[0], dataColName);

                vbox.setVgrow(tableView, Priority.ALWAYS);
                vbox.setAlignment(Pos.TOP_CENTER);

                if (gpeManager.getClosePhase()>=4) {
                    col_delete.setVisible(false);
                }else if(!phase.equals("Closed") && (comboBox.getValue().equals("All Data") || comboBox.getValue().equals("Proposal List"))){
                    col_delete.setVisible(true);
                }else{

                    col_delete.setVisible(false);
                }
            }


            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
            configAdapter();

            UpdateTableView();
        });



        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });

        menuBar.addPropertyChangeListener(evt -> {
            UpdateTableView();
        });

        gpeManager.addTableUpdateListener(evt -> {
            UpdateTableView();
        });

    }

    private void UpdateTableView() {
        if(!comboBox.getValue().equals("Advisor Stats")) {
            tableView.setItems(generateDataInMap());
        }
        tableView.setVisible(true);
        vboxTableView.setVgrow(tableView, Priority.ALWAYS);
        vbox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setAlignment(Pos.TOP_CENTER);

        vInsertManual.setVisible(false);
        stackPane = new StackPane(vbox, vInsertManual);
        this.setCenter(stackPane);

    }

    private void configAdapter() {
        UpdateTableView();
        if (gpeManager.getClosePhase() >=4) {
            phase = "Closed";
            labelClose.setText(phase);

            lbConsult.setText(String.format(gpeManager.advisorsGeneralStatus()));

            col_delete.setVisible(false);


            menuBar.phaseOpenClose("", false, false, true, true, false, true);
            tableTopButtons.phaseOpenClose("", true, true, false, false);
            tableButtons.phaseOpenClose("", false, true, true);
        }else{
            labelClose.setText("");


            menuBar.phaseOpenClose("", true, false, true, false, true, true);
            tableTopButtons.phaseOpenClose("", true, false, true, true);
            tableButtons.phaseOpenClose("", true, true, true);

        }
        lbConsult.setText(String.format(gpeManager.advisorsGeneralStatus()));
        bottomBorder.BottomInfoUpdate(gpeManager, dataA.size());
    }
    private void update() {

        if (gpeManager.getMenuOpt() == MenuOpt.IN_STATE && gpeManager.getState() == GpeState.ADVISORS) {
            dataA.putAll(gpeManager.consultMode(1));

            configAdapter();
            this.setVisible(true);
            return;
        }
        this.setVisible(false);
    }

}
