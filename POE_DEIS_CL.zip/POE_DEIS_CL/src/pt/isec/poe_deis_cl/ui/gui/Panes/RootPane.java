package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;
/**
 * Class description:
 *
 * Credits
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Root pane.
 */
public class RootPane extends BorderPane {
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The background color of the main window.
     * <p>
     * The Background.
     */
    /**
     * The Background.
     */
    Color background = Color.LIGHTGRAY;

    /**
     * The T main menu.
     */
    Text tMainMenu;
    /**
     * The Btns.
     */
    Button[] btns;
    private static final int NRB = 7;
    private static final int BW = 7;
    private static final int BH = 7;
    /**
     * The Canvas.
     */
    Canvas canvas;

    /**
     * The Predef table width.
     */
    int predefTableWidth = 1050;

    /**
     * The Canvas pane.
     */
    ScrollPane canvasPane;

    /**
     * Instantiates a new Root pane.
     *
     * @param gpeManager the gpe manager
     */
    public RootPane(GpeManager gpeManager){
        this.gpeManager = gpeManager;
        createViews();
        registerHandler();
        update();

    }

    private void createViews() {

 CSSManager.applyCSS(this,"styles.css");
        CSSManager.applyCSS(this,"tableViewBase.css");
        StackPane stackPane = new StackPane(
                new Credits(gpeManager),
                new MenuUI(gpeManager),
                new TableP1Students(gpeManager,predefTableWidth),
                new TableP1Teachers(gpeManager,predefTableWidth),
                new TableP1ProposalsProjects(gpeManager,predefTableWidth),
                new TableP2Candidatures(gpeManager,predefTableWidth),
                new TableP3Proposals(gpeManager,predefTableWidth),
                new TableP4Advisors(gpeManager,predefTableWidth),
                new TableP5Consult(gpeManager,predefTableWidth)

        );

        stackPane.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, CornerRadii.EMPTY, Insets.EMPTY)));

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(stackPane);
        stackPane.setAlignment(Pos.TOP_CENTER);

        scrollPane.setPannable(true);
        scrollPane.setId("scrollPaneMain");
        this.setCenter(scrollPane);
        scrollPane.setFitToHeight(true);
        scrollPane.setFitToWidth(true);

        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
    }

    private void registerHandler() {

        gpeManager.addPropertyChangeListener(evt -> {update();});


    }

    private void update() {

        switch (gpeManager.getState()){


            case CANDIDATURE:
            case STUDENTS:
            case ASSIGNEDPROPOSALS:
                setRight(null);
                setBottom(null);
                break;
            case ADVISORS:
            case CONSULT:
            default:
                break;
        }

    }

}