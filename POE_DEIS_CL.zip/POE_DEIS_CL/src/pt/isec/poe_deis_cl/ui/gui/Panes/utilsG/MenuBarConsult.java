package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.animation.PauseTransition;
import javafx.scene.control.*;
import javafx.scene.input.KeyCombination;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Map;
import java.util.Optional;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Menu bar consult.
 */
public class MenuBarConsult extends MenuBar {

    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Labeltext.
     */
    String labeltext,
    /**
     * The Label close.
     */
    labelClose = "";

    /**
     * The Label handler.
     */
    Label labelHandler;

    /**
     * The Menub.
     */
    MenuBar menub;

    /**
     * The State m.
     */
    Menu stateM,
    /**
     * The File m.
     */
    fileM,
    /**
     * The Configs m.
     */
    configsM,
    /**
     * The Phases m.
     */
    phasesM,
    /**
     * The Status phase.
     */
    StatusPhase,
    /**
     * The Statuslabel close.
     */
    StatuslabelClose;

    /**
     * The M insert manual.
     */
    MenuItem mInsertManual,
    /**
     * The M edit.
     */
    mEdit,
    /**
     * The M undo.
     */
    mUndo,
    /**
     * The M redo.
     */
    mRedo,
    /**
     * The M insert.
     */
    mInsert,
    /**
     * The M delete all.
     */
    mDeleteAll;
    /**
     * The M export.
     */
    MenuItem mExport,
    /**
     * The M export delete.
     */
    mExportDelete,
    /**
     * The M save.
     */
    mSave;
    /**
     * The M student.
     */
    MenuItem mStudent,
    /**
     * The M teachers.
     */
    mTeachers,
    /**
     * The M proposals.
     */
    mProposals;
    /**
     * The M next f.
     */
    MenuItem mNextF,
    /**
     * The M close f.
     */
    mCloseF,
    /**
     * The M back f.
     */
    mBackF;

    /**
     * The Phase.
     */
    String phase = "";
    /**
     * The Conf alert.
     */
    Alert confAlert;
    /**
     * The Table view.
     */
    TableView tableView;
    /**
     * The Column map key.
     */
    String[] columnMapKey;
    /**
     * The Data col name.
     */
    TableColumn<Map, String>[] dataColName;
    /**
     * The Map string table column.
     */
    TableColumn<Map, String> mapStringTableColumn;
    /**
     * The Bottom border.
     */
    BottomInfo bottomBorder;
    /**
     * The Combo box.
     */
    ComboBox comboBox;
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;
    /**
     * The Pcs.
     */
    PropertyChangeSupport pcs;


    /**
     * Instantiates a new Menu bar consult.
     *
     * @param gpeManager           the gpe manager
     * @param tempMessage          the temp message
     * @param tableView            the table view
     * @param columnMapKey         the column map key
     * @param mapStringTableColumn the map string table column
     * @param dataColName          the data col name
     * @param deleteAlert          the delete alert
     * @param comboBox             the combo box
     * @param label                the label
     * @param labelClose           the label close
     * @param bottomBorder         the bottom border
     */
    public MenuBarConsult(GpeManager gpeManager, Text tempMessage, TableView tableView, String[] columnMapKey, TableColumn<Map, String> mapStringTableColumn, TableColumn<Map, String>[] dataColName, Alert deleteAlert, ComboBox comboBox, Label label, Label labelClose, BottomInfo bottomBorder) {
        this.gpeManager = gpeManager;
        this.tempMessage = tempMessage;
        pcs = new PropertyChangeSupport(this);
        this.gpeManager = gpeManager;
        this.tempMessage = tempMessage;
        this.tableView = tableView;
        this.columnMapKey = columnMapKey;
        this.mapStringTableColumn = mapStringTableColumn;
        this.dataColName = dataColName;
        this.comboBox = comboBox;
        this.labeltext = label.getText();
        this.labelHandler = label;
        this.labelClose = "";
        this.bottomBorder = bottomBorder;
        createViews();
        registerHandlers();
        update();
    }

    /**
     * Add property change listener.
     *
     * @param listener the listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }


    private void createViews() {
        CSSManager.applyCSS(this, "stylesMenuBar.css");
        confAlert = new Alert(Alert.AlertType.CONFIRMATION);
        stateM = new Menu("Students");
        fileM = new Menu("File");
        configsM = new Menu("Configuration");
        phasesM = new Menu("Phase");
        StatusPhase = new Menu(labeltext);
        StatusPhase.setId("StatusPhase");
        StatuslabelClose = new Menu(labelClose);
        StatuslabelClose.setId("StatuslabelClose");

        this.getMenus().addAll(fileM, stateM, configsM, phasesM, StatuslabelClose);


        mInsertManual = new MenuItem("Manual Insert");
        mEdit = new MenuItem("Edit");
        mUndo = new MenuItem("Undo");
        mRedo = new MenuItem("Redo");
        mExport = new MenuItem("Export");
        mExportDelete = new MenuItem("Export Delete");
        mSave = new MenuItem("Save");
        mInsert = new MenuItem("Insert");
        mDeleteAll = new MenuItem("Delete All");
        mStudent = new MenuItem("Students");
        mTeachers = new MenuItem("Teachers");
        mProposals = new MenuItem("Proposals");
        mNextF = new MenuItem("Next phase");
        mCloseF = new MenuItem("Close phase");
        mBackF = new MenuItem("Back phase");



            mUndo.setAccelerator(KeyCombination.keyCombination("Ctrl+Z"));
            mRedo.setAccelerator(KeyCombination.keyCombination("Ctrl+Y"));
            mSave.setAccelerator(KeyCombination.keyCombination("Ctrl+S"));
            mEdit.setAccelerator(KeyCombination.keyCombination("Ctrl+E"));
            mInsert.setAccelerator(KeyCombination.keyCombination("Ctrl+I"));



        stateM.getItems().addAll(mInsert, mInsertManual, mEdit, mDeleteAll, new SeparatorMenuItem(), mUndo, mRedo);
        fileM.getItems().addAll(mExport, mExportDelete, mSave);
        configsM.getItems().addAll(mStudent, mTeachers, mProposals);
        phasesM.getItems().addAll(mNextF, mBackF);

    }
    private void registerHandlers() {

        mTeachers.setOnAction(evt -> {
            gpeManager.load();
            gpeManager.f1_teachers();
            tempMessage.setVisible(true);

            tempMessage.setText("Teacher - Phase 1...");
            update();

        });
        mStudent.setOnAction(evt -> {
            gpeManager.f1_students();

            tempMessage.setVisible(true);
            tempMessage.setText("Students - Phase 1...");
            update();
        });
        mProposals.setOnAction(evt -> {
            gpeManager.f1_propProj();

            tempMessage.setVisible(true);
            tempMessage.setText("Proposals - Phase 1...");
            update();
        });
        mDeleteAll.setOnAction(evt -> {
            gpeManager.saveUndo();
            comboBox.setValue("All Data");
            if (gpeManager.deleteAll()) {
                tempMessage.setText("Data removed...");
                tempMessage.setFill(Color.GREEN);
            } else {
                tempMessage.setText("Error removing data...");
                tempMessage.setFill(Color.RED);
            }
            comboBox.setValue("All Data");
            pcs.firePropertyChange(null, null, null);
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();
            update();

            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
            gpeManager.saveRedo();
        });

        mSave.setOnAction(evt -> {
            gpeManager.save();
        });

        mExportDelete.setOnAction(evt -> {

            if (gpeManager.exportDelete()) {
                tempMessage.setText("Exported files removed...");
                tempMessage.setFill(Color.GREEN);
            } else {
                tempMessage.setText("Error removing export files...");
                tempMessage.setFill(Color.RED);
            }

        });


        mInsert.setOnAction(evt -> {
            gpeManager.saveUndo();
      pcs.firePropertyChange(null, null, null);
            comboBox.setValue("All Data");
            if (gpeManager.getState() == GpeState.ADVISORS) {
                gpeManager.addAutoDesignedAdvisor();

            } else {
                if (gpeManager.getState() == GpeState.PROPOSALS && gpeManager.isEmpty()) {
                    confAlert.setTitle("Insert proposals?");
                    confAlert.setContentText("Do you want do add proposals, before register teachers and students?");
                    confAlert.setHeaderText("");
                    ButtonType buttonInsert = new ButtonType("Insert", ButtonBar.ButtonData.YES);
                    ButtonType buttonCancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                    confAlert.getButtonTypes().setAll(buttonCancel, buttonInsert);
                    Optional<ButtonType> result = confAlert.showAndWait();
                    if (result.get() == buttonCancel)
                        return;


                }
                if (gpeManager.insert("")) {
                    gpeManager.saveUndo();
                    tempMessage.setText("Data added...");
                    tempMessage.setFill(Color.GREEN);
                } else {
                    tempMessage.setText("Error adding data...");
                    tempMessage.setFill(Color.RED);
                }
                gpeManager.saveRedo();

            }

            pcs.firePropertyChange(null, null, null);
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();
            comboBox.setValue("All Data");



            update();
            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
            gpeManager.saveRedo();
        });

        mCloseF.setOnAction(evt -> {
            gpeManager.saveUndo();
            comboBox.setValue("All Data");
          if(gpeManager.getClosePhase()==0) {
              if (!gpeManager.checkOneEmptyP1()) {

                  update();
                  pcs.firePropertyChange(null, null, null);
                  comboBox.setValue("All Data");
                  gpeManager.closePhase();
              }else{

                      tempMessage.setText("Add all data from the phase in order to close this phase!...");
                      tempMessage.setFill(Color.RED);
                  System.out.println(tempMessage.toString());
                  tempMessage.setVisible(true);
                  PauseTransition pause = new PauseTransition(Duration.seconds(2));
                  pause.setOnFinished(e -> tempMessage.setText(null));
                  pause.play();

              }
          }else{

              update();
              pcs.firePropertyChange(null, null, null);
              comboBox.setValue("All Data");
              gpeManager.closePhase();
          }
            gpeManager.saveRedo();
        });

        mNextF.setOnAction(evt -> {
            comboBox.setValue("All Data");
            gpeManager.advancePhase();
        });
        mBackF.setOnAction(evt -> {
            comboBox.setValue("All Data");
            gpeManager.previousPhase();
        });

        mUndo.setOnAction(evt -> {
            gpeManager.undo();
            comboBox.setValue("All Data");
        });
        mRedo.setOnAction(evt -> {
            gpeManager.redo();
            comboBox.setValue("All Data");
        });
        mExport.setOnAction(evt -> {
            if (gpeManager.export()) {
                tempMessage.setText("Data Exported...");
                tempMessage.setFill(Color.GREEN);
            } else {
                tempMessage.setText("Error exporting data...");
                tempMessage.setFill(Color.RED);
            }
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();

        });
        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });


    }

    /**
     * Gets m insert.
     *
     * @return the m insert
     */
    public MenuItem getMInsert() {
        return mInsertManual;
    }

    /**
     * Gets m ed it.
     *
     * @return the m ed it
     */
    public MenuItem getMEdIT() {
        return mEdit;
    }

    /**
     * M delete all menu item.
     *
     * @return the menu item
     */
    public MenuItem mDeleteAll() {
        return mDeleteAll;
    }

    /**
     * M insert menu item.
     *
     * @return the menu item
     */
    public MenuItem mInsert() {
        return mInsert;
    }

    /**
     * M close f menu item.
     *
     * @return the menu item
     */
    public MenuItem mCloseF() {
        return mCloseF;
    }

    /**
     * Phase open close.
     *
     * @param labelClose          the label close
     * @param hboxstateM_Status   the hboxstate m status
     * @param hboxconfigsM_Status the hboxconfigs m status
     * @param hboxmBackF_Status   the hboxm back f status
     * @param hboxmNextF_Status   the hboxm next f status
     * @param hboxmCloseF_Status  the hboxm close f status
     * @param hboxphasesM_Status  the hboxphases m status
     */
    public void phaseOpenClose(String labelClose, Boolean hboxstateM_Status, Boolean hboxconfigsM_Status, Boolean hboxmBackF_Status, Boolean hboxmNextF_Status, Boolean hboxmCloseF_Status, Boolean hboxphasesM_Status) {
        this.labelClose = labelClose;


        stateM.setVisible(hboxstateM_Status);
        stateM.setDisable(!hboxstateM_Status);
        configsM.setDisable(!hboxconfigsM_Status);
        configsM.setVisible(hboxconfigsM_Status);
        mBackF.setVisible(hboxmBackF_Status);
        mBackF.setDisable(!hboxmBackF_Status);
        mNextF.setVisible(hboxmNextF_Status);
        mNextF.setDisable(!hboxmNextF_Status);
        mCloseF.setDisable(!hboxmCloseF_Status);
        mCloseF.setVisible(hboxmCloseF_Status);
        phasesM.setDisable(!hboxphasesM_Status);
        phasesM.setVisible(hboxphasesM_Status);


        update();
    }

    private void update() {



        if(!labelClose.equals("Closed")){
        mStudent.setVisible(true);
        mProposals.setVisible(true);
        mTeachers.setVisible(true);
        }

        if (gpeManager.getState() == GpeState.STUDENTS) {
            stateM.setText("Students");

            mStudent.setVisible(false);
        } else if (gpeManager.getState() == GpeState.TEACHERS) {
            stateM.setText("Teachers");
            mTeachers.setVisible(false);
        } else if ((gpeManager.getState() == GpeState.PROPOSALS)) {
            stateM.setText("Proposals");
            mProposals.setVisible(false);
        } else if ((gpeManager.getState() == GpeState.CANDIDATURE)) {
            stateM.setText("Candidatures");
            mProposals.setVisible(false);
        } else if ((gpeManager.getState() == GpeState.ASSIGNEDPROPOSALS)) {
            stateM.setText("Assigned Proposals");
            mProposals.setVisible(false);
        } else if ((gpeManager.getState() == GpeState.ADVISORS)) {
            stateM.setText("Advisors");
            mProposals.setVisible(false);
        } else if ((gpeManager.getState() == GpeState.CONSULT)) {
            stateM.setText("Consult");
            phasesM.setDisable(true);
            phasesM.setVisible(true);

            mProposals.setVisible(false);

            configsM.setDisable(true);
            configsM.setVisible(true);
            mBackF.setDisable(true);
            mBackF.setVisible(true);
            mCloseF.setDisable(true);
            mCloseF.setVisible(true);
            mNextF.setDisable(true);
            mNextF.setVisible(true);

        }


    }

    /**
     * Refresh closed.
     *
     * @param labelClose the label close
     */
    public void refreshClosed(String labelClose) {
        this.labelClose = labelClose;
    }
}
