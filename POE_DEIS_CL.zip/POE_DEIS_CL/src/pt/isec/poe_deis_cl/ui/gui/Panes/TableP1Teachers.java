package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;

import java.util.*;

import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import javafx.util.StringConverter;
import pt.isec.poe_deis_cl.ui.gui.Panes.utilsG.*;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;

/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */


/**
 * The type Table pane.
 */
public class TableP1Teachers extends BorderPane {

    /**
     * The Btn insert.
     */
    Button btnInsert,
    /**
     * The Btn cancel.
     */
    btnCancel;

    /**
     * The Btn new.
     */
    Button btnNew = new Button("New Record");
    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Delete alert.
     */
    Alert deleteAlert;
    /**
     * The Vbox.
     */
    VBox vbox,
    /**
     * The V insert manual.
     */
    vInsertManual;

    /**
     * The Stack pane.
     */
    StackPane stackPane;
    /**
     * The Hbox.
     */
    HBox hboxtableButtons,
    /**
     * The Hbox combo box.
     */
    hboxComboBox,
    /**
     * The H box tbtns.
     */
    HBoxTbtns,
    /**
     * The Hbox lables.
     */
    hboxLables;
    /**
     * The Text field.
     */
    TextField textField[];
    /**
     * The Text label.
     */
    Label textLabel[],
    /**
     * The Label.
     */
    label;
    /**
     * The Menu bar.
     */
    MenuBarConsult menuBar;
    /**
     * The Label close.
     */
    Label labelClose;
    /**
     * The Table buttons.
     */
    TableButtons tableButtons;
    /**
     * The Table top buttons.
     */
    TableTopButtons tableTopButtons;
    /**
     * The Cell del button.
     */
    DellCellButton cellDelButton;
    /**
     * The Bottom border.
     */
    BottomInfo bottomBorder;

    /**
     * The Combo box.
     */
    ComboBox comboBox;

    /**
     * The Phase.
     */
    String phase = "";

    /**
     * The Predef table width.
     */
    int predefTableWidth;

    /**
     * The Table view.
     */
    TableView tableView;

    /**
     * The Data col name.
     */
    TableColumn<Map, String> dataColName[];

    /**
     * The Col delete.
     */
    TableColumn col_delete;

    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * dataT
     */
    Map<String, String> dataT;

    /**
     * The Column map key.
     */
    String[] ColumnMapKey = {"Name", "Mail"};


    /**
     * Instantiates a new Table pane.
     *
     * @param gpeManager       the gpe manager
     * @param predefTableWidth the predef table width
     */
    public TableP1Teachers(GpeManager gpeManager, int predefTableWidth) {
        this.gpeManager = gpeManager;
        dataT = (Map<String, String>) gpeManager.getDataAll(GpeState.TEACHERS);

        if (gpeManager.getClosePhase() >= 1)
            phase = "Closed";

        this.predefTableWidth = predefTableWidth;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {

        CSSManager.applyCSS(this, "tableViewP1Teach.css");

        vbox = new VBox();


        textField = new TextField[ColumnMapKey.length];
        textLabel = new Label[ColumnMapKey.length];
        tempMessage = new Text("");
        tempMessage.setStyle("-fx-font-weight: bold;");
        btnCancel = new Button("Cancel");
        btnInsert = new Button("Submit");
        vInsertManual = new VBox();

        label = new Label("Teachers -  PHASE I");
        label.setVisible(true);
        label.setId("StatusPhase");
        labelClose = new Label(phase);
        labelClose.setVisible(true);
        labelClose.setId("StatuslabelClose");

        comboBox = new ComboBox();
        comboBox.setValue("All Data");

        CreateTable(phase, ColumnMapKey);

        bottomBorder = new BottomInfo(gpeManager, tableView.getItems().size());

        menuBar = new MenuBarConsult(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, deleteAlert, comboBox, label, labelClose, bottomBorder);
        //this.setTop(menuBar);
        menuBar.setVisible(true);
        menuBar.setId("MenuBar");

        AnchorPane aPane = new AnchorPane();
        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
        tableButtons = new TableButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose, bottomBorder);
        this.setBottom(tableButtons);
        tableButtons.setVisible(true);
        VBox.setVgrow(tableButtons, Priority.ALWAYS);

        HBox hbox = new HBox();
        hbox.getChildren().addAll(tableButtons);
        hbox.setAlignment(Pos.CENTER);


        hbox.setPadding(new Insets(0, 2, 2, 2));

        tableTopButtons = new TableTopButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose);
        //this.setBottom(tableTopButtons);
        tableTopButtons.setVisible(true);
        this.setRight(tableTopButtons);
        tableTopButtons.setId("tableTopButtons");
        HBox hb1 = new HBox(tableTopButtons);
        hb1.setAlignment(Pos.TOP_RIGHT);
        HBoxTbtns = new HBox();
        hboxLables = new HBox();

        HBox.setHgrow(hboxLables, Priority.ALWAYS);
        hboxLables.getChildren().addAll(label, labelClose);
        hboxLables.setAlignment(Pos.CENTER);
        hboxLables.setPadding(new Insets(0, 100, 0, 0));
        HBoxTbtns.getChildren().addAll(menuBar, hboxLables, hb1);
        HBoxTbtns.setAlignment(Pos.TOP_LEFT);
        HBoxTbtns.setPadding(new Insets(3, 0, 0, 0));
        this.setTop(HBoxTbtns);

        vbox.getChildren().addAll(HBoxTbtns, tableView, tempMessage, hbox);
        vbox.setPrefWidth(700);
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10);

        AnchorPane.setTopAnchor(btnCancel, 50.0);
        AnchorPane.setTopAnchor(btnInsert, 10.0);
        AnchorPane.setLeftAnchor(btnCancel, 600.0);
        AnchorPane.setLeftAnchor(btnInsert, 598.0);

        aPane.getChildren().addAll(btnCancel, btnInsert);
        vInsertManual.setMaxSize(600, 400);
        vInsertManual.setAlignment(Pos.CENTER);
        vInsertManual.setSpacing(5);
        vInsertManual.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));

        Label lbEdit = new Label("Insert" + gpeManager.getState().toString());
        lbEdit.setStyle("-fx-font: 16 arial;");
        lbEdit.setAlignment(Pos.CENTER);

        vInsertManual.getChildren().addAll(lbEdit);

        textField = new TextField[ColumnMapKey.length];
        textLabel = new Label[ColumnMapKey.length];

        for (int i = 0; i < ColumnMapKey.length; i++) {
            textField[i] = new TextField();
            textLabel[i] = new Label(ColumnMapKey[i]);
            textLabel[i].setAlignment(Pos.CENTER);
            textField[i].setMaxSize(250, 20);
            vInsertManual.getChildren().addAll(textLabel[i], textField[i]);
        }

        vInsertManual.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(1.5))));
        vInsertManual.getChildren().add(aPane);
        vInsertManual.setVisible(false);
        //this.setCenter(vbox);

        stackPane = new StackPane(vbox, vInsertManual);
        stackPane.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, CornerRadii.EMPTY, Insets.EMPTY)));
        this.setCenter(stackPane);
        //Creating the scroll pane

        HBox hBox = new HBox(stackPane);
        hBox.setAlignment(Pos.TOP_CENTER);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(0, 0, 0, 0));

        this.setCenter(hBox);
        hBox.setHgrow(vbox, Priority.ALWAYS);
        hBox.setHgrow(tableView, Priority.ALWAYS);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setPrefWidth(predefTableWidth);


        setBottom(bottomBorder);
    }

    private void CreateTable(String phase,  String[] ColumnMapKey) {
        tableView = new TableView<>(generateDataInMap());
        tableView.setId("table-view");
        tableView.setEditable(true);
        dataColName = new TableColumn[ColumnMapKey.length];


        col_delete = new TableColumn<>("");
        col_delete.setId("col_delete");
        col_delete.setEditable(false);
        col_delete.setReorderable(false);
        col_delete.setSortable(false);
        col_delete.setPrefWidth(50);


        col_delete.setCellFactory(
                new Callback<TableColumn<Record, Boolean>, TableCell<Record, Boolean>>() {

                    @Override
                    public TableCell<Record, Boolean> call(TableColumn<Record, Boolean> p) {

                        return cellDelButton = new DellCellButton(dataColName[0], deleteAlert, tempMessage, gpeManager, 0, 1,  comboBox);

                    }
                });


        col_delete.setCellValueFactory(new MapValueFactory(col_delete));
        tableView.getColumns().setAll(col_delete);

        if (!phase.equals("Closed")) {
            col_delete.setVisible(true);
        } else {
            col_delete.setVisible(false);
        }
        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i] = new TableColumn<>(ColumnMapKey[i]);
            dataColName[i].setId("col_" + i);

            dataColName[i].setCellValueFactory(new MapValueFactory(ColumnMapKey[i]));
            dataColName[i].setMinWidth(110);
            dataColName[i].setPrefWidth(160);
            dataColName[i].setEditable(false);
            dataColName[i].setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Map, String>>() {
                @Override
                public void handle(TableColumn.CellEditEvent<Map, String> mapStringCellEditEvent) {


                    EditsPhases.editP1Teachers(mapStringCellEditEvent.getNewValue(), mapStringCellEditEvent.getRowValue().values(), mapStringCellEditEvent.getTablePosition(), gpeManager, tempMessage);

                }
            });
        }


        tableView.getSelectionModel().setCellSelectionEnabled(true);


        tableView.getColumns().addAll(dataColName);

        Callback<TableColumn<Map, String>, TableCell<Map, String>>
                cellFactoryForMap = (TableColumn<Map, String> p) ->
                new TextFieldTableCell(new StringConverter() {
                    @Override
                    public String toString(Object t) {
                        return t.toString();
                    }

                    @Override
                    public Object fromString(String string) {
                        return string;
                    }
                });

        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i].setCellFactory(cellFactoryForMap);
        }

    }

    private ObservableList<Map> generateDataInMap() {

        String[] ValuesName = new String[ColumnMapKey.length];
        int max = dataT.size();
        ObservableList<Map> allData = FXCollections.observableArrayList();


        int j = 0;
        for (Object key : dataT.keySet()) {
            Map<String, String> dataRow = new HashMap<>();
            String a = dataT.get(key);

            ValuesName[0] = key.toString();
            dataRow.put(ColumnMapKey[0], ValuesName[0]);
            ValuesName[1] = a;
            dataRow.put(ColumnMapKey[1], ValuesName[1]);


            allData.add(dataRow);
            j++;

        }

        return allData;
    }

    private void registerHandlers() {

        btnCancel.setOnAction(evt -> {
            //this.setCenter(vbox);
            vbox.setVisible(true);
            vInsertManual.setVisible(false);
            UpdateTableView();
        });

        menuBar.getMInsert().setOnAction(evt -> {
            vInsertManual.setVisible(true);
            vbox.setVisible(false);
            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
        });

        btnInsert.setOnAction(evt -> {
            gpeManager.saveUndo();

            if (
                    gpeManager.manualInsert(textField[0].getText(), textField[1].getText()) == 0)
                tempMessage.setText("Teacher " + textField[1].getText() + " added!");
            else
                tempMessage.setText("Error adding Teacher!");

            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();


            tableButtons.UpdateTblInnerButtons(gpeManager, tableView,  ColumnMapKey,  dataColName[0], dataColName);
            setTop(vbox);
            btnCancel.fire();
            UpdateTableView();
            gpeManager.saveRedo();

        });

        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });

        menuBar.addPropertyChangeListener(evt -> {
            update();
            UpdateTableView();

        });

        gpeManager.addTableUpdateListener(evt -> {
            UpdateTableView();

        });

        tableButtons.addTableUpdateChangeListener(evt -> {
            UpdateTableView();
        });

        gpeManager.addUndoRedoListener(evt -> {

            dataT.putAll((Map<String, String>) gpeManager.getDataAll(GpeState.TEACHERS));
            UpdateTableView();
        });

        gpeManager.addcloseUpdateListener(evt -> {
            update();
            phase = "Closed";
            labelClose.setText("Closed");
            configAdapter();
        });

    }



    private void UpdateTableView() {

        tableView.setItems(generateDataInMap());
        vbox.setPrefWidth(predefTableWidth);
        tableView.setMaxWidth(predefTableWidth);
        tableView.setVisible(true);
        vbox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setAlignment(Pos.TOP_CENTER);

        vInsertManual.setVisible(false);
        stackPane = new StackPane(vbox, vInsertManual);
        this.setCenter(stackPane);

    }

    private void configAdapter() {

        if (gpeManager.getClosePhase() >= 1) {


            phase = "Closed";
            labelClose.setText("Closed");
            menuBar.phaseOpenClose("", false, true, false, true, false, true);
            tableTopButtons.phaseOpenClose("", false, true, false, false);
            tableButtons.phaseOpenClose("", false, true, true);
            col_delete.setVisible(false);



        } else {

            phase = "";
            labelClose.setText("");
            tableButtons.phaseOpenClose("", true, true, true);
            col_delete.setVisible(true);
            if (!gpeManager.checkOneEmptyP1()) {

                menuBar.phaseOpenClose("", true, true, false, false, true, false);
                tableTopButtons.phaseOpenClose("", false, false, true, true);
                UpdateTableView();
            } else {


                menuBar.phaseOpenClose("", true, true, false, false, false, false);
                tableTopButtons.phaseOpenClose("", false, false, false, true);
            }
        }
        bottomBorder.BottomInfoUpdate(gpeManager, dataT.size());
    }

    private void update() {
        if (gpeManager.getMenuOpt() == MenuOpt.IN_STATE && gpeManager.getState() == GpeState.TEACHERS) {

            configAdapter();

            this.setVisible(true);

            return;
        }
        this.setVisible(false);
    }

}
