package pt.isec.poe_deis_cl.ui.gui.resources;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

import java.util.HashSet;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Sound manager.
 */
public class SoundManager {
    private SoundManager() { }
    private static MediaPlayer mp;


    /**
     * Stop boolean.
     *
     * @param filename the filename
     * @return the boolean
     */
    public static boolean stop(String filename) {


        var url = SoundManager.class.getResource("sounds/" + filename);
        if (url == null)
            return false;

        String path = url.toExternalForm();
        Media music = new Media(path);


            mp.stop();
        mp = new MediaPlayer(music);

        mp.setStartTime(Duration.ZERO);
        mp.setStopTime(music.getDuration());
        mp.setAutoPlay(false);
        return true;
    }

    /**
     * Play boolean.
     *
     * @param filename the filename
     * @return the boolean
     */
    public static boolean play(String filename) {
        try {
            var url = SoundManager.class.getResource("sounds/" + filename);
            if (url == null) return false;
            String path = url.toExternalForm();
            Media music = new Media(path);
            if (mp != null && mp.getStatus() == MediaPlayer.Status.PLAYING)
                mp.stop();
            mp = new MediaPlayer(music);

            mp.setStartTime(Duration.ZERO);
            mp.volumeProperty().set(0.04);

            mp.setStopTime(Duration.millis(7000));
            mp.setAutoPlay(true);
            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.seconds(8),
                            new KeyValue(mp.volumeProperty(), 0)));
            timeline.play();

        } catch (Exception e) {
            return false;
        }
        return true;
    }
}