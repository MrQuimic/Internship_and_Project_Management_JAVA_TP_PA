package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Callback;
import javafx.util.Duration;
import javafx.util.StringConverter;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.model.fsm.GpeState;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;
import pt.isec.poe_deis_cl.ui.gui.Panes.utilsG.*;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;

import java.util.*;

/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */


/**
 * The type Table p 2 candidatures.
 */
public class TableP2Candidatures extends BorderPane {

    /**
     * The Btn insert.
     */
    Button btnInsert,
    /**
     * The Btn cancel.
     */
    btnCancel;

    /**
     * The Temp message.
     */
    Text tempMessage;
    /**
     * The Delete alert.
     */
    Alert deleteAlert;
    /**
     * The Vbox.
     */
    VBox vbox,
    /**
     * The V insert manual.
     */
    vInsertManual;
    /**
     * The Hbox.
     */
    HBox hboxtableButtons,
    /**
     * The Hbox combo box.
     */
    hboxComboBox,
    /**
     * The H box tbtns.
     */
    HBoxTbtns,
    /**
     * The Hbox lables.
     */
    hboxLables;
    /**
     * The Text field.
     */
    TextField textField[];
    /**
     * The Text label.
     */
    Label textLabel[],
    /**
     * The Label.
     */
    label;
    /**
     * The Menu bar.
     */
    MenuBarConsult menuBar;
    /**
     * The Label close.
     */
    Label labelClose;
    /**
     * The Table buttons.
     */
    TableButtons tableButtons;
    /**
     * The Table top buttons.
     */
    TableTopButtons tableTopButtons;
    /**
     * The Cell del button.
     */
    DellCellButton cellDelButton;
    /**
     * The Bottom border.
     */
    BottomInfo bottomBorder;

    /**
     * The Combo box.
     */
    ComboBox comboBox;

    /**
     * The Phase.
     */
    String phase = "";

    /**
     * The Predef table width.
     */
    int predefTableWidth;
    /**
     * The Table view.
     */
    TableView tableView;


    /**
     * The Stack pane.
     */
    StackPane stackPane;
    /**
     * The Data col name.
     */
    TableColumn<Map, String> dataColName[];

    /**
     * The Col delete.
     */
    TableColumn col_delete;
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The Data can.
     */
    Map<String, ArrayList<Object>> dataCan;

    /**
     * The Column map key.
     */
    String[] ColumnMapKey = {"ID", "Candidatures"};

    /**
     * The Choices.
     */
    String choices[] = {"All Data", "All Proposals", "Assigned Candidatures", "Auto Proposals", "Without Candidatures"};

    /**
     * Instantiates a new Table pane.
     *
     * @param gpeManager       the gpe manager
     * @param predefTableWidth the predef table width
     */
    public TableP2Candidatures(GpeManager gpeManager, int predefTableWidth) {
        this.gpeManager = gpeManager;
        dataCan = new HashMap<>();

        if (gpeManager.getClosePhase() >= 2)
            phase = "Closed";
        this.predefTableWidth = predefTableWidth;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {
        CSSManager.applyCSS(this, "TableViewP2Cand.css");

        vbox = new VBox();
        vInsertManual = new VBox();
        tempMessage = new Text("");
        tempMessage.setStyle("-fx-font-weight: bold;");
        btnCancel = new Button("Cancel");
        btnInsert = new Button("Submit");

        label = new Label("Candidatures -  PHASE II");
        label.setVisible(true);
        label.setId("StatusPhase");
        labelClose = new Label(phase);
        labelClose.setVisible(true);
        labelClose.setId("StatuslabelClose");


        comboBox = new ComboBox(FXCollections.observableArrayList(choices));
        comboBox.setValue("All Data");


        CreateTable(phase, ColumnMapKey);

        bottomBorder = new BottomInfo(gpeManager, tableView.getItems().size());

        menuBar = new MenuBarConsult(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, deleteAlert, comboBox, label, labelClose, bottomBorder);
        menuBar.setVisible(true);
        menuBar.setId("MenuBar");


        AnchorPane aPane = new AnchorPane();
        deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
        tableButtons = new TableButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose, bottomBorder);
        this.setBottom(tableButtons);
        tableButtons.setVisible(true);
        VBox.setVgrow(tableButtons, Priority.ALWAYS);
        VBox vobxTempMessage = new VBox();

        vobxTempMessage.getChildren().addAll(tempMessage,tableButtons);
        vobxTempMessage.setAlignment(Pos.CENTER);
        hboxtableButtons = new HBox();
        hboxtableButtons.getChildren().addAll(vobxTempMessage);
        hboxtableButtons.setAlignment(Pos.CENTER);
        hboxtableButtons.setPadding(new Insets(0, 2, 2, 2));

        hboxComboBox = new HBox();
        hboxComboBox.getChildren().add(comboBox);
        hboxComboBox.setAlignment(Pos.CENTER);

        tableTopButtons = new TableTopButtons(gpeManager, tempMessage, tableView, ColumnMapKey, dataColName[0], dataColName, menuBar, deleteAlert, btnCancel, vInsertManual, comboBox, label, labelClose);
        tableTopButtons.setVisible(true);
        this.setRight(tableTopButtons);
        tableTopButtons.setId("tableTopButtons");
        HBox hb1 = new HBox(tableTopButtons);
        hb1.setAlignment(Pos.TOP_RIGHT);
        HBoxTbtns = new HBox();
        hboxLables = new HBox();

        HBox.setHgrow(hboxLables, Priority.ALWAYS);
        hboxLables.getChildren().addAll(label, labelClose);
        hboxLables.setAlignment(Pos.CENTER);
        hboxLables.setPadding(new Insets(0, 100, 0, 0));
        HBoxTbtns.getChildren().addAll(menuBar, hboxLables, hb1);
        HBoxTbtns.setAlignment(Pos.TOP_LEFT);
        HBoxTbtns.setPadding(new Insets(3, 0, 0, 0));
        this.setTop(HBoxTbtns);


        vbox.getChildren().addAll(HBoxTbtns, hboxComboBox, tableView, hboxtableButtons);
        vbox.setPrefWidth(700);
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10);


        AnchorPane.setTopAnchor(btnCancel, 50.0);
        AnchorPane.setTopAnchor(btnInsert, 10.0);
        AnchorPane.setLeftAnchor(btnCancel, 600.0);
        AnchorPane.setLeftAnchor(btnInsert, 598.0);



        aPane.getChildren().addAll(btnCancel, btnInsert);
        vInsertManual.setMaxSize(600, 400);
        vInsertManual.setAlignment(Pos.CENTER);
        vInsertManual.setSpacing(5);

        vInsertManual.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        Label lbEdit = new Label("Insert proposal");
        lbEdit.setStyle("-fx-font: 16 arial;");
        lbEdit.setAlignment(Pos.CENTER);

        vInsertManual.getChildren().addAll(lbEdit);


        textField = new TextField[ColumnMapKey.length];
        textLabel = new Label[ColumnMapKey.length];

        for (int i = 0; i < ColumnMapKey.length; i++) {
            textField[i] = new TextField();
            textLabel[i] = new Label(ColumnMapKey[i]);
            textLabel[i].setAlignment(Pos.CENTER);
            textField[i].setMaxSize(250, 20);
            vInsertManual.getChildren().addAll(textLabel[i], textField[i]);
        }

        vInsertManual.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(1.5))));
        vInsertManual.getChildren().add(aPane);

        vInsertManual.setVisible(false);

        stackPane = new StackPane(vbox, vInsertManual);
        stackPane.setBackground(new Background(new BackgroundFill(Color.GAINSBORO, CornerRadii.EMPTY, Insets.EMPTY)));
        this.setCenter(stackPane);


        HBox hBox = new HBox(stackPane);
        hBox.setAlignment(Pos.TOP_CENTER);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(0, 0, 0, 0));

        this.setCenter(hBox);
        hBox.setHgrow(vbox, Priority.ALWAYS);
        hBox.setHgrow(tableView, Priority.ALWAYS);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setPrefWidth(predefTableWidth);

        setBottom(bottomBorder);
    }

    private void CreateTable(String phase,  String[] ColumnMapKey) {


        tableView = new TableView<>(generateDataInMap());
        tableView.setId("table-view");

        tableView.setEditable(true);

        dataColName = new TableColumn[ColumnMapKey.length];
        col_delete = new TableColumn<>("");
        col_delete.setId("col_delete");
        col_delete.setEditable(false);
        col_delete.setReorderable(false);
        col_delete.setSortable(false);
        col_delete.setPrefWidth(50);

        col_delete.setCellFactory(
                new Callback<TableColumn<Record, Boolean>, TableCell<Record, Boolean>>() {

                    @Override
                    public TableCell<Record, Boolean> call(TableColumn<Record, Boolean> p) {

                        return cellDelButton = new DellCellButton(dataColName[0], deleteAlert, tempMessage, gpeManager, 1, 1, comboBox);

                    }
                });


        col_delete.setCellValueFactory(new MapValueFactory(col_delete));
        tableView.getColumns().addAll(col_delete);


        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i] = new TableColumn<>(ColumnMapKey[i]);
            dataColName[i].setId("col_" + i);

            dataColName[i].setCellValueFactory(new MapValueFactory(ColumnMapKey[i]));
            dataColName[i].setMinWidth(90);
            dataColName[i].setPrefWidth(150);
            dataColName[i].setEditable(false);
            dataColName[i].setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Map, String>>() {
                @Override
                public void handle(TableColumn.CellEditEvent<Map, String> mapStringCellEditEvent) {


                    EditsPhases.editP2Candidatures(mapStringCellEditEvent.getNewValue(), mapStringCellEditEvent.getRowValue().values(), mapStringCellEditEvent.getTablePosition(), gpeManager, tempMessage);

                }
            });
        }
        dataColName[1].setEditable(true);

        dataColName[0].setMinWidth(110);
        dataColName[1].setPrefWidth(310);


        tableView.getSelectionModel().setCellSelectionEnabled(true);

        tableView.getColumns().addAll(dataColName);


        Callback<TableColumn<Map, String>, TableCell<Map, String>>
                cellFactoryForMap = (TableColumn<Map, String> p) ->
                new TextFieldTableCell(new StringConverter() {
                    @Override
                    public String toString(Object t) {
                        if(t == null )
                            return "AAAAAAAA";
                        return t.toString();
                    }

                    @Override
                    public Object fromString(String string) {
                        return string;
                    }
                });

        for (int i = 0; i < ColumnMapKey.length; i++) {
            dataColName[i].setCellFactory(cellFactoryForMap);
        }

    }


    private ObservableList<Map> generateDataInMap() {


        String[] ValuesName = new String[ColumnMapKey.length];
        int max = dataCan.size();
        ObservableList<Map> allData = FXCollections.observableArrayList();


        int j = 0;
        for (Object key : dataCan.keySet()) {
            Map<String, String> dataRow = new HashMap<>();
            ArrayList<Object> a = dataCan.get(key);

            ValuesName[0] = String.valueOf(key);
            dataRow.put(ColumnMapKey[0], ValuesName[0]);
            for (int i = 0; i < ColumnMapKey.length - 1; i++) {
                ValuesName[i + 1] = a.get(i).toString();
                if(ValuesName[i + 1].charAt(0) == '[') {
                    ValuesName[i + 1] = ValuesName[i + 1].substring(1);
                    ValuesName[i + 1] = ValuesName[i + 1].substring( 0 , ValuesName[i + 1].length()-1);

                }
                dataRow.put(ColumnMapKey[i + 1], ValuesName[i + 1]);
            }

            allData.add(dataRow);
            j++;
        }


        return allData;
    }


    private void registerHandlers() {

        btnCancel.setOnAction(evt -> {
            vbox.setVisible(true);
            vInsertManual.setVisible(false);
            UpdateTableView();
        });


        menuBar.getMInsert().setOnAction(evt -> {
            vInsertManual.setVisible(true);
            vbox.setVisible(false);
            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
        });



        comboBox.setOnAction(evt -> {
            dataCan.clear();
            switch (comboBox.getValue().toString()) {
                case "All Data" -> {
                    dataCan.putAll(gpeManager.consultMode(1));
                    comboBox.setValue("All Proposals");

                }
                case "All Proposals" -> {
                    dataCan.putAll(gpeManager.consultMode(1));
                    comboBox.setValue("All Proposals");
                }
                case "Assigned Candidatures" -> {
                    dataCan.putAll(gpeManager.consultMode(2));
                    comboBox.setValue("Assigned Candidatures");
                }
                case "Auto Proposals" -> {
                    dataCan.putAll(gpeManager.consultMode(3));
                    comboBox.setValue("Auto Proposals");
                }
                case "Without Candidatures" -> {
                    dataCan.putAll(gpeManager.consultMode(4));
                    comboBox.setValue("Without Candidatures");
                }
            }

            if (comboBox.getValue() == "All Proposals") {
                ColumnMapKey = new String[]{"ID", "Candidatures"};

            } else {
                ColumnMapKey = new String[]{"Id", "Name", "Mail", "Course", "Branch", "Grade", "Internship"};

            }


            CreateTable(phase, ColumnMapKey);
            vbox.getChildren().setAll(HBoxTbtns, hboxComboBox, tableView, hboxtableButtons);
            tableButtons.UpdateTblInnerButtons(gpeManager, tableView,  ColumnMapKey,  dataColName[0], dataColName);

            vbox.setVgrow(tableView, Priority.ALWAYS);
            vbox.setAlignment(Pos.TOP_CENTER);
            bottomBorder.BottomInfoUpdate(gpeManager, tableView.getItems().size());
            configAdapter();

            UpdateTableView();

            if (gpeManager.getClosePhase()>=2) {
                col_delete.setVisible(false);
            }else if(!phase.equals("Closed") && (comboBox.getValue().equals("All Data") || comboBox.getValue().equals("All Proposals"))){
                col_delete.setVisible(true);
            }else{

                col_delete.setVisible(false);
            }
        });

        btnInsert.setOnAction(evt -> {
            gpeManager.saveUndo();

            if (
                    gpeManager.manualInsert(textField[0].getText(), textField[1].getText()) == 0)
                tempMessage.setText("Candidature " + textField[1].getText() + " added!");
            else
                tempMessage.setText("Error adding Candidature!");

            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();



            tableButtons.UpdateTblInnerButtons(gpeManager, tableView,  ColumnMapKey,  dataColName[0], dataColName);
            vbox.setVgrow(tableView, Priority.ALWAYS);
            vbox.setAlignment(Pos.TOP_CENTER);

            btnCancel.fire();
            UpdateTableView();
            gpeManager.redo();

        });

        gpeManager.addPropertyChangeListener(evt -> {
            update();
        });

        menuBar.addPropertyChangeListener(evt -> {
            update();
            UpdateTableView();

        });

        gpeManager.addTableUpdateListener(evt -> {
            UpdateTableView();

        });

        tableButtons.addTableUpdateChangeListener(evt -> {
            UpdateTableView();
        });


    }

    private void UpdateTableView() {

        tableView.setItems(generateDataInMap());
        vbox.setPrefWidth(predefTableWidth);
        tableView.setMaxWidth(predefTableWidth);
        tableView.setVisible(true);
        vbox.setVgrow(tableView, Priority.ALWAYS);
        vbox.setAlignment(Pos.TOP_CENTER);

        vInsertManual.setVisible(false);
        stackPane = new StackPane(vbox, vInsertManual);
        this.setCenter(stackPane);

    }

    private void configAdapter() {


        UpdateTableView();

        if (gpeManager.getClosePhase() >= 2) {

                col_delete.setVisible(false);

            phase = "Closed";
            labelClose.setText("Closed");
            menuBar.phaseOpenClose("Closed", false, true, false, true, false, true);
            tableTopButtons.phaseOpenClose("Closed", true, true, false, false);
            tableButtons.phaseOpenClose("Closed", false, true, true);



        } else {
            phase = "";
            labelClose.setText("");
            menuBar.phaseOpenClose("", true, false, true, false, true, true);
            tableButtons.phaseOpenClose("", true, true, true);
            tableTopButtons.phaseOpenClose("", true, false, true, true);

        }
        bottomBorder.BottomInfoUpdate(gpeManager, dataCan.size());

    }

    private void update() {




        if (gpeManager.getMenuOpt() == MenuOpt.IN_STATE && gpeManager.getState() == GpeState.CANDIDATURE) {
            dataCan.putAll(gpeManager.consultMode(1));
            configAdapter();



            this.setVisible(true);
            return;
        }
        this.setVisible(false);
    }


}

