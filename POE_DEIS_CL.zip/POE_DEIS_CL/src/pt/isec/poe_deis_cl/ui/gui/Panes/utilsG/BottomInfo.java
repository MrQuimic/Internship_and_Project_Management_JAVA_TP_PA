package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import pt.isec.poe_deis_cl.model.GpeManager;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Bottom info.
 */
public class BottomInfo extends BorderPane {

        private Label sumInfoPanel;
        /**
         * The Gpe manager.
         */
        GpeManager gpeManager;
        /**
         * The Rows.
         */
        int rows,
        /**
         * The Teachers.
         */
        teachers,
        /**
         * The Students.
         */
        students,
        /**
         * The Candidatures.
         */
        candidatures,
        /**
         * The Proposals.
         */
        proposals,
        /**
         * The Atrib advisors.
         */
        AtribAdvisors;

        /**
         * Instantiates a new Bottom info.
         *
         * @param gpeManager the gpe manager
         * @param dataSize   the data size
         */
        public BottomInfo(GpeManager gpeManager, int dataSize){
                this.gpeManager = gpeManager;

                this.rows = dataSize;
                this.teachers = 0;
                this.students = 0;
                this.candidatures = 0;
                this.proposals = 0;

                createViews();
                registerHandlers();
                update();
        }



        private void createViews() {

                sumInfoPanel = new Label();
                sumInfoPanel.setPrefWidth(Integer.MAX_VALUE);
                sumInfoPanel.setStyle("-fx-background-color: rgba(73,69,69,0.08); -fx-font-size: 12;");
                sumInfoPanel.setPadding(new Insets(10));
                sumInfoPanel.setBorder(new Border(new BorderStroke(Color.DARKGRAY,
                        BorderStrokeStyle.SOLID, CornerRadii.EMPTY,new BorderWidths(1))));

                sumInfoPanel.setText(String.format("Data rows: %d  |  Teacher Count: %d  |  Student Count: %d  |  Candidatures: %d  |  Proposals: %d   ||    AINDA NAO ESTAO OS DADOS CERTOS", rows, teachers, students, candidatures,proposals));

                sumInfoPanel.setAlignment(Pos.BASELINE_CENTER);


                setBottom(sumInfoPanel);
        }


        /**
         * Bottom info update.
         *
         * @param gpeManager the gpe manager
         * @param dataSize   the data size
         */
        public void BottomInfoUpdate(GpeManager gpeManager, int dataSize){
                this.rows = dataSize;
                this.students = gpeManager.getBottomInfo(1);
                this.teachers = gpeManager.getBottomInfo(2);
                this.candidatures = gpeManager.getBottomInfo(3);
                this.proposals = gpeManager.getBottomInfo(4);
                this.AtribAdvisors = gpeManager.getBottomInfo(5);
                sumInfoPanel.setText(String.format("Data rows: %d  |  Teacher Count: %d  |  Student Count: %d  |  Candidatures: %d  |  Proposals: %d  |  Attributed Advisores: %d", rows, teachers, students, candidatures,proposals, AtribAdvisors));
                update();
        }

        private void registerHandlers() {
        }

        private void update() {
}
}
