package pt.isec.poe_deis_cl.ui.gui;

/**
 * Class description:
 * <br>
 * GPEState - Enum with all the states
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>,  <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public enum MenuOpt {

    /**
     * Startmenu menu opt.
     */
    STARTMENU,
    /**
     * Teachers gpe state.
     */
    INFO,
    /**
     * Students gpe state.
     */
    CREDITS,
    /**
     * Proposalsprojects gpe state.
     */
    IN_STATE

}



