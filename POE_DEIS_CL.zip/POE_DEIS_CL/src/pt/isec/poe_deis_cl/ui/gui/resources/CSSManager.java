package pt.isec.poe_deis_cl.ui.gui.resources;

import javafx.scene.Parent;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Css manager.
 */
public class CSSManager {
    private CSSManager() { }

    /**
     * Apply css.
     *
     * @param parent   the parent
     * @param filename the filename
     */
    public static void applyCSS(Parent parent, String filename) {
        var url = CSSManager.class.getResource("css/"+filename);
        if (url == null)
            return;
        String fileCSS = url.toExternalForm();
        parent.getStylesheets().add(fileCSS);
    }
/*
    public static void applyto(Parent parent, String cssname) {
        parent.getStyleClass().add(cssname);
    }

 */
}

