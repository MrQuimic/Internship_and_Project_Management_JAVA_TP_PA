package pt.isec.poe_deis_cl.ui.gui.Panes.utilsG;

import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.Map;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Utils gui.
 */
public class UtilsGui {
    /**
     * Register table handlers.
     *
     * @param btnEdit      the btn edit
     * @param btnVisible   the btn visible
     * @param ColumnMapKey the column map key
     * @param dataColName  the data col name
     * @param tableView    the table view
     * @param startcol     the startcol
     */
    public static void registerTableHandlers(Button btnEdit, Button btnVisible, String[] ColumnMapKey, TableColumn<Map, String>[] dataColName, TableView tableView, int startcol) {
        btnEdit.setOnAction(evt -> {

            for (int i = startcol; i < ColumnMapKey.length; i++) {

                if (dataColName[i].editableProperty().get() == true) {
                    btnEdit.setId("buttonNoEdit");
                    dataColName[i].setEditable(false);

                } else {
                    btnEdit.setId("buttonEdit");
                    dataColName[i].setEditable(true);

                }
            }
        });

        btnVisible.setOnAction(evt -> {
            if (tableView.visibleProperty().get() == true)
                tableView.setVisible(false);
            else
                tableView.setVisible(true);
        });

    }


}
