package pt.isec.poe_deis_cl.ui.gui.Panes;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.ui.gui.MenuOpt;
import pt.isec.poe_deis_cl.ui.gui.resources.CSSManager;
import pt.isec.poe_deis_cl.ui.gui.resources.ImageManager;

import java.util.Optional;
/**
 * Class description:
 * The type Main gui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/06/18
 */

/**
 * The type Menu ui.
 */
public class MenuUI extends BorderPane {
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    /**
     * The Background.
     */
    /**
     * The background color of the main window.
     */
    Color background = Color.LIGHTGRAY;

    /**
     * The T main menu.
     */
    Text tMainMenu,
    /**
     * The Temp message.
     */
    tempMessage;
    /**
     * The Btns.
     */
    Button[] btns;
    private static final int NRB = 7;
    private static final int BW = 7;
    private static final int BH = 7;
    /**
     * The Canvas.
     */
    Canvas canvas;
    /**
     * The Canvas pane.
     */
    ScrollPane canvasPane;
    /**
     * The Anchor pane.
     */
    AnchorPane anchorPane;
    /**
     * The V box.
     */
    VBox vBox;

    /**
     * The Quit alert.
     */
    Alert quitAlert;

    /**
     * Instantiates a new Menu ui.
     *
     * @param gpeManager the gpe manager
     */
    public MenuUI(GpeManager gpeManager){
            this.gpeManager = gpeManager;

            createViews();
            registerHandlers();
            update();
        }

    private void createViews() {

        anchorPane = new AnchorPane();
        vBox = new VBox();


        tempMessage = new Text();
        tempMessage.setId("tempMessage");
        quitAlert = new Alert(Alert.AlertType.CONFIRMATION);
        CSSManager.applyCSS(this,"styles.css");
        StackPane stackPane = new StackPane(
                new Credits(gpeManager)
        );

        stackPane.setBackground(new Background(new BackgroundImage(
                ImageManager.getImage("bg1.jpg"),
                BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(1,1,true,true,true,false)
        )));
        this.setCenter(stackPane);
        btns = new Button[5];

        btns[0] = new Button(String.format("\uD83D\uDD01 Phases"));
        btns[1] = new Button(String.format("💾 Save Data"));
        btns[2] = new Button(String.format("\uD83D\uDDEC Credits"));
        btns[3] = new Button(String.format("\uD83D\uDCA5 Reset"));
        btns[4] = new Button(String.format("✖ Quit"));

        for(int i = 0; i < 4; i++){
            btns[i].setPrefSize(110,40);
            btns[i].setId("MenuUIBtn");
           // btns[i].setStyle("");
        }
        btns[4].setPrefSize(80,30);
        btns[4].setId("MenuUIBtn");
        btns[2].setStyle("\n" +
                "    -fx-background-color: \n" +
                "                linear-gradient(#fafdfe, #e8f5fc),\n" +
                "                linear-gradient(#a5c2d5 0%, #7ea7bb 49%, #7d9fb2 50%, #ace59d 100%);\n");
        tMainMenu = new Text();
        tMainMenu.setText("⧉Main Menu");

        tMainMenu.setFont(new Font("TimesRoman", 35));
        vBox.getChildren().add(tMainMenu);

        vBox.setBackground(new Background(new BackgroundImage(
                ImageManager.getImage("bg1.jpg"),
                BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(1,1,true,true,true,false)
        )));
        vBox.setSpacing(10);
        vBox.getChildren().addAll(btns);
        vBox.setAlignment(Pos.CENTER);
        setCenter(vBox);
        this.setCenter(vBox);

        anchorPane.getChildren().addAll(tempMessage);
        AnchorPane.setLeftAnchor(tempMessage, 0.0);
        AnchorPane.setTopAnchor(tempMessage, 150.0);
        vBox.getChildren().add(anchorPane);


    }

    private void registerHandlers() {

        gpeManager.addPropertyChangeListener(evt -> {update();});

        btns[0].setOnAction(event -> {

            gpeManager.setMenuOpt(MenuOpt.IN_STATE);
        });

        btns[1].setOnAction(event -> {
                    if(gpeManager.save()) {
                        tempMessage.setText("Saved Data...");
                        tempMessage.setFill(Color.GREEN);

                    }
                    else {
                        tempMessage.setText("Error saving data" +
                                "...");
                        tempMessage.setFill(Color.RED);
                    }
                    tempMessage.setVisible(true);
                    PauseTransition pause = new PauseTransition(Duration.seconds(2));
                    pause.setOnFinished(e -> tempMessage.setText(null));
                    pause.play();
        });
        btns[2].setOnAction(event -> {
            gpeManager.setMenuOpt(MenuOpt.CREDITS);
            // gpeManager.f1_teachers();

        });


        btns[2].setOnMouseEntered(event ->{
            btns[2].setStyle("\n" +
                    "     -fx-background-color: \n" +
                    "                linear-gradient(#fafdfe, #e8f5fc),\n" +
                    "                linear-gradient(rgba(83,165,243,0.64) 0%, rgb(83,165,243) 49%, rgba(83,165,243,0.83) 50%, #53a5f3 100%);\n");

        });

        btns[2].setOnMouseExited(event ->{
            btns[2].setStyle("\n" +
                    "    -fx-background-color: \n" +
                    "                linear-gradient(#fafdfe, #e8f5fc),\n" +
                    "                linear-gradient(#a5c2d5 0%, #7ea7bb 49%, #7d9fb2 50%, #ace59d 100%);\n");
        });

        btns[3].setOnAction(event -> {
            if(gpeManager.reset()) {
                tempMessage.setText("Data Cleared...");
                tempMessage.setFill(Color.GREEN);
                update();

            }
            else {
                tempMessage.setText("Error clearing data...");
                tempMessage.setFill(Color.RED);

            }
            tempMessage.setVisible(true);
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> tempMessage.setText(null));
            pause.play();


            update();


        });

        btns[4].setOnAction(event -> {
            quitAlert.setTitle("Leave application?");
            quitAlert.setContentText("Are you sure you want to leave?");
            quitAlert.setHeaderText("");
            ButtonType buttonLeave = new ButtonType("Leave", ButtonBar.ButtonData.YES);
            ButtonType buttonCancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            quitAlert.getButtonTypes().setAll(buttonCancel,buttonLeave);
            Optional<ButtonType> result = quitAlert.showAndWait();
            if (result.get() ==buttonLeave)
                Platform.exit();
        });

        /*
        btns[5].setOnMouseEntered(event ->{
            btns[5].setBackground(new Background(new BackgroundFill(Color.INDIANRED, null, null)));
        });
        btns[5].setOnMouseExited(event ->{
            btns[5].setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY ,null,null)));
        });
*/
    }

    private void update() {



        if(gpeManager.getMenuOpt()== MenuOpt.STARTMENU) {
            this.setVisible(true);


        }else{

                this.setVisible(false);
                return;

        }

        canvas = new Canvas();
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.LIGHTCORAL.brighter());
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        gc.setFont(new Font ("Times New Roman", 24));
        gc.setFill(Color.WHITE);
        gc.fillText("Advanced Programming", 50, 50);
        gc.setStroke(Color.BLACK);
        gc.strokeText("Advanced Programming", 50, 100);
        gc.fillText("Advanced Programming", 50, 150);
        gc.strokeText("Advanced Programming", 50, 100);

        gc.drawImage(ImageManager.getImage("ISEC.png"),150,150,200,100);
        gc.drawImage(ImageManager.getExternalImage("https://logodownload.org/wp-content/uploads/2017/04/java-logo12.png"),250,50,50,100);

        switch (gpeManager.getState()){
            case STUDENTS:
            case TEACHERS:
            case CANDIDATURE:
            case ASSIGNEDPROPOSALS:
                setRight(null);
                setBottom(null);
                break;
            case ADVISORS:
            case CONSULT:
            default:
                break;
        }

    }
    }
