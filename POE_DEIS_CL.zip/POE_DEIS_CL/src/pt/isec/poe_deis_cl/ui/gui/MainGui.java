package pt.isec.poe_deis_cl.ui.gui;


import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import pt.isec.poe_deis_cl.model.GpeManager;
import pt.isec.poe_deis_cl.ui.gui.Panes.RootPane;
import pt.isec.poe_deis_cl.utils.Utils;

import java.awt.*;

/**
 * Class description:
 * The type Main cui.
 *
 * @authors : <a href="mailto:a2003035578@isec.pt">Carlos Santos</a>, <a href="mailto:a2019129243@isec.pt">Leonardo Sousa</a>
 * @institution :  <a href="http://isec.pt">ISEC</a> <a href="https://www.isec.pt/pt/instituto/departamentos/deis/">DEIS</a>
 * @subject :  <a href="https://www.ipc.pt/ipc/unidade-curricular/programacao-avancada/">Programaçâo Avançada</a>
 * @date : 2022/04/05
 */
public class MainGui extends Application {
    /**
     * The Gpe manager.
     */
    GpeManager gpeManager;

    @Override
    public void init() throws Exception {
        super.init();
        gpeManager = new GpeManager(); // here or in the constructor
        //gpeManager.f1_students();
        gpeManager.load();

    }

    @Override
    public void start(Stage stage) throws Exception {

        RootPane root = new RootPane(gpeManager);

        root.getChildren().add(new Label("Project PA"));
        root.getChildren().add(new Label("POE_DEIS"));

       // Scene scene = new Scene(root, 1150, 750, Color.INDIGO);
        Scene scene = new Scene(root, 1150, 750, Color.INDIGO);
        stage.setScene(scene);


        stage.setTitle("⧉ DEIS-ISEC");
        stage.setMinWidth(900);
        stage.setMinHeight(500);
        //stage.setMinWidth(850);
        //stage.setMinHeight(700);
        //stage.setMaxWidth(1400);
        //stage.setMaxHeight(1100);
        // stage.setResizable(false);
        stage.setMaximized(false);
        //stage.setFullScreenExitKeyCombination();
        stage.show();


        stage.setOnCloseRequest(evt -> {
            Platform.exit();
        });


    }


    @Override
    public void stop() throws Exception {
        super.stop();
    }

}
